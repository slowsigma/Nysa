using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using Nysa.CodeAnalysis.VbScript;
using Nysa.Logics;
using Nysa.Text;

using SyntaxToken = Dorata.Text.Lexing.Token;
using SyntaxNode  = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript
{

    public class Trivia : IReadOnlyList<TriviaLine>
    {
        private VbScriptContent             _Content;
        private IReadOnlyList<TriviaLine>   _Lines;

        public Int32 Position { get; set; }

        internal Trivia(VbScriptContent content, IReadOnlyList<TriviaLine> lines)
        {
            this._Content   = content;
            this._Lines     = lines;
            this.Position   = 0;
        }

        public Int32 Count => this._Lines.Count;
        public TriviaLine this[Int32 index] => this._Lines[index];
        public IEnumerator<TriviaLine> GetEnumerator() => this._Lines.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((System.Collections.IEnumerable)this._Lines).GetEnumerator();

        public String Text(Int32 index)
        {
            var trivia = this._Lines[index];
            var start  = trivia.TailToken.Span.End.Value;
            var end    = trivia.Line.Position + trivia.Line.Length;
            var length = end - start;
            var line   = trivia.Type == TriviaLineTypes.LineEnd
                         ? this._Content.Value.Substring(start, length)
                         : this._Content.Value.Substring(trivia.Line.Position, trivia.Line.Length).TrimStart();
            var cat    = line.IndexOf("'");

            if (cat > -1)
                line = String.Concat(line.Substring(0, cat), "//", (cat + 1 < line.Length) ? line.Substring(cat + 1) : String.Empty);

            if (trivia.Type == TriviaLineTypes.LineEnd)
            {
                return line.Trim().DataEquals("_")
                       ? String.Empty
                       : line;
            }
            else
                return line;
        }
    }

}