using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

using Nysa.Logics;
using Nysa.Text;

using LexToken  = Dorata.Text.Lexing.Token;
using ParseNode = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript
{

    public struct TokenInfo
    {
        public ParseNode Node        { get; private set; }
        public Int32     EndPosition { get; private set; }

        public TokenInfo(ParseNode node, LexToken token)
        {
            this.Node = node;
            this.EndPosition = token.Span.Position + token.Span.Length;
        }
    }

}
