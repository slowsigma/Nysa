using System;

using SyntaxToken = Dorata.Text.Lexing.Token;
using SyntaxNode  = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript
{

    public struct ContentLine
    {
        public Int32            Position    { get; private set; }
        public Int32            Length      { get; private set; }
        public Boolean          IsEmpty     { get; private set; }

        public ContentLine(Int32 position, Int32 length, Boolean isEmpty)
        {
            this.Position   = position;
            this.Length     = length;
            this.IsEmpty    = isEmpty;
        }
    }

}