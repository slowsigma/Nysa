using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

using Nysa.CodeAnalysis.VbScript;
using Nysa.Logics;
using Nysa.Text;

using Dorata.Text.Parsing;
using LexToken  = Dorata.Text.Lexing.Token;
using ParseNode = Dorata.Text.Parsing.Node;

using HtmlAgilityPack;

namespace Tyler.CodeAnalysis.VbScript
{

    public static class ContentExtensions
    {
        // Returns the first position after the given token.
        public static Int32 End(this LexToken @this)
            => @this.Span.Position + @this.Span.Length;

        // In all but the final line, NextLine will be the position of first character advancing the line (i.e., Char(13) or Char(10)).
        public static Int32 NextLine(this ContentLine @this)
            => @this.Position + @this.Length;

        // Produces ContentLine object for each line in the original source.
        public static List<ContentLine> ContentLines(this String @this)
        {
            var lines    = new List<ContentLine>();
            var current  = (Int32)0;
            var previous = (Int32)0;
            var start    = (Int32)0;
            var length   = (Int32)0;
            var isEmpty  = true;

            void AddLine(Int32 newStart)
            {
                lines.Add(new ContentLine(start, length, isEmpty));
                length  = 0;
                isEmpty = true;
                start   = newStart;
            }
            
            while (current < @this.Length)
            {
                if (@this[current] == 13)
                {
                    if (previous == 13)
                    {
                        AddLine(current + 1);
                    }
                }
                else if (@this[current] == 10)
                {
                    AddLine(current + 1);
                }
                else
                {
                    if (previous == 13)
                    {
                        AddLine(current);
                    }

                    if (!Char.IsWhiteSpace(@this[current]))
                        isEmpty = false;
                    
                    length++;
                }

                previous = @this[current];
                current++;
            }

            if (length > 0 || previous == 10 || previous == 13)
                lines.Add(new ContentLine(start, length, isEmpty));

            return lines;
        }

        public static void CollectTokens(this ParseNode @this, List<TokenInfo> collector)
        {
            foreach (var nodeOrToken in @this.Members)
            {
                if (nodeOrToken.IsToken)
                    collector.Add(new TokenInfo(@this, nodeOrToken.AsToken));
                else
                    nodeOrToken.AsNode.CollectTokens(collector);
            }
        }

        public static List<TriviaLine> WithAnchors(this List<ContentLine> lines, ParseNode root)
        {
            var tokens      = root.Tokens().ToList();
            var triviaLines = new List<TriviaLine>(lines.Count);

            var nextToken   = (Int32)0;
            var anchorIdx   = (Int32)0;

            for (Int32 line = 0; line < lines.Count; line++)
            {
                var triviaLine = (TriviaLine?)null;

                if (lines[line].NextLine() < tokens[nextToken].Span.Position)
                {
                    if (lines[line].IsEmpty &&
                        anchorIdx < nextToken)
                        anchorIdx = nextToken;

                    triviaLine = new TriviaLine(lines[line], tokens[anchorIdx]);
                }
                else // current line does not end prior to current token
                {
                    while (nextToken < tokens.Count && tokens[nextToken].End() <= lines[line].NextLine())
                    {
                        anchorIdx  = nextToken;
                        triviaLine = triviaLine.HasValue
                                     ? triviaLine.Value.Updated(tokens[anchorIdx])
                                     : new TriviaLine(lines[line], tokens[anchorIdx]);
                        nextToken++;
                    }
                }

                if (triviaLine.HasValue)
                    triviaLines.Add(triviaLine.Value);
            }

            return triviaLines;
        }

        public static Trivia Trivia(this VbScriptContent @this, ParseNode root)
        {
            var lines = @this.Value.ContentLines().WithAnchors(root);

            return new Trivia(@this, lines);
        }

    }

}