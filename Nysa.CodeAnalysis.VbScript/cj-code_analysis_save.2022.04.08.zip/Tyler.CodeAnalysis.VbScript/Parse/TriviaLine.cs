using System;

using Nysa.Logics;

using SyntaxToken = Dorata.Text.Lexing.Token;
using SyntaxNode  = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript
{

    public struct TriviaLine
    {
        public ContentLine      Line        { get; private set; }
        public SyntaxToken      LeadToken   { get; private set; }
        public SyntaxToken      TailToken   { get; private set; }
        public TriviaLineTypes  Type        { get; private set; }

        private TriviaLine(ContentLine line, SyntaxToken leadToken, SyntaxToken tailToken, TriviaLineTypes type)
        {
            this.Line       = line;
            this.LeadToken  = leadToken;
            this.TailToken  = tailToken;
            this.Type       = type;
        }

        public TriviaLine(ContentLine line, SyntaxToken anchor)
            : this(line,
                   anchor,
                   anchor,
                     line.NextLine() < anchor.Span.Position ? TriviaLineTypes.Header
                   : anchor.End()    < line.Position        ? TriviaLineTypes.Footer
                   :                                          TriviaLineTypes.LineEnd)
        {
        }

        public TriviaLine Updated(SyntaxToken anchor)
            => new TriviaLine(this.Line, this.LeadToken, anchor, this.Type);

    }

}