using System;

using SyntaxToken = Dorata.Text.Lexing.Token;
using SyntaxNode  = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript
{

    public enum TriviaLineTypes : Int32
    {
        Header,         // the trivia precedes its associated node
        LineEnd,        // the trivia is ends the line of code associated node
        Footer          // the trivia follows its associated node 
    }

}