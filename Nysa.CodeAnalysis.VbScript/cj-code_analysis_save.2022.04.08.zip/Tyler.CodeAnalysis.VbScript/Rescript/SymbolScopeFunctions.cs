using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using HtmlAgilityPack;


namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class SymbolScopeFunctions
    {
        public static SymbolsScope AddScope(this SymbolsScope @this, params ISymbolScope[] others)
            => others.Aggregate(@this, (a, o) => new SymbolsScope(a.Some(), o));

        public static SymbolsScope AddScope(this SymbolsScope @this, IEnumerable<ISymbolScope> others)
            => others.Aggregate(@this, (a, o) => new SymbolsScope(a.Some(), o));

        public static SymbolsScope AddScope(this SymbolsScope @this, params SymbolsScope[] others)
            => others.Aggregate(@this, (a, o) => new SymbolsScope(a.Some(), o));

        public static SymbolsScope AddScope(this SymbolsScope @this, IEnumerable<SymbolsScope> others)
            => others.Aggregate(@this, (a, o) => new SymbolsScope(a.Some(), o));


        private static FoundSymbol BaseCheckHigher(this FoundSymbol @this, Func<SymbolsScope, Boolean> includeScope)
            => @this.Symbol is RedimSymbol redim
               ? @this.Scope.Previous.Bind(p => p.FindBaseSymbol(redim.Name, includeScope)).Or(@this)
               : @this;

        public static Option<FoundSymbol> FindBaseSymbol(this SymbolsScope @this, String name, Func<SymbolsScope, Boolean> includeScope)
            => includeScope(@this)
               ? @this.GetMember<Symbol>(name)
                      .Map(f => (FoundSymbol)new FoundBaseSymbol(f, @this))
                      .Or(@this.Previous.Bind(p => p.FindBaseSymbol(name, includeScope)))
                      .Map(c => c.BaseCheckHigher(includeScope))
               : @this.Previous
                      .Bind(p => p.FindBaseSymbol(name, includeScope))
                      .Map(c => c.BaseCheckHigher(includeScope));

        public static Option<FoundBaseSymbol<VariableSymbol>> FindReturnVariable(this MethodDeclaration @this, SymbolsScope scope)
            => scope.GetMember<VariableSymbol>(@this.Name.Value)
                    .Map(f => new FoundBaseSymbol<VariableSymbol>(f, scope));

        public static Option<FoundSymbol> FindTypeSymbol(this SymbolsScope @this, String name, Func<SymbolsScope, Boolean> includeScope)
            => includeScope(@this)
               ? @this.GetMembers<ClassSymbol>()
                      .FirstOrNone(m => m.Index.ContainsKey(name))
                      .Map(c => (FoundSymbol)new FoundTypeSymbol(c.Index[name], new SymbolsScope(@this.Some(), c), c))
                      .Or(@this.Previous.Bind(p => p.FindTypeSymbol(name, includeScope)))
               : @this.Previous.Bind(p => p.FindTypeSymbol(name, includeScope));

        public static Int32 ToInStat(this SymbolsScope @this)
            => @this.Value switch
            {
                CodeSymbols => SymbolStats.In.CodeSymbols,
                PageSymbols => SymbolStats.In.PageSymbols,
                IncludeSymbols => SymbolStats.In.IncludeSymbols,
                HostSymbols => SymbolStats.In.HostSymbols,
                _ => @this.Previous.Match(p => p.ToInStat(), () => SymbolStats.In.Invalid)
            };

    }

}