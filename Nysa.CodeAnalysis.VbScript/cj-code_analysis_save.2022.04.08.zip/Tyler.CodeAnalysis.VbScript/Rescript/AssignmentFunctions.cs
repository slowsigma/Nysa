using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using HtmlAgilityPack;


namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class AssignmentFunctions
    {
        public static IReadOnlyDictionary<String, String> AssignedTypes(this Program @this)
        {
            var result = new Dictionary<String, String>(StringComparer.OrdinalIgnoreCase);

            void Upsert(Dictionary<String, String> index, String id, String type)
            {
                if (index.ContainsKey(id))
                    index[id] = type;
                else
                    index.Add(id, type);
            }

            foreach (var stmt in @this.GetAll<AssignStatement>(s => true))
            {
                var left = stmt.LeftSingleId();

                if (left is Some<String> someId)
                {
                    if (stmt.RightCreateObjectType() is Some<String> someType)
                        Upsert(result, someId.Value, someType.Value);
                    else if (stmt.RightNewObjectType() is Some<String> someObj)
                        Upsert(result, someId.Value, someObj.Value);
                }
            }

            return result;
        }

        public static IReadOnlySet<String> ComIncidentals(this MethodDeclaration @this, Context context)
        {
            var result = new HashSet<String>(StringComparer.OrdinalIgnoreCase);

            foreach (var stmt in @this.GetAll<AssignStatement>(s => true))
            {
                if (   stmt.LeftSingleId() is Some<String> someLeft
                    && stmt.RightStartId() is Some<String> someRight
                    && context.AssignedTypes.ContainsKey(someRight.Value)
                    && context.AssignedTypes[someRight.Value].DataStartsWith("\""))
                {
                    result.Add(someLeft.Value);
                }
                else if (   stmt.LeftSingleId() is Some<String> someAssn
                         && (   stmt.FinalSelectNodesCall()
                             || stmt.FinalSelectSingleNodeCall()))
                {
                    result.Add(someAssn.Value);
                }
            }

            foreach (var stmt in @this.GetAll<ForEachStatement>(s => true))
            {
                if (stmt.In.HasFinalSelectNodesCall())
                    result.Add(stmt.Variable.Value);
            }

            return result;
        }

        public static IReadOnlyDictionary<String, String> MergeAssignedTypes(this IReadOnlyDictionary<String, String> original, IReadOnlyDictionary<String, String> additional)
        {
            var result = new Dictionary<String, String>(original, StringComparer.OrdinalIgnoreCase);

            void Upsert(Dictionary<String, String> index, String id, String type)
            {
                if (index.ContainsKey(id))
                    index[id] = type;
                else
                    index.Add(id, type);
            }

            foreach (var assign in additional)
                Upsert(result, assign.Key, assign.Value);

            return result;
        }
    }

}