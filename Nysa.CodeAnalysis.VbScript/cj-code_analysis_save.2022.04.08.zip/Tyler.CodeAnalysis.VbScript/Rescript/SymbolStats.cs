using System;
using System.Collections.Generic;
using System.Linq;

using Nysa.Logics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public class SymbolStats
    {
        public static class What
        {
            public static readonly Int32 Argument = 0x01;    // found in: CodeSymbols, IncludeSymbols; found at: BaseLevel
            public static readonly Int32 Class    = 0x02;    // found in: CodeSymbols, IncludeSymbols; found at: BaseLevel
            public static readonly Int32 Constant = 0x04;    // found in: CodeSymbols, IncludeSymbols, HostSymbols; found at: BaseLevel, TypeLevel
            public static readonly Int32 Function = 0x08;    // found in: CodeSymbols, IncludeSymbols, HostSymbols; found at: BaseLevel, TypeLevel
            public static readonly Int32 Variable = 0x10;    // found in: CodeSymbols, PageSymbols, IncludeSymbols, HostSymbols; found at: BaseLevel, TypeLevel
            public static readonly Int32 Invalid  = 0x20;

            public static readonly IReadOnlyList<(String Title, Int32 Value)> Info =
                new List<(String Title, Int32 Value)>()
                {
                    (nameof(Argument), Argument),
                    (nameof(Class), Class),
                    (nameof(Constant), Constant),
                    (nameof(Function), Function),
                    (nameof(Variable), Variable),
                    (nameof(Invalid), Invalid)
                };
        }

        public static class In
        {
            public static readonly Int32 CodeSymbols    = 0x0100;
            public static readonly Int32 PageSymbols    = 0x0200;
            public static readonly Int32 IncludeSymbols = 0x0400;
            public static readonly Int32 HostSymbols    = 0x0800;
            public static readonly Int32 Invalid        = 0x1000;

            public static readonly IReadOnlyList<(String Title, Int32 Value)> Info =
                new List<(String Title, Int32 Value)>()
                {
                    (nameof(CodeSymbols), CodeSymbols),
                    (nameof(PageSymbols), PageSymbols),
                    (nameof(IncludeSymbols), IncludeSymbols),
                    (nameof(HostSymbols), HostSymbols),
                    (nameof(Invalid), Invalid)
                };
        }

        public static class For
        {
            public static readonly Int32 BaseSearch = 0x4000;
            public static readonly Int32 TypeSearch = 0x8000;

            public static readonly IReadOnlyList<(String Title, Int32 Value)> Info =
                new List<(String Title, Int32 Value)>()
                {
                    (nameof(BaseSearch), BaseSearch),
                    (nameof(TypeSearch), TypeSearch)
                };
        }

        public static class How
        {
            public static readonly Int32 Exact   = 0x00000;   // match was exact (characters and casing)
            public static readonly Int32 Inexact = 0x10000;   // match was not exact (characters but not casing)

            public static readonly IReadOnlyList<(String Title, Int32 Value)> Info =
                new List<(String Title, Int32 Value)>()
                {
                    (nameof(Exact), Exact),
                    (nameof(Inexact), Inexact)
                };
    }

        private Dictionary<Int32, Int32> _Hits;
        public Int32 BaseMisses { get; private set; }
        public Int32 TypeMisses { get; private set; }

        private SymbolStats(Dictionary<Int32, Int32> hits, Int32 baseMisses, Int32 typeMisses)
        {
            this._Hits      = hits;
            this.BaseMisses = baseMisses;
            this.TypeMisses = typeMisses;
        }

        public SymbolStats()
            : this(new Dictionary<Int32, Int32>(), 0, 0)
        {
        }

        public Unit AddHit(Int32 what, Int32 @in, Boolean forBase, Boolean exactMatch)
        {
            var index = what | @in | (forBase ? For.BaseSearch : For.TypeSearch) | (exactMatch ? How.Exact : How.Inexact);

            if (this._Hits.ContainsKey(index))
                this._Hits[index] += 1;
            else
                this._Hits.Add(index, 1);

            return Unit.Value;
        }

        public (Int32 Code, Int32 Page, Int32 Include, Int32 Host, Int32 Inexact, Int32 Invalid) HitCounts(Boolean forBase)
        {
            var exacts   = new List<Int32>();
            var inexacts = new List<Int32>();

            foreach (var @in in In.Info) // see definition (they are in order: code, page, include, host, invalid)
            {
                var total = What.Info.Select(w => (w.Value | @in.Value | (forBase ? For.BaseSearch : For.TypeSearch)) | How.Exact)
                                     .Select(v => this._Hits.ContainsKey(v) ? this._Hits[v] : 0)
                                     .Aggregate(0, (c, v) => c + v);

                var inexact = What.Info.Select(w => (w.Value | @in.Value | (forBase ? For.BaseSearch : For.TypeSearch)) | How.Inexact)
                                       .Select(v => this._Hits.ContainsKey(v) ? this._Hits[v] : 0)
                                       .Aggregate(0, (c, v) => c + v);

                exacts.Add(total);
                inexacts.Add(inexact);
            }

            return (exacts[0] + inexacts[0],
                    exacts[1] + inexacts[1],
                    exacts[2] + inexacts[2],
                    exacts[3] + inexacts[3],
                    inexacts[0] + inexacts[1] +  inexacts[2] + inexacts[3] + inexacts[4],
                    exacts[4] + inexacts[4]);
        }

        public Unit AddBaseMiss()
        {
            this.BaseMisses += 1;

            return Unit.Value;
        }

        public Unit AddTypeMiss()
        {
            this.TypeMisses += 1;

            return Unit.Value;
        }

        public SymbolStats AddStats(SymbolStats other)
        {
            foreach (var kv in other._Hits)
            {
                if (this._Hits.ContainsKey(kv.Key))
                    this._Hits[kv.Key] += kv.Value;
                else
                    this._Hits.Add(kv.Key, kv.Value);
            }

            this.BaseMisses += other.BaseMisses;
            this.TypeMisses += other.TypeMisses;

            return this;
        }
    }

}