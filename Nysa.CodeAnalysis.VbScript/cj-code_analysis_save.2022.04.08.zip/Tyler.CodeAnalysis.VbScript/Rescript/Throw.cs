using System;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class Throw
    {

        public static T CodingError<T>(String functionName, String message)
            => throw new Exception($"Coding error in call to '{functionName}': {message}.");
        public static T UnexpectedType<T>(String functionName, String thisArgName)
            => throw new Exception($"Unexpected type encountered in '{functionName}({thisArgName})'.");
        public static T UnexpectedTree<T>(String functionName, String thisArgName)
            => throw new Exception($"Unexpected semantic context in parse tree encountered in '{functionName}({thisArgName}).");

    }

}