using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using Dorata.Text.Parsing;
using SyntaxToken = Dorata.Text.Lexing.Token;
using SyntaxNode  = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class Translate
    {
        public static readonly String Function_Return_Type = "__function_return_type";

        private static readonly Func<SymbolsScope, Boolean> _AllScopes    = ss => !(ss.Value.Tags.Contains("page-elements"));
        private static readonly Func<SymbolsScope, Boolean> _SkipIncludes = ss => !(ss.Value is IncludeSymbols);
        private static readonly Func<SymbolsScope, Boolean> _PageElements = ss => (ss.Value is HostSymbols host && host.Tags.Contains("page-elements"));

        private static readonly List<String> _NoMessages = new List<String>();

        public static String CodeNotification(this String message, String level = "Error")
            => $"/* Tyler.VbsToJs.{level}: {message} */";

        public static String FromDateLiteral(this String dateLiteral)
        {
// change to new Date();
            return dateLiteral;
        }

        public static String FromStringLiteral(this String stringLiteral)
            => stringLiteral.Replace(@"\", @"\\")       // change \ to \\
                            .Replace("\"\"", "\\\"");   // change "" to \"

        public static DraftExpr ToExprDraft(this LiteralValue @this)
            => @this.Type switch
            {
                LiteralValueTypes.Boolean => new DraftExpr(@this.Value.ToLower(), _NoMessages, ExpressionTypes.AccessBoolean),
                LiteralValueTypes.Date => new DraftExpr(@this.Value.FromDateLiteral(), _NoMessages, ExpressionTypes.AccessQuantity),
                LiteralValueTypes.Empty => new DraftExpr(@this.Value, _NoMessages, ExpressionTypes.Access),                         // needs operation level override
                LiteralValueTypes.Float => new DraftExpr(@this.Value, _NoMessages, ExpressionTypes.AccessQuantity),
                LiteralValueTypes.Integer => new DraftExpr(@this.Value.DataStartsWith("&h")
                                                           ? String.Concat("0x", @this.Value.Substring(2))
                                                           : @this.Value, _NoMessages, ExpressionTypes.AccessQuantity),
                LiteralValueTypes.Nothing => new DraftExpr("null", _NoMessages, ExpressionTypes.Access),                       // needs operation level override
                LiteralValueTypes.Null => new DraftExpr(@this.Value.ToLower(), _NoMessages, ExpressionTypes.Access),
                LiteralValueTypes.String => new DraftExpr(String.Concat("\"", @this.Value.Substring(1, @this.Value.Length - 2).FromStringLiteral(), "\""), _NoMessages, ExpressionTypes.AccessString),
                _ => Throw.UnexpectedType<DraftExpr>(nameof(ToJavaScript), nameof(LiteralValue))
            };

        public static String ToJavaScript(this LiteralValue @this)
            => @this.Type switch
            {
                LiteralValueTypes.Boolean => @this.Value.ToLower(),
                LiteralValueTypes.Date => @this.Value.FromDateLiteral(),
                LiteralValueTypes.Empty => @this.Value,                         // needs operation level override
                LiteralValueTypes.Float => @this.Value,
                LiteralValueTypes.Integer => @this.Value.DataStartsWith("&h") ? String.Concat("0x", @this.Value.Substring(2)) : @this.Value,
                LiteralValueTypes.Nothing => "null",                       // needs operation level override
                LiteralValueTypes.Null => @this.Value.ToLower(),
                LiteralValueTypes.String => String.Concat("\"", @this.Value.Substring(1, @this.Value.Length - 2).FromStringLiteral(), "\""),
                _ => Throw.UnexpectedType<String>(nameof(ToJavaScript), nameof(LiteralValue))
            };

        internal static String Join(this IEnumerable<String> @this, String separator)
        {
            var builder = new StringBuilder();
            var count   = 0;

            foreach (var value in @this)
            {
                if (count > 0)
                    builder.Append(separator);

                builder.Append(value);

                count++;
            }

            return builder.ToString();
        }


        // exprType here can be either Access (for function arguments) or AccessQuantity (for array arguments)
        public static IEnumerable<DraftExpr> ToExprDrafts(this IEnumerable<Expression> @this, Context context, SymbolsScope symbols, ExpressionTypes exprType)
            => ((IEnumerable<Expression>)@this).Select(expr => expr.ToExprDraft(context, symbols, exprType));

        private static String ToId(this LiteralValue @this)
            =>    @this.Type == LiteralValueTypes.String
               && @this.Value.Length > 2
               && @this.Value.DataStartsWith("\"")
               && @this.Value.DataEndsWith("\"")
               ? @this.Value.Substring(1, @this.Value.Length - 2)
               : @this.Value;

        private static Boolean Is(this PathIdentifier @this, String name)
            => @this.Value.DataEquals(name);

        private static DraftExpr ToExprDraft(this PathExpression @this, Context context, SymbolsScope symbols, ExpressionTypes exprType)
        {
            var exprBounds      = @this.TokenBounds();
            var messages        = new List<String>();
            var prependThis     = false;
            var incompleteSet   = false;
            var state           = PathExprStates.initial;
            var pathStrs        = new List<String>();
            var pathStates      = new List<PathExprStates>();
            var foundSymbol     = Option<FoundSymbol>.None;
            var foundSymbols    = new List<Option<FoundSymbol>>();
            var classDecl       = context.Level.FirstOf<ClassDeclaration>();
            var incompletArgs   = new List<String>();
            var assign          = exprType == ExpressionTypes.AssignTarget;
            var exec            = exprType == ExpressionTypes.Execute;
            var access          = (   exprType == ExpressionTypes.Access
                                   || exprType == ExpressionTypes.AccessBoolean
                                   || exprType == ExpressionTypes.AccessQuantity
                                   || exprType == ExpressionTypes.AccessString  );
            var comBase         = false;
            var pageBase        = false;

            PathExprStates ProcessGetRefLiteral(LiteralValue getRefLiteral, List<String> commonMsgs, List<String> commonValues, List<PathExprStates> commonStates)
            {
                // a GetRef() call containing a string that is really a reference to a method (i.e., requires symbol lookup)
                var idToken   = exprBounds.Start ?? exprBounds.End ?? default(SyntaxToken);
                var idValue   = getRefLiteral.ToId();
                var innerExpr = new PathExpression(@this.Node.Or(new Node(Id.Rule.LeftExpr, idValue)),
                                                   idValue.Split('.')
                                                          .Select(v => new PathIdentifier(idToken, v)));

                var exprDraft = innerExpr.ToExprDraft(context, symbols, ExpressionTypes.Reference);

                commonMsgs.AddRange(exprDraft.Messages);

                commonValues.Add($"(\"{exprDraft.Value}\")");
                commonStates.Add(PathExprStates.termArgs);

                return PathExprStates.termArgs;
            }

            PathExprStates ProcessGetRefExpr(Expression getRefArg, List<String> commonMsgs, List<String> commonValues, List<PathExprStates> commonStates)
            {
                var exprDraft = getRefArg.ToExprDraft(context, symbols, ExpressionTypes.Reference);

                commonMsgs.AddRange(exprDraft.Messages);

                commonValues.Add($"({exprDraft.Value})");
                commonStates.Add(PathExprStates.termArgs);

                return PathExprStates.termArgs;
            }

            PathExprStates ProcessFunctionArgs(IEnumerable<Expression> args, List<String> commonMsgs, List<String> commonValues, List<PathExprStates> commonStates)
            {
                var funcArgs = args.ToExprDrafts(context, symbols, ExpressionTypes.Access).ToList();
                var (openChar, closeChar) = (state == PathExprStates.function || state == PathExprStates.initial)
                                            ? ("(", ")")
                                            : ("[", "]");

                commonMsgs.AddRange(funcArgs.SelectMany(a => a.Messages));

                var newState = state == PathExprStates.initial ? PathExprStates.variable : PathExprStates.funcArgs;

                commonValues.Add(String.Concat(openChar, String.Join(", ", funcArgs.Select(fa => fa.Value)), closeChar));
                commonStates.Add(newState);
                return  newState;
            }

            PathExprStates ProcessIncompletArgs(IEnumerable<Expression> args, List<String> commonMsgs, List<String> argValues, List<PathExprStates> commonStates)
            {
                var funcArgs = args.ToExprDrafts(context, symbols, ExpressionTypes.Access).ToList();

                commonMsgs.AddRange(funcArgs.SelectMany(a => a.Messages));

                argValues.AddRange(funcArgs.Select(d => d.Value));
                commonStates.Add(PathExprStates.funcArgs);
                return PathExprStates.funcArgs;
            }

            for (Int32 i = 0; i < @this.Count; i++)
            {
                var item     = @this[i];
                var first    = (i == 0);
                var last     = (i == (@this.Count - 1));
                var oneMore  = (i == (@this.Count - 2));
                var argsNext =    (i < (@this.Count - 1))
                               && (   @this[i + 1] is PathArguments
                                   || @this[i + 1] is PathValue    );

                if (item is PathWith && !first)
                    Throw.UnexpectedTree<String>(nameof(ToJavaScript), nameof(PathExpression));     // can only be in the first position
                else if (item is PathWith)
                {
                    if (context.Level.WithLevel.Current > 0)
                    {
                        pathStrs.Add(context.Level.WithLevel.CurrentName);
                        comBase = context.Level.WithLevel.CurrentCom;
                    }
                    else
                    {
                        pathStrs.Add(String.Empty);
                        messages.Append("outer with block not found".CodeNotification());
                    }

                    state = PathExprStates.variable;
                    pathStates.Add(state);
                }
                else if (item is PathIdentifier id)
                {
                    if (   (first && context.AssignedTypes.ContainsKey(id.Value) && context.AssignedTypes[id.Value].DataStartsWith("\""))
                        || (first && context.ComIncidentals.Contains(id.Value)))
                        comBase = true;

                    if (foundSymbol.Map(f => f.Scope.Value is PageSymbols).Or(false))
                        pageBase = true;

                    var typeFilter = pageBase ? _PageElements : _AllScopes;

                    // Search for the id.Value (i.e., a name) in the current context.
                    foundSymbol = !first && comBase          ? Option.None
                                  : first && id.Is("parent") ? context.Fixed.ParentSymbols.FindBaseSymbol(id.Value, _AllScopes)
                                  : first                    ? foundSymbol.Map(f => f.Scope)
                                                                          .Or(symbols)
                                                                          .FindBaseSymbol(id.Value, _AllScopes)
                                  :                            foundSymbol.Map(f => f.Scope == context.Fixed.ParentSymbols
                                                                                    ? f.Scope
                                                                                    : symbols)
                                                                          .Or(symbols)
                                                                          .FindTypeSymbol(id.Value, typeFilter);

                    var isReturnVar = foundSymbol.Map(sc => sc.Symbol is VariableSymbol varSym && varSym.TypeName.Map(tn => tn.DataEquals(Translate.Function_Return_Type)).Or(false))
                                                 .Or(false);

                    var recurseCall =    isReturnVar
                                      && (access || exec)
                                      && argsNext
                                      && oneMore;

                    // See if the found symbol context is pointing to a ClassSymbol
                    var asClass = foundSymbol.Bind(sc => isReturnVar
                                                         ? sc.Scope.Previous.Bind(p => p.As<ClassSymbol>())
                                                         : sc.Scope.As<ClassSymbol>());

                    if (foundSymbol is Some<FoundSymbol> someFound)
                    {
                        if (   first                                            // the first item
                            && asClass is Some<ClassSymbol> classSym            // and it came from a class
                            && !someFound.Value.Symbol.Name.Equals("me")        // but it's not "me"
                            && (!isReturnVar || recurseCall)                    // only use if return var and recursive
                            && classDecl is Some<ClassDeclaration> someClass    // we're currently defining the class
                            && someClass.Value
                                        .Name
                                        .Value
                                        .DataEquals(classSym.Value.Name)    )   // is member of the class
                        {
                            prependThis = true;
                        }

                        if (someFound.Value.Symbol is HardSymbol hard && hard.ErrMessage is Some<String> someErr)
                            messages.Add(someErr.Value);

                        if (someFound.Value.Symbol is PropertySymbol propSym)
                        {
                            var set_resolved = false;
                            var get_resolved = false;

                            if (assign && propSym.Setter is Some<FunctionSymbol> someSetter)
                            {
                                var is_set_prop = someSetter.Value is PropertySetSymbol;

                                // we are in assign target with a setter
                                // and either
                                //        is a property and last
                                //     or is a function with only (oneMore) argsNext
                                if (   (is_set_prop && last)
                                    || (!is_set_prop && argsNext && oneMore))
                                {
                                    foundSymbol = someFound.Value.WithSymbol(someSetter.Value).Some(); // change found to the setter
                                    pathStrs.Add(someSetter.Value.SymbolName());

                                    incompleteSet = !is_set_prop;
                                    state = is_set_prop ? PathExprStates.property : PathExprStates.function;
                                    pathStates.Add(state);
                                    set_resolved = true;
                                }
                            }

                            if (!set_resolved && propSym.Getter is Some<FunctionSymbol> someGetter)
                            {
                                var is_get_prop = someGetter.Value is PropertyGetSymbol;

                                //    is a property and not assign
                                // or is a property and assign but not last
                                // or is a function with argsNext and it's not next to last in an assignment
                                if (   (is_get_prop && !assign)
                                    || (is_get_prop && assign && !last)
                                    || (!is_get_prop && argsNext && !(assign && oneMore))
                                   )
                                {
                                    foundSymbol = someFound.Value.WithSymbol(someGetter.Value).Some(); // change found to the getter
                                    pathStrs.Add(someGetter.Value.SymbolName());

                                    state = is_get_prop ? PathExprStates.property : PathExprStates.function;
                                    pathStates.Add(state);
                                    get_resolved = true;
                                }
                            }

                            if (!set_resolved && !get_resolved)
                                foundSymbol = Option<FoundSymbol>.None;
                        }
                        else if (someFound.Value.Symbol is ConstantSymbol constSym)
                        {
                            if (assign)
                                messages.Add("Cannot assign to a constant.");

                            pathStrs.Add(constSym.SymbolName());
                            state = PathExprStates.constant;
                            pathStates.Add(state);
                        }
                        else if (someFound.Value.Symbol is FunctionSymbol funcSym)
                        {
                            state =   first && someFound.Value.Symbol.Name.DataEquals("getref") ? PathExprStates.getRef
                                    : first && someFound.Value.Symbol.Name.DataEquals("array")  ? PathExprStates.arrayInit
                                    :                                                             PathExprStates.function;

                            pathStates.Add(state);

                            if (state != PathExprStates.arrayInit)
                                pathStrs.Add(funcSym.SymbolName());
                        }
                        else if (someFound.Value.Symbol is ClassSymbol classSymbol)
                        {
                            (state, foundSymbol) = first
                                                   ? (PathExprStates.className, foundSymbol) // valid
                                                   : (PathExprStates.variable, Option.None); // incorrect find

                            pathStates.Add(state);
                            pathStrs.Add(state == PathExprStates.className ? classSymbol.SymbolName() : id.Value);
                        }
                        else if (someFound.Value.Symbol is ArgumentSymbol argSym)
                        {
                            (state, foundSymbol) = first
                                                   ? (PathExprStates.variable, foundSymbol)  // valid
                                                   : (PathExprStates.variable, Option.None); // incorrect find

                            pathStates.Add(state);
                            pathStrs.Add(first ? argSym.SymbolName() : id.Value);
                        }
                        else if (someFound.Value.Symbol is VariableSymbol varSym)
                        {
                            var symName = recurseCall
                                          ? someFound.Value
                                                     .Scope
                                                     .Previous
                                                     .Bind(p => p.FindBaseSymbol(id.Value, _AllScopes))
                                                     .Map(h => h.Symbol.SymbolName())
                                                     .Or(varSym.SymbolName())
                                          : varSym.SymbolName();

                            state = recurseCall ? PathExprStates.function : PathExprStates.variable;

                            pathStates.Add(state);
                            pathStrs.Add(symName);
                        }
                        else if (someFound.Value.Symbol is RedimSymbol redimSym)
                        {
                            state = PathExprStates.variable;

                            pathStates.Add(state);
                            pathStrs.Add(redimSym.SymbolName());
                        }
                        else
                            Throw.CodingError<Unit>(nameof(ToExprDraft), "Found symbol type not handled.");
                    }

                    if (foundSymbol is None<FoundSymbol>)
                    {
                        // basic assumptions
                        state =   last && exec          ? PathExprStates.function
                                : !first && !argsNext   ? PathExprStates.property
                                : argsNext              ? PathExprStates.function
                                :                         PathExprStates.variable;

                        if (comBase)
                        {
                            if (!first && argsNext && id.Is("childNodes")) // override for childNodes (known COM property)
                                state = PathExprStates.property;

                            // all situations
                            if (assign && state == PathExprStates.property && last && classDecl is Some<ClassDeclaration>)
                            {
                                incompleteSet = true;
                                pathStrs.Add("setHostProperty");
                                pathStates.Add(PathExprStates.function);

                                incompletArgs.Add($"\"{id.Value}\"");
                                pathStates.Add(PathExprStates.funcArgs);
                            }
                            else if (state == PathExprStates.function && assign && argsNext && oneMore)
                            {
                                incompleteSet = true;
                                pathStrs.Add(id.Value);
                                pathStates.Add(state);
                            }                            
                            else if (state == PathExprStates.property && id.Is("length"))
                            {
                                pathStrs.Add("Length");
                                pathStates.Add(state);
                            }
                            else
                            {
                                pathStrs.Add(id.Value);
                                pathStates.Add(state);
                            }
                        }
                        else // completely unknown
                        {
                            incompleteSet = assign && argsNext && oneMore;

                            state =   argsNext ? PathExprStates.function        // basic assumptions for unknown ids
                                    : first    ? PathExprStates.variable
                                    :            PathExprStates.property;

                            pathStrs.Add(id.Value);
                            pathStates.Add(state);

                        }
                    }


                    // if we don't come up with a set of COM symbols we can search on, then we might need to put in this condition
                    //if (first || !comBase)
                    context.RecordSymbolStat(id.Value,
                                             asClass.Match(c => false,      // if the scope turns out to be ClassSymbol, it's marked as a type search
                                                           () => i == 0),   // base searches start at the first item in PathExpression
                                             foundSymbol);
                }
                else if (item is PathArguments args)
                {
                    if (incompleteSet)
                        state = ProcessIncompletArgs(args.Select(a => a), messages, incompletArgs, pathStates);
                    else if (state == PathExprStates.getRef && args[0] is LiteralValue getRefLiteral)
                        state = ProcessGetRefLiteral(getRefLiteral, messages, pathStrs, pathStates);
                    else if (state == PathExprStates.getRef)
                        state = ProcessGetRefExpr(args[0], messages, pathStrs, pathStates);
                    else if (state == PathExprStates.function || state == PathExprStates.arrayInit)
                        state = ProcessFunctionArgs(args.Select(a => a), messages, pathStrs, pathStates);
                    else if (   (   state == PathExprStates.variable
                                 || state == PathExprStates.property)
                             && last
                             && exec)
                    {
                        var funcArgs = args.ToExprDrafts(context, symbols, ExpressionTypes.Access);

                        messages.AddRange(funcArgs.SelectMany(f => f.Messages));

                        pathStrs.Add(String.Concat("(", String.Join(", ", funcArgs.Select(f => f.Value)), ")"));
                        state = PathExprStates.funcArgs;
                        pathStates.Add(state);
                    }
                    else 
                    {
                        var arrayArgs = args.ToExprDrafts(context, symbols, ExpressionTypes.AccessQuantity).ToList();

                        pathStrs.Add(String.Join(String.Empty, arrayArgs.Select(aa => $"[{aa.Value}]")));
                        state = PathExprStates.arrayArgs;
                        pathStates.Add(state);
                    }
                }
                else if (item is PathValue value)
                {
                    if (incompleteSet)
                        state = ProcessIncompletArgs(Return.Enumerable(value.Expression), messages, incompletArgs, pathStates);
                    else if (state == PathExprStates.getRef && value.Expression is LiteralValue getRefLiteral)
                        state = ProcessGetRefLiteral(getRefLiteral, messages, pathStrs, pathStates);
                    else if (state == PathExprStates.getRef)
                        state = ProcessGetRefExpr(value.Expression, messages, pathStrs, pathStates);
                    else if (state == PathExprStates.function || state == PathExprStates.arrayInit)
                        state = ProcessFunctionArgs(Return.Enumerable(value.Expression), messages, pathStrs, pathStates);
                    else if (state == PathExprStates.initial)
                        state = ProcessFunctionArgs(Return.Enumerable(value.Expression), messages, pathStrs, pathStates);
                    else
                        Throw.CodingError<Unit>(nameof(ToExprDraft), "Unhandled condition for PathValue.");
                }
                else
                    Throw.UnexpectedType<Unit>(nameof(ToExprDraft), nameof(PathExpression));
            }

            if (foundSymbol.Map(f =>    f.Symbol is ArgumentSymbol argSym           // the final symbol is an argument
                                     && argSym.IsByRef                              // and it's flagged as byref
                                     && assign)                                     // and we are being asked to supply an assign target
                           .Or(false))
            {
                messages.Add("Assigning to a byref argument will not translate.");
            }

            var build = new StringBuilder();
            var fromState = PathExprStates.initial;

            if (prependThis)
            {
                build.Append("this");
                fromState = PathExprStates.variable;
            }

            for (Int32 i = 0; i < pathStrs.Count; i++)
            {
                var last = (i == pathStrs.Count);
                var toState = pathStates[i];

                if (   PathExprTransitions.DotFromStates.Contains(fromState)
                    && PathExprTransitions.DotToStates.Contains(toState))
                    build.Append(".");

                build.Append(pathStrs[i]);

                fromState = toState;
            }

            if (   exprType != ExpressionTypes.Reference
                && !incompleteSet
                && (   (fromState == PathExprStates.function)
                    || (   fromState != PathExprStates.funcArgs
                        && fromState != PathExprStates.arrayArgs
                        && exec)))
                build.Append("()");

            return incompleteSet
                   ? new DraftExprPartial(build.ToString(), messages, ExpressionTypes.AssignTarget, incompletArgs.ToArray())
                   : new DraftExpr(build.ToString(), messages, exprType);
        }

        public static DraftExpr ToExprDraft(this NewObjectExpression @this, Context context, SymbolsScope symbols, ExpressionTypes exprType)
            => @this.Object.ToExprDraft(context, symbols, ExpressionTypes.ClassIdentifier)
                           .Make(classDraft => new DraftExpr(String.Concat("new ",
                                                             classDraft.Value,
                                                             (   @this.Object is PathExpression path
                                                              && path.Count == 1
                                                              && path[0] is PathIdentifier
                                                              ? "()"
                                                              : String.Empty)),
                                                             classDraft.Messages,
                                                             classDraft.Type));

        public static DraftExpr ToExprDraft(this ConstantExpression @this, Context context, SymbolsScope symbols, ExpressionTypes exprType)
            =>   @this is ConstantOperation operation ? operation.ToExprDraft(context, symbols, exprType)
               : @this is LiteralValue literal ? context.Fixed.InspectLiteral(literal).ToExprDraft()
               : Throw.UnexpectedType<DraftExpr>(nameof(ToExprDraft), nameof(ConstantExpression));

        public static DraftExpr ToExprDraft(this ConstantOperation @this, Context context, SymbolsScope symbols, ExpressionTypes exprType)
            => @this.Type switch
            {
                ConstantOperationTypes.add => @this.Operand.ToExprDraft(context, symbols, exprType).Make(od => new DraftExpr(String.Concat("+", od.Value), od.Messages, ExpressionTypes.AccessQuantity)),
                ConstantOperationTypes.subtract => @this.Operand.ToExprDraft(context, symbols, exprType).Make(od => new DraftExpr(String.Concat("-", od.Value), od.Messages, ExpressionTypes.AccessQuantity)),
                ConstantOperationTypes.precedence => @this.Operand.ToExprDraft(context, symbols, exprType).Make(od => new DraftExpr(String.Concat("(", od.Value, ")"), od.Messages, ExpressionTypes.AccessQuantity)),
                _ => Throw.UnexpectedType<DraftExpr>(nameof(ToExprDraft), nameof(ConstantOperation))
            };

        public static DraftExpr ToExprDraft(this OperateExpression @this, Context context, SymbolsScope symbols, ExpressionTypes exprType)
        {
            // Notes: OperateExpression always returns Access, AccessBoolean, AccessQuantity,
            //        or AccessString.
            //        The incoming exprType argument indicates what the calling translation
            //        function expects. If exprType is AccessBoolean, the result of ToExprDraft
            //        is for the predicate of an if statement or one of the loop type conditions.
            //        The right hand side of an assignment statement always uses the general
            //        Access type for exprType. The only place that can call ToExprDraft using
            //        AccessQuantity is for an array index argument.  In this situation, the
            //        incoming Operation must be a quantity type operation.
            //        The general rule for operands is this:  Operands always get an exprType
            //        based upon the class of @this.Operation except when the class is
            //        OpsForBooleanAndBit.

            var accessBool  = exprType == ExpressionTypes.AccessBoolean;
            var isBoolOp    = Operators.BooleanIndex.ContainsKey(@this.Operation);
            var isQuantOp   = Operators.TakingQuantities.Contains(@this.Operation);

            exprType        =   isQuantOp ? ExpressionTypes.AccessQuantity
                              :             exprType;                       // sub ops may be logical (i.e., from And to sub Or)

            var opDrafts = @this.Operands
                                .Select(o => (Draft: o.ToExprDraft(context, symbols, exprType),
                                              NonLiteral: o.IsNotLiteral(),
                                              IsGetAttr: o.EndsInCallTo("getattribute")))
                                .ToList();

            var oneQuant = false;
            var messages = new List<String>();

            foreach (var opDraft in opDrafts)
            {
                messages.AddRange(opDraft.Draft.Messages);

                if (opDraft.Draft.Type == ExpressionTypes.AccessQuantity)
                    oneQuant = true;
            }

            if (isBoolOp && !oneQuant)
            {
                if (@this.Operation == OperationTypes.ExclusiveOr)
                {
                    var xorStr = String.Empty;

                    // != operator
                    // ! prefix for Access
                    // (a != b) != c  etc.
                    for (Int32 i = 0; i < opDrafts.Count; i++)
                    {
                        if (i == 0)
                            xorStr = $"!{opDrafts[i].Draft.Value}";
                        else if (i == (opDrafts.Count - 1))
                            xorStr = $"{xorStr} != !{opDrafts[i].Draft.Value}";
                        else // more will follow, parens needed
                            xorStr = $"({xorStr} != !{opDrafts[i].Draft.Value})";
                    }

                    return new DraftExpr(xorStr, messages, exprType);
                }
                else if (@this.Operation == OperationTypes.Not)
                    return @this.Operands.Count == 1
                           ? new DraftExpr($" ! ({opDrafts[0].Draft.Value})", messages, exprType)
                           : Throw.UnexpectedTree<DraftExpr>(nameof(ToExprDraft), nameof(OperateExpression));
                else
                    return new DraftExpr(String.Join($" {Operators.BooleanIndex[@this.Operation].Logical} ", opDrafts.Select(d => d.Draft.Value)), messages, exprType);
            }
            else if (isBoolOp && oneQuant)
            {
                var opStr = Operators.BooleanIndex[@this.Operation].Bitwise;

                return (@this.Operation == OperationTypes.Not)
                       ? @this.Operands.Count == 1
                         ? new DraftExpr($"{opStr}{opDrafts[0].Draft.Value}", messages, exprType)
                         : Throw.UnexpectedTree<DraftExpr>(nameof(ToExprDraft), nameof(OperateExpression))
                       : new DraftExpr(String.Join($" {opStr} ", opDrafts.Select(d => d.Draft.Value)), messages, exprType);
            }
            else if (Operators.OtherBooleanIndex.ContainsKey(@this.Operation))
            {
                var opArgs = String.Join(", ", opDrafts.Select(d => d.Draft.Value));
                var opFunc =   @this.Operation == OperationTypes.Implication ? context.Fixed.SafeImpFunction
                             : @this.Operation == OperationTypes.Equivalence ? context.Fixed.SafeEqvFunction
                             : Throw.UnexpectedType<String>(nameof(ToExprDraft), nameof(OperateExpression));

                return new DraftExpr($"{opFunc}({opArgs})", messages, ExpressionTypes.AccessBoolean);
            }
            else if (Operators.ComparisonIndex.ContainsKey(@this.Operation))
            {
                return new DraftExpr(String.Join($" {Operators.ComparisonIndex[@this.Operation]} ", opDrafts.Select(d => d.Draft.Value)), messages, ExpressionTypes.AccessBoolean);
            }
            else if (@this.Operation == OperationTypes.IntDivide)
            {
                var divStr = String.Join(" / ", opDrafts.Select(d => d.Draft.Value));

                return new DraftExpr($"Math.floor({divStr})", messages, ExpressionTypes.AccessQuantity);
            }
            else if (@this.Operation == OperationTypes.Concatenate) // VbScript '&' operator.
            {
                Boolean IsNullStr(String value)
                    => value.DataEquals("global.nullstring") || value.DataEquals("vbnullstring") || value.DataEquals("\"\"");

                var nullStrs    = opDrafts.Count(d => IsNullStr(d.Draft.Value));
                var include     = nullStrs > 0 && nullStrs < opDrafts.Count
                                  ? opDrafts.Where(d => !IsNullStr(d.Draft.Value))
                                  : opDrafts;

                return new DraftExpr(String.Join(" + ", include.Select(od => od.IsGetAttr || (od.NonLiteral && (nullStrs > 0))
                                                                             ? $"{context.Fixed.SafeDeNullFunc}({od.Draft.Value})"
                                                                             : od.Draft.Value)),
                                     messages,
                                     ExpressionTypes.AccessString);
            }
            else
            {
                return @this.Operation switch
                {
                    OperationTypes.SignNegative => new DraftExpr(String.Concat("-", opDrafts[0].Draft.Value), messages, ExpressionTypes.AccessQuantity),
                    OperationTypes.SignPositive => new DraftExpr(String.Concat("+", opDrafts[0].Draft.Value), messages, ExpressionTypes.AccessQuantity),
                    // Add, Subtract, Mod, Multiply, Divide, Exponentiate
                    _ => new DraftExpr(String.Join($" {Operators.MathIndex[@this.Operation]} ", opDrafts.Select(d => d.Draft.Value)), messages, ExpressionTypes.AccessQuantity)
                };
            }
        }

        public static DraftExpr ToExprDraft(this PrecedenceExpression @this, Context context, SymbolsScope symbols, ExpressionTypes exprType)
            => @this.Value
                    .ToExprDraft(context, symbols, exprType)
                    .Make(v => new DraftExpr(String.Concat("(", v.Value, ")"), v.Messages, v.Type));

        public static DraftExpr ToExprDraft(this Expression @this, Context context, SymbolsScope symbols, ExpressionTypes exprType)
            =>   @this is ConstantOperation operation ? operation.ToExprDraft(context, symbols, exprType)
               : @this is LiteralValue literal ? context.Fixed.InspectLiteral(literal).ToExprDraft(context, symbols, exprType)
               : @this is NewObjectExpression newObject ? newObject.ToExprDraft(context, symbols, exprType)
               : @this is PathExpression path ? path.ToExprDraft(context, symbols, exprType)
               : @this is OperateExpression operate ? operate.ToExprDraft(context, symbols, exprType)
               : @this is PrecedenceExpression precedence ? precedence.ToExprDraft(context, symbols, exprType)
               : Throw.UnexpectedType<DraftExpr>(nameof(ToJavaScript), nameof(Expression));

        public static String ToJavaScript(this ArgumentDefinition @this)
            => String.Concat(@this.Name.Value, @this.ArraySuffix ? "[]]" : String.Empty);

        public static Boolean AssignsThis(this AssignStatement @this, Identifier id)
            =>    @this.Left is PathExpression leftPath
               && leftPath.Count == 1
               && leftPath[0] is PathIdentifier leftId
               && leftId.Value.DataEquals(id.Value);

        public static Unit ToJavaScript(this MethodDeclaration @this, Context context, SymbolsScope symbols)
        { 
            var stmtBounds = @this.TokenBounds();
            // method name taken from enclosing context not inside it's own scope (i.e., "prior to context = contex.ForScope(...)")
            var classDecl  = context.Level
                                    .FirstOf<ClassDeclaration>();

            var methSymbol = symbols.GetMember<Symbol>(@this.Name.Value)
                                    .Bind(s => @this is PropertyDeclaration propDecl
                                               ? s is PropertySymbol propSym
                                                 ? propDecl.Access == PropertyAccessTypes.Get
                                                   ? propSym.Getter
                                                   : propSym.Setter
                                                 : (s as FunctionSymbol).AsOption()
                                               : (s as FunctionSymbol).AsOption());

            var methName   = methSymbol.Match(s => s.SymbolName(),
                                              () => classDecl.Map(c => true).Or(false) && @this.Visibility.Or(VisibilityTypes.Public) == VisibilityTypes.Private
                                                    ? String.Concat("#", @this.Name.Value)
                                                    : @this.Name.Value);

            var win_onload = classDecl is None<ClassDeclaration> && @this.Name.Value.DataEquals("window_onload") && @this.Arguments.Count == 0;

            var declIntro  = classDecl is Some<ClassDeclaration>
                             ? methSymbol is Some<FunctionSymbol> someFunc
                               ? someFunc.Value is PropertyGetSymbol ? $"get {methName}"
                               : someFunc.Value is PropertySetSymbol ? $"set {methName}"
                               :                                       methName
                               : Throw.UnexpectedTree<String>(nameof(ToJavaScript), nameof(MethodDeclaration))
                             : win_onload
                               ? "window.addEventListener(\"load\", function "
                               : $"function {methName}";


            Int32 IfBranchComplexity(StatementList stmts)
                => stmts.Select(s => s switch
                {
                    VariableDeclaration => 0,
                    ConstantDeclaration => 0,
                    AssignStatement => 1,
                    CallStatement => 1,
                    InlineCallStatement => 1,
                    EraseStatement => 1,
                    RedimStatement redim => redim.Variables.Count,
                    _ => 2
                }).Aggregate(0, (a, c) => a + c);

            Int32 IfStmtComplexity(IfStatement stmt)
                =>   (IfBranchComplexity(stmt.Consequent) > 1) ? 2
                   : (stmt.Alternatives.Count == 0) ? 1
                   : (   stmt.Alternatives.Count == 1
                      && stmt.Alternatives[0] is FinalElseBlock finalElse)
                     ? IfBranchComplexity(finalElse.Statements)
                     : 2; // else if || multiple alternatives

            Int32 StmtComplexity(Statement stmt)
                => stmt switch
                {
                    VariableDeclaration => 0,
                    ConstantDeclaration => 0,
                    AssignStatement => 1,
                    CallStatement => 1,
                    InlineCallStatement => 1,
                    EraseStatement => 1,
                    ExitStatement => 1,
                    RedimStatement redim => redim.Variables.Count,
                    IfStatement ifStmt => IfStmtComplexity(ifStmt),
                    _ => 2
                };

            // switch to this methods symbols (i.e., it's internal symbols)
            symbols = symbols.SymbolsFor(@this);

            var tryWrap      =    @this.Statements.Count == 2
                               && @this.Statements[0] is OnErrorResumeNext
                               && (StmtComplexity(@this.Statements[1]) < 2);
            var tryBounds    = tryWrap ? @this.Statements[0].TokenBounds()
                                       : (Start: null, End: null, StartPlusOne: null, EndMinusOne: null);
            var assignsList  = @this.GetAll<AssignStatement>(a => a.AssignsThis(@this.Name));
            // if we don't find returnSymbol, then we have a bug in the code
            var returnSymbol = @this.FindReturnVariable(symbols)
                                    .Match(v => v.Symbol,
                                           () => Throw.CodingError<VariableSymbol>(nameof(ToJavaScript), nameof(MethodDeclaration)));

            var methodCtx    = context.NextContext(@this, context.Level.WithLevel.NewLevel(), assignsList.Count, returnSymbol);
            var finalReturn  =    (assignsList.Count == 1)
                               && (assignsList.Contains(@this.Statements[@this.Statements.Count - 1]));
            var tryIndented  = tryWrap ? methodCtx.LineIndented() : methodCtx;
            var indented     = tryIndented.LineIndented();
            var argCount     = @this.Arguments.Count;

            // @this.IsDefault
            // @this.Arguments[] -> ArgumentDefinition.Modifier
            // @this.Arguments[] -> ArgumentDefinition.ArraySuffix

            var args = String.Concat("(", String.Join(", ", @this.Arguments.Select(a => a.Name.Value)), ")");

            methodCtx.AppendLine(String.Concat(declIntro, args, " {"), stmtBounds.Start, null);

            if (tryWrap)
                tryIndented.AppendLine("try {", tryBounds.Start, tryBounds.End);

            if (finalReturn)
            {
                if (@this.Statements.Count > 1 && !tryWrap)
                {
                    var allButLast = @this.Statements.SkipLast(1).ToList();

                    allButLast.ProcessStatements(indented, symbols);
                }

                var finalBounds = assignsList[0].TokenBounds();
                var rightDraft  = assignsList[0].Right.ToExprDraft(indented, symbols, ExpressionTypes.Access);

                foreach (var err in rightDraft.Messages)
                    indented.AppendLine(err.CodeNotification(), null, null);

                // single method assigning statement
                indented.AppendLine(String.Concat("return ", rightDraft.Value, ";"), finalBounds.Start, finalBounds.End);
            }
            else
            {
                if (assignsList.Count > 0)
                    indented.AppendLine(String.Concat("var ", returnSymbol.SymbolName(), ";"), null, null);

                if (tryWrap)
                    @this.Statements.Skip(1).ToList().ProcessStatements(indented, symbols);
                else
                    @this.Statements.ProcessStatements(indented, symbols);

                if (assignsList.Count > 0)
                    indented.AppendLine(String.Concat("return ", returnSymbol.SymbolName(), ";"), null, null);
            }

            if (tryWrap)
            {
                tryIndented.AppendLine($"}} catch (__{@this.Name.Value}_error) {{", null, null);
                indented.AppendLine($"return null;", null, null);
                tryIndented.AppendLine("}", null, null);
            }

            methodCtx.AppendLine(win_onload ? "});" : "}", stmtBounds.EndMinusOne, stmtBounds.End);

            return Unit.Value;
        }

        public static Draft ToDraft(this AssignStatement @this, Context context, SymbolsScope symbols)
        {
            var leftDraft  = @this.Left.ToExprDraft(context, symbols, ExpressionTypes.AssignTarget);
            var rightDraft = @this.Right.ToExprDraft(context, symbols, ExpressionTypes.Access);

            if (leftDraft is DraftExprPartial partial) // only occurs when last path item is a property setter converted to a function
            {
                return new Draft(String.Concat(partial.Value, "(", String.Join(", ", partial.Args.Concat(Return.Enumerable(rightDraft.Value))), ");"),
                                 partial.Messages.Concat(rightDraft.Messages).ToList());
            }
            else
            {
                var tryCustom = context.Fixed
                                    .CustomToJs
                                    .ToJavaScript(@this, context, symbols, leftDraft, rightDraft);

                return tryCustom != null
                       ? tryCustom
                       : new Draft(String.Concat(leftDraft.Value, " ", "=", " ", rightDraft.Value, ";"),
                                   new List<String>(leftDraft.Messages.Concat(rightDraft.Messages)));
            }
        }
            
        public static Draft ToDraft(this CallStatement @this, Context context, SymbolsScope symbols)
        {
            if (context.Fixed.CustomToJs.Message(@this, context, symbols) is Some<String> someMsg)
                context.AppendLine(someMsg.Value.CodeNotification(), null, null);

            return @this.AccessExpression
                        .ToExprDraft(context, symbols, ExpressionTypes.Execute)
                        .Make(v => new Draft(String.Concat(v.Value, ";"), v.Messages));
        }

        public static Unit ToJavaScript(this ClassDeclaration @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds = @this.TokenBounds();
            
            symbols = symbols.SymbolsFor(@this);
            context = context.NextContext(@this);

            var indented  = context.LineIndented();
            var ranked    = new List<Variable>();
            var classInit = (MethodDeclaration?)null;

            if (symbols.Index.ContainsKey("init") && symbols.Index["init"] is FunctionSymbol initFunc)
            {
                if (initFunc.Members.Where(m => m is ArgumentSymbol).Count() == 1)
                {
                    context.AppendLine(String.Empty, null, null);
                    context.AppendLine(String.Concat("function ItemCreate", @this.Name, "() {"), null, null);
                    context.LineIndented().AppendLine($"return new {@this.Name}();", null, null);
                    context.AppendLine("}", null, null);
                    context.AppendLine(String.Empty, null, null);
                }
            }

            context.AppendLine(String.Concat("class", " ", @this.Name.Value, " {"), stmtBounds.Start, stmtBounds.StartPlusOne);

            foreach (var item in @this.Statements)
            {
                // capture array variables for constructor
                if (item is FieldDeclaration fieldDecl)
                    ranked.AddRange(fieldDecl.Fields.Where(f => f.ArrayRanks is Some<IReadOnlyList<LiteralValue>>));
                else if (item is VariableDeclaration varDecl)
                    ranked.AddRange(varDecl.Variables.Where(v => v.ArrayRanks is Some<IReadOnlyList<LiteralValue>>));

                item.ToJavaScript(indented, symbols);

                if (item is MethodDeclaration methDecl && methDecl.Name.Value.DataEquals("class_initialize"))
                    classInit = methDecl;
            }

            if (classInit != null || ranked.Count > 0)
            {
                indented.AppendLine("", null, null);
                indented.AppendLine("constructor() {", null, null);

                var constructorLines = indented.LineIndented();

                var initSymbol = classInit != null ? symbols.GetMember<Symbol>(classInit.Name.Value) : Option.None;

                foreach (var variable in ranked)
                {
                    var rankStr = variable.ArrayRanks.Map(ranks => String.Join(", ", ranks.Select(v => v.ToJavaScript()))).Or(String.Empty);

                    symbols.GetMember<Symbol>(variable.Name.Value)
                           .Affect(n =>
                           {
                               constructorLines.AppendLine(String.Concat("this.", n.SymbolName(), " = ", context.Fixed.ArrayCreateFunc, "(", rankStr, ");"), null, null);
                           });
                }

                if (initSymbol is Some<Symbol> initGood)
                {
                    if (ranked.Count > 0)
                        constructorLines.AppendLine("", null, null);

                    constructorLines.AppendLine(String.Concat("this.", initGood.Value.SymbolName(), "();"), null, null);
                }
                    

                indented.AppendLine("}", null, null);
            }

            context.AppendLine("}", stmtBounds.EndMinusOne, stmtBounds.End);

            return Unit.Value;
        }

        public static Unit ToJavaScript(this ConstantDeclaration @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds = @this.TokenBounds();

            for (Int32 i = 0; i < @this.Constants.Count; i++)
            {
                var constant  = @this.Constants[i];
                var varName   = symbols.GetMember<Symbol>(constant.Name.Value).Match(s => s.SymbolName(), () => constant.Name.Value);
                var exprDraft = constant.Expression.Match(expr => expr.ToExprDraft(context, symbols, ExpressionTypes.Access),
                                                          () => new DraftExpr("undefined", _NoMessages, ExpressionTypes.Access));

                foreach(var msg in exprDraft.Messages)
                    context.AppendLine(msg.CodeNotification(), null, null);
                

                context.AppendLine(String.Concat("const ", varName, " = ", exprDraft.Value, ";"),
                                   i == 0 ? stmtBounds.Start : null,
                                   i == (@this.Constants.Count - 1) ? stmtBounds.End : null);
            }

            return Unit.Value;
        }
            
        public static Unit ToJavaScript(this ConstantStatement @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds = @this.TokenBounds();

            for (Int32 i = 0; i < @this.Constants.Count; i++)
            {
                var constant  = @this.Constants[i];
                var exprDraft = constant.Expression.Match(expr => expr.ToExprDraft(context, symbols, ExpressionTypes.Access),
                                                          () => new DraftExpr("undefined", _NoMessages, ExpressionTypes.Access));

                foreach(var msg in exprDraft.Messages)
                    context.AppendLine(msg.CodeNotification(), null, null);

                context.AppendLine(String.Concat("const ", constant.Name.Value, " = ", exprDraft.Value, ";"),
                                   i == 0 ? stmtBounds.Start : null,
                                   i == (@this.Constants.Count - 1) ? stmtBounds.End : null);
            }

            return Unit.Value;
        }
            
        public static Unit ToJavaScript(this DoLoopStatement @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds = @this.TokenBounds();
            var indented   = context.LineIndented();

            context.AppendLine("while (true) {", stmtBounds.Start, stmtBounds.Start);
            
            @this.Statements.ProcessStatements(indented, symbols.SymbolsFor(@this));

            context.AppendLine("}", stmtBounds.End, stmtBounds.End);

            return Unit.Value;
        }

        public static Unit ToJavaScript(this DoLoopTestStatement @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds = @this.TokenBounds();
            var exprBounds = @this.Condition.TokenBounds();
            var indented   = context.LineIndented();

            context.AppendLine("do {", stmtBounds.Start, stmtBounds.Start);

            @this.Statements.ProcessStatements(indented, symbols.SymbolsFor(@this));

            var condDraft = @this.Condition.ToExprDraft(indented, symbols, ExpressionTypes.AccessBoolean);

            foreach(var msg in condDraft.Messages)
                context.AppendLine(msg.CodeNotification(), null, null);

            var condition = @this.Type == LoopTypes.While
                            ? condDraft.Value
                            : String.Concat(" ! (", condDraft.Value, ")");

            context.AppendLine(String.Concat("} while (", condition, ");"), null, exprBounds.End);

            return Unit.Value;
        }
            
        public static Unit ToJavaScript(this DoTestLoopStatement @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds = @this.TokenBounds();
            var exprBounds = @this.Condition.TokenBounds();
            var indented   = context.LineIndented();

            var condDraft  = @this.Condition.ToExprDraft(indented, symbols, ExpressionTypes.AccessBoolean);

            foreach(var msg in condDraft.Messages)
                context.AppendLine(msg.CodeNotification(), null, null);

            var condition = @this.Type == LoopTypes.While
                            ? condDraft.Value
                            : String.Concat(" ! (", condDraft.Value, ")");

            context.AppendLine(String.Concat("while (", condition, ") {"), stmtBounds.Start, exprBounds.End);

            @this.Statements.ProcessStatements(indented, symbols.SymbolsFor(@this));

            context.AppendLine("}", stmtBounds.End, stmtBounds.End);

            return Unit.Value;
        }

        public static String ToJavaScript(this EraseStatement @this, Context context, SymbolsScope symbols)
            => String.Concat(context.Fixed.ArrayEraseFunc, "(", @this.Name.Value, ");");

        public static String ToJavaScript(this ExitStatement @this, Context context, SymbolsScope symbols)
            =>   (@this.Type == ExitTypes.For) ? "break;"
               : (@this.Type == ExitTypes.Do)  ? "break;"
               : context.Level
                        .MethodAssign
                        .Match(f => f.AssignCount > 0
                                    ? String.Concat("return ", f.ReturnSymbol.SymbolName(), ";")
                                    : "return;",
                               () => "return;");
            
        public static Unit ToJavaScript(this FieldDeclaration @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds   = @this.TokenBounds();
            var inClass      = context.Level
                                      .FirstOf<ClassDeclaration>();

            for (Int32 i = 0; i < @this.Fields.Count; i++)
            {
                var variable = @this.Fields[i];
                var rankStr  = variable.ArrayRanks.Map(ranks => String.Join(", ", ranks.Select(v => v.ToJavaScript())));

                symbols.GetMember<Symbol>(variable.Name.Value)
                       .Affect(v =>
                       {
                           if (inClass is Some<ClassDeclaration>)
                               context.AppendLine(String.Concat(v.SymbolName(), ";"),
                                                  i == 0 ? stmtBounds.Start : null,
                                                  i == (@this.Fields.Count - 1) ? stmtBounds.End : null);
                          else
                               context.AppendLine(rankStr.Match(r => String.Concat("var ", v.SymbolName(), " = ", context.Fixed.ArrayCreateFunc, "(", r, ");"),
                                                                () => String.Concat("var ", v.SymbolName(), ";")),
                                                  i == 0 ? stmtBounds.Start : null,
                                                  i == (@this.Fields.Count - 1) ? stmtBounds.End : null);
                       });
            }

            return Unit.Value;
        }

        public static Unit ToJavaScript(this ForEachStatement @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds  = @this.TokenBounds();
            var exprBounds  = @this.In.TokenBounds();
            var variable    = @this.Variable.Value;
            var indented    = context.LineIndented();

            var inDraft     = @this.In.ToExprDraft(context, symbols, ExpressionTypes.Access);

            foreach(var msg in inDraft.Messages)
                context.AppendLine(msg.CodeNotification(), null, null);

            context.AppendLine(String.Concat("for (", variable, " of Global.iterateOn(", inDraft.Value, ")) {"), stmtBounds.Start, exprBounds.End);

            @this.Statements.ProcessStatements(indented, symbols.SymbolsFor(@this));

            context.AppendLine("}", stmtBounds.End, stmtBounds.End);

            return Unit.Value;
        }

        public static Unit ToJavaScript(this ForStatement @this, Context context, SymbolsScope symbols)
        {
            var stmtBounds      = @this.TokenBounds();
            var exprBounds      = @this.Step.Match(s => s.TokenBounds(), () => @this.To.TokenBounds());
            var variable        = @this.Variable.Value;
            var step            = "1";
            var stepQuantity    = Return.Try(() => Int32.Parse(step));
            var fromDraft       = @this.From.ToExprDraft(context, symbols, ExpressionTypes.Access);
            var toDraft         = @this.To.ToExprDraft(context, symbols, ExpressionTypes.Access);

            foreach(var msg in fromDraft.Messages)
                context.AppendLine(msg.CodeNotification(), null, null);
            foreach(var msg in toDraft.Messages)
                context.AppendLine(msg.CodeNotification(), null, null);

            if (@this.Step is Some<Expression> someStep)
            {
                var stepDraft = someStep.Value.ToExprDraft(context, symbols, ExpressionTypes.Access);

                step         = stepDraft.Value;
                stepQuantity = Return.Try(() => Int32.Parse(step));

                foreach(var msg in stepDraft.Messages)
                    context.AppendLine(msg.CodeNotification(), null, null);
            }

            if (stepQuantity is Confirmed<Int32> validQuantity)
            {
                var upperTest = validQuantity.Value < 0 ? " >= " : " <= ";

                if (Math.Abs(validQuantity.Value) == 1)
                    context.AppendLine(String.Concat("for (", variable, " = ", fromDraft.Value, "; ", variable, upperTest, toDraft.Value, "; ", variable, validQuantity.Value < 0 ? "--" : "++", ") {"), stmtBounds.Start, exprBounds.End);
                else
                    context.AppendLine(String.Concat("for (", variable, " = ", fromDraft.Value, "; ", variable, upperTest, toDraft.Value, "; ", variable, " += ", step, ") {"), stmtBounds.Start, exprBounds.End);
            }
            else
            {
                // this branch could produce a bad for loop
                context.AppendLine(String.Concat("for (", variable, " = ", fromDraft.Value, "; ", variable, " <= ", toDraft.Value, "; ", variable, " += ", step, ") {"), stmtBounds.Start, exprBounds.End);
            }

            @this.Statements.ProcessStatements(context.LineIndented(), symbols.SymbolsFor(@this));

            context.AppendLine("}", stmtBounds.End, stmtBounds.End);

            return Unit.Value;
        }

        public static Draft ToInlineDraft(this Statement @this, Context context, SymbolsScope symbols)
        {
            return @this switch 
            {
                AssignStatement assignStmt => assignStmt.ToDraft(context, symbols),
                CallStatement callStmt => callStmt.ToDraft(context, symbols),
                InlineCallStatement inlineCallStmt => inlineCallStmt.ToDraft(context, symbols),
                OnErrorResumeNext errResumeStmt => new Draft(errResumeStmt.ToJavaScript(context, symbols), _NoMessages),
                OnErrorGotoZero errZeroStmt => new Draft(errZeroStmt.ToJavaScript(context, symbols), _NoMessages),
                ExitStatement exitStmt => new Draft(exitStmt.ToJavaScript(context, symbols), _NoMessages),
                IfStatement ifStmt => ifStmt.ToInlineDraft(context, symbols),
                EraseStatement eraseStmt => new Draft(eraseStmt.ToJavaScript(context, symbols), _NoMessages),
                _ => Throw.UnexpectedType<Draft>(nameof(ToInlineDraft), nameof(Statement))
            };
        }

        public static Draft ToInlineDraft(this IfStatement @this, Context context, SymbolsScope symbols)
        {
            var allMsgs     = new List<String>();

            var predDraft   = @this.Predicate.ToExprDraft(context, symbols, ExpressionTypes.AccessBoolean);

            allMsgs.AddRange(predDraft.Messages);

            var consequent = new List<String>();

            foreach (var consequentDraft in @this.Consequent.Select(s => s.ToInlineDraft(context, symbols.SymbolsFor(@this))))
            {
                consequent.Add(consequentDraft.Value);
                allMsgs.AddRange(consequentDraft.Messages);
            }

            var alts = new List<String>();

            if (@this.Alternatives.Count == 1)
            {
                foreach (var altDraft in @this.Alternatives[0].Statements.Select(s => s.ToInlineDraft(context, symbols.SymbolsFor(@this.Alternatives[0]))))
                {
                    alts.Add(altDraft.Value);
                    allMsgs.AddRange(altDraft.Messages);
                }
            }

            return   @this.Alternatives.Count == 0 ? new Draft(String.Concat("if (", predDraft.Value, ") { ", String.Join(" ", consequent), " }"), allMsgs)
                   : @this.Alternatives.Count == 1 ? new Draft(String.Concat("if (", predDraft.Value, ") { ", String.Join(" ", consequent), " } else { ", String.Join(" ", alts), " }"), allMsgs)
                   : Throw.UnexpectedTree<Draft>(nameof(ToInlineDraft), nameof(IfStatement));
        }

        public static Unit ToJavaScript(this IfStatement @this, Context context, SymbolsScope symbols)
        {
            var ifBounds = @this.TokenBounds();
            var ifThen   = @this.FirstToken(Id.Symbol.Then);
            var indented = context.LineIndented();

            var predDraft = @this.Predicate.ToExprDraft(indented, symbols, ExpressionTypes.AccessBoolean);

            foreach (var msg in predDraft.Messages)
                context.AppendLine(msg.CodeNotification(), null, null);

            context.AppendLine(String.Concat("if", " (", predDraft.Value, ") {"), ifBounds.Start, ifThen);

            @this.Consequent.ProcessStatements(indented, symbols.SymbolsFor(@this));

            foreach (var alternative in @this.Alternatives)
            {
                if (alternative is ElseIfBlock elseIf)
                {
                    var elseIfBounds = elseIf.TokenBounds();
                    var elseIfThen   = elseIf.FirstToken(Id.Symbol.Then);

                    var elsePredDraft = elseIf.Predicate.ToExprDraft(indented, symbols, ExpressionTypes.AccessBoolean);

                    foreach (var err in elsePredDraft.Messages)
                        context.AppendLine(err.CodeNotification(), null, null);

                    context.AppendLine(String.Concat("} else if (", elsePredDraft.Value, ") {"), elseIfBounds.Start, elseIfThen);
                }
                else if (alternative is FinalElseBlock final)
                {
                    var finalBounds = final.TokenBounds();

                    context.AppendLine("} else {", finalBounds.Start, finalBounds.Start); // only one Vbs token ("else")
                }
                else
                {
                    Throw.UnexpectedType<String>(nameof(ToJavaScript), nameof(IfStatement));
                }

                alternative.Statements.ProcessStatements(indented, symbols.SymbolsFor(alternative));
            }

            if (   ifBounds.End != null
                && ifBounds.End.Value.Id.Equals(Id.Symbol.If)
                && ifBounds.EndMinusOne != null
                && ifBounds.EndMinusOne.Value.Id.Equals(Id.Symbol.End))
            {
                context.AppendLine("}", ifBounds.EndMinusOne, ifBounds.End);
            }
            else
            {
                context.AppendLine("}", null, null);
            }

            return Unit.Value;
        }

        public static Draft ToDraft(this InlineCallStatement @this, Context context, SymbolsScope symbols)
        {
            if (context.Fixed.CustomToJs.Message(@this, context, symbols) is Some<String> someMsg)
                context.AppendLine(someMsg.Value.CodeNotification(), null, null);

            return @this.AccessExpression.ToExprDraft(context, symbols, ExpressionTypes.Execute)
                        .Make(v => new Draft(String.Concat(v.Value, ";"), v.Messages));
        }
            
        public static String ToJavaScript(this OnErrorGotoZero @this, Context context, SymbolsScope symbols)
            => "ON ERROR GOTO ZERO not translated".CodeNotification();
            
        public static String ToJavaScript(this OnErrorResumeNext @this, Context context, SymbolsScope symbols)
            => "ON ERROR RESUME NEXT not translated".CodeNotification();

        public static String ToJavaScript(this OptionExplicitStatement @this, Context context, SymbolsScope symbols)
            => "OPTION EXPLICIT not translated".CodeNotification("Info");

        public static Unit ToJavaScript(this RedimStatement @this, Context context, SymbolsScope symbols)
        {
            var redimBounds = @this.TokenBounds();
            var inClass     = context.Level
                                     .FirstOf<ClassDeclaration>();

            for (Int32 i = 0; i < @this.Variables.Count; i++)
            {
                var variable = @this.Variables[i];
                var ranks    = new List<String>();
                var allMsgs  = new List<String>();

                foreach (var rankDraft in variable.RankExpressions.Select(re => re.ToExprDraft(context, symbols, ExpressionTypes.Access)))
                {
                    ranks.Add(rankDraft.Value);
                    allMsgs.AddRange(rankDraft.Messages);
                }

                var foundSymbol = symbols.FindBaseSymbol(variable.Name.Value, _AllScopes);

                // See if the found symbol context is pointing to a ClassSymbol
                var thisPrefix  = foundSymbol.Bind(f => f.Scope.As<ClassSymbol>())                            // is a found class symbol?
                                             .Bind(c => inClass.Map(i => i.Name.Value.DataEquals(c.Name)      // we are defining this class?
                                                                         ? "this."
                                                                         : ""))
                                             .Or("");

                foreach (var rankErr in allMsgs)
                    context.AppendLine(rankErr.CodeNotification(), null, null);

                foundSymbol.Affect(f =>
                {
                    if (f.Symbol is HardSymbol hard && hard.ErrMessage is Some<String> someMessage)
                        context.AppendLine(someMessage.Value.CodeNotification(), null, null);
                });

                if (@this.Preserve)
                {
                    var symName = foundSymbol.Map(f => String.Concat(thisPrefix, f.Symbol.SymbolName())).Or(variable.Name.Value);

                    context.AppendLine(String.Concat(symName, " = ", context.Fixed.ArrayResizeFunc, "(", symName, ", ", String.Join(", ", ranks), ");"),
                                       i == 0 ? redimBounds.Start : null,
                                       i == (@this.Variables.Count -1) ? redimBounds.End : null);
                }
                else
                {
                    var makeVar =    (foundSymbol is None<FoundSymbol>)
                                  || (foundSymbol is Some<FoundSymbol> someCheck && someCheck.Value.Symbol is RedimSymbol)
                                  ? "var "
                                  : String.Empty;

                    context.AppendLine(String.Concat(makeVar, foundSymbol.Map(f => String.Concat(thisPrefix, f.Symbol.SymbolName())).Or(variable.Name.Value), " = ", context.Fixed.ArrayCreateFunc, "(", String.Join(", ", ranks), ");"),
                                       i == 0 ? redimBounds.Start : null,
                                       i == (@this.Variables.Count - 1) ? redimBounds.End : null);
                }

                context.RecordSymbolStat(variable.Name.Value,
                                         true,
                                         foundSymbol);
            }

            return Unit.Value;
        }

        public static Unit ToJavaScript(this SelectStatement @this, Context context, SymbolsScope symbols)
        {
            var caseBounds = @this.TokenBounds();
            var exprBounds = @this.Value.TokenBounds();
            var caseLevel  = context.LineIndented();
            var stmtLevel  = caseLevel.LineIndented();

            var valueDraft = @this.Value.ToExprDraft(context, symbols, ExpressionTypes.Access);

            foreach (var valueMsg in valueDraft.Messages)
                context.AppendLine(valueMsg.CodeNotification(), null, null);

            context.AppendLine(String.Concat("switch (", valueDraft.Value, ") {"), caseBounds.Start, exprBounds.End);

            foreach (var @case in @this.Cases)
            {
                if (@case is SelectCaseWhen caseWhen)
                {
                    var whenBounds = caseWhen.TokenBounds();
                    var valsBounds = caseWhen.When.TokenBounds();

                    for (Int32 i = 0; i < caseWhen.When.Count; i++)
                    {
                        var whenDraft = caseWhen.When[i].ToExprDraft(caseLevel, symbols, ExpressionTypes.Access);

                        foreach (var whenMsg in whenDraft.Messages)
                            caseLevel.AppendLine(whenMsg.CodeNotification(), null, null);

                        caseLevel.AppendLine(String.Concat("case ", whenDraft.Value, ":"),
                                             i == 0 ? whenBounds.Start : null,
                                             i == (caseWhen.When.Count - 1) ? valsBounds.End : null);
                    }
                    
                    caseWhen.Statements.ProcessStatements(stmtLevel, symbols.SymbolsFor(caseWhen));

                    stmtLevel.AppendLine("break;", null, null);
                }
                else if (@case is SelectCaseElse caseElse)
                {
                    var elseBounds = caseElse.TokenBounds();

                    caseLevel.AppendLine("default:", elseBounds.Start, null);

                    caseElse.Statements.ProcessStatements(stmtLevel, symbols.SymbolsFor(caseElse));
                }
            }

            context.AppendLine("}", caseBounds.EndMinusOne, caseBounds.End);

            return Unit.Value;
        }

        public static Unit ToJavaScript(this VariableDeclaration @this, Context context, SymbolsScope symbols)
        {
            // NOTE: This function is actually only called from ToJavaScript on a ClassDeclaration.
            var stmtBounds   = @this.TokenBounds();
            var classDecl    = context.Level
                                      .FirstOf<ClassDeclaration>();

            for (Int32 i = 0; i < @this.Variables.Count; i++)
            {
                var variable = @this.Variables[i];
                var rankStr  = variable.ArrayRanks.Map(ranks => String.Join(", ", ranks.Select(v => v.ToJavaScript())));

                symbols.GetMember<Symbol>(variable.Name.Value)
                       .Affect(v =>
                       {
                           if (classDecl is Some<ClassDeclaration>)
                               context.AppendLine(String.Concat(v.SymbolName(), ";"),
                                                  i == 0 ? stmtBounds.Start : null,
                                                  i == (@this.Variables.Count - 1) ? stmtBounds.End : null);
                          else
                               context.AppendLine(rankStr.Match(r => String.Concat("var ", v.SymbolName(), " = ", context.Fixed.ArrayCreateFunc, "(", r, ");"),
                                                                () => String.Concat("var ", v.SymbolName(), ";")),
                                                  i == 0 ? stmtBounds.Start : null,
                                                  i == (@this.Variables.Count - 1) ? stmtBounds.End : null);
                       });
            }

            return Unit.Value;
        }

        public static Unit ToJavaScript(this WhileStatement @this, Context context, SymbolsScope symbols)
        {
            var whileBounds = @this.TokenBounds();
            var condBounds  = @this.Condition.TokenBounds();
            var indented    = context.LineIndented();

            var condDraft   = @this.Condition.ToExprDraft(context, symbols, ExpressionTypes.AccessBoolean);

            foreach (var condMsg in condDraft.Messages)
                context.AppendLine(condMsg.CodeNotification(), null, null);

            context.AppendLine(String.Concat("while", " (", condDraft.Value, ") {"), whileBounds.Start, condBounds.End);

            @this.Statements.ProcessStatements(indented, symbols.SymbolsFor(@this));

            context.AppendLine("}", whileBounds.End, whileBounds.End);

            return Unit.Value;
        }

        public static Unit ToJavaScript(this WithStatement @this, Context context, SymbolsScope symbols)
        {
            var inWith      = context.Level.FirstOf<WithStatement>().Map(w => true).Or(false);
            var thisContext = context.NextContext(@this, inWith ? context.Level.WithLevel.NewLevel() : context.Level.WithLevel, context.Level.MethodAssign);
            var withLevel   = thisContext.Level.WithLevel;

            var withBounds  = @this.TokenBounds();
            var exprBounds  = @this.Expression.TokenBounds();

            var exprDraft   = @this.Expression.ToExprDraft(context, symbols, ExpressionTypes.Access);

            foreach (var exprMsg in exprDraft.Messages)
                context.AppendLine(exprMsg.CodeNotification(), null, null);

            withLevel.IncrementName(@this.Expression.CreateObjectType().Map(t => t.StartsWith("\"")).Or(false));
            thisContext.AppendLine(String.Concat("var ", withLevel.CurrentName, " = ", exprDraft.Value, ";"), withBounds.Start, exprBounds.End);

            @this.Statements.ProcessStatements(thisContext, symbols.SymbolsFor(@this));

            context.AppendLine(String.Empty, withBounds.EndMinusOne, withBounds.End);

            return Unit.Value;
        }

        private static Option<SyntaxToken> LeadToken(this Statement @this)
            => @this.Node.Match(n => n.Tokens().FirstOrNone(), Option.None);

        private static Unit ToJavaScriptFromInline(this CodeNode @this, Draft inline, Context context, SymbolsScope symbols)
        {
            foreach (var msg in inline.Messages)
                context.AppendLine(msg.CodeNotification(), null, null);

            var bnds = @this.TokenBounds();

            context.AppendLine(inline.Value, bnds.Start, bnds.End);

            return Unit.Value;
        }

        public static Unit ToJavaScript(this Statement @this, Context context, SymbolsScope symbols)
        {
            var result =   @this is AssignStatement assign ? assign.ToJavaScriptFromInline(assign.ToDraft(context, symbols), context, symbols)
                         : @this is CallStatement call ? call.ToJavaScriptFromInline(call.ToDraft(context, symbols), context, symbols)
                         : @this is ClassDeclaration @class ? @class.ToJavaScript(context, symbols)
                         : @this is ConstantDeclaration constant ? constant.ToJavaScript(context, symbols)
                         : @this is ConstantStatement constStmt ? constStmt.ToJavaScript(context, symbols)
                         : @this is DoLoopStatement doloop ? doloop.ToJavaScript(context, symbols)
                         : @this is DoLoopTestStatement dolooptest ? dolooptest.ToJavaScript(context, symbols)
                         : @this is DoTestLoopStatement dotestloop ? dotestloop.ToJavaScript(context, symbols)
                         : @this is EraseStatement erase ? erase.TokenBounds().Make(bnds => context.AppendLine(erase.ToJavaScript(context, symbols), bnds.Start, bnds.End))
                         : @this is ExitStatement exit ? exit.TokenBounds().Make(bnds => context.AppendLine(exit.ToJavaScript(context, symbols), bnds.Start, bnds.End))
                         : @this is FieldDeclaration field ? field.ToJavaScript(context, symbols)
                         : @this is ForEachStatement @foreach ? @foreach.ToJavaScript(context, symbols)
                         : @this is ForStatement @for ? @for.ToJavaScript(context, symbols)
                         : @this is IfStatement ifInline && ifInline.Node.Match(n => n.Id == Id.Rule.InlineIfStmt, false) ? ifInline.ToJavaScriptFromInline(ifInline.ToInlineDraft(context, symbols), context, symbols)
                         : @this is IfStatement @if ? @if.ToJavaScript(context, symbols)
                         : @this is InlineCallStatement inline ? inline.ToJavaScriptFromInline(inline.ToInlineDraft(context, symbols), context, symbols)
                         : @this is MethodDeclaration method ? method.ToJavaScript(context, symbols)
                         : @this is OnErrorGotoZero gotozero ? gotozero.TokenBounds().Make(bnds => context.AppendLine(gotozero.ToJavaScript(context, symbols), bnds.Start, bnds.End))
                         : @this is OnErrorResumeNext resumenext ? resumenext.TokenBounds().Make(bnds => context.AppendLine(resumenext.ToJavaScript(context, symbols), bnds.Start, bnds.End))
                         : @this is OptionExplicitStatement optExplicit ? optExplicit.TokenBounds().Make(bnds => context.AppendLine(optExplicit.ToJavaScript(context, symbols), bnds.Start, bnds.End))
                         : @this is RedimStatement redim ? redim.ToJavaScript(context, symbols)
                         : @this is SelectStatement select ? select.ToJavaScript(context, symbols)
                         : @this is VariableDeclaration variable ? variable.ToJavaScript(context, symbols)
                         : @this is WhileStatement @while ? @while.ToJavaScript(context, symbols)
                         : @this is WithStatement with  ? with.ToJavaScript(context, symbols)
                         : Throw.UnexpectedType<Unit>(nameof(ToJavaScript), nameof(Statement));

            return result;
        }

        public static Unit ProcessStatements(this IReadOnlyList<Statement> @this, Context context, SymbolsScope symbols)
        {
            // rule: variables from a variable declaration statement can only be held
            // when the very next statement assigns one of the remaining variables in
            // prevVars (prevNext points to the start of those remaining variables)
            var prevVars  = new List<Variable>();
            var prevNext  = 0;
            var prevBnds  = (Start: (SyntaxToken?)null, End: (SyntaxToken?)null, StartPlusOne: (SyntaxToken?)null, EndMinusOne: (SyntaxToken?)null);

            void CheckClearPrev()
            {
                if (!(prevNext < prevVars.Count))
                {
                    prevVars.Clear();
                    prevNext = 0;
                    prevBnds.Start = null;
                    prevBnds.End = null;
                }
            }

            void CheckFinishPrev()
            {
                while (prevNext < prevVars.Count)
                {
                    var rankStr = prevVars[prevNext].ArrayRanks.Map(ranks => String.Join(", ", ranks.Select(v => v.ToJavaScript())));

                    context.AppendLine(rankStr.Match(r => String.Concat("var ", prevVars[prevNext].Name.Value, " = ", context.Fixed.ArrayCreateFunc,"(", r, ");"),
                                                     () => String.Concat("var ", prevVars[prevNext].Name.Value, ";")),
                                       prevNext == 0 ? prevBnds.Start : null,
                                       prevNext == (prevVars.Count - 1) ? prevBnds.End : null);

                    prevNext++;
                }

                CheckClearPrev();
            }

            foreach (var stmt in @this)
            {
                if (stmt is AssignStatement assignStmt)
                {
                    var assignBnds  = assignStmt.TokenBounds();
                    var assignsThis = prevVars.Skip(prevNext).FirstOrNone(v => assignStmt.AssignsThis(v.Name));
                    var assignDone  = false;

                    while (prevNext < prevVars.Count && !assignDone) // go until no more left or assign is done
                    {
                        var rankStr = prevVars[prevNext].ArrayRanks.Map(ranks => String.Join(", ", ranks.Select(v => v.ToJavaScript())));

                        if (rankStr is Some<String> someRanks)
                        {
                            context.AppendLine(String.Concat("var ", prevVars[prevNext].Name.Value, " = ", context.Fixed.ArrayCreateFunc, "(", someRanks.Value, ");"),
                                               prevNext == 0 ? prevBnds.Start : null,
                                               prevNext == (prevVars.Count - 1) ? prevBnds.End : null);
                        }
                        else if (assignsThis is Some<Variable> someVar && someVar.Value.Equals(prevVars[prevNext]))
                        {
                            var rightDraft = assignStmt.Right.ToExprDraft(context, symbols, ExpressionTypes.Access);

                            foreach (var rightMsg in rightDraft.Messages)
                                context.AppendLine(rightMsg.CodeNotification(), null, null);

                            context.AppendLine(String.Concat("var ", someVar.Value.Name.Value, " = ", rightDraft.Value, ";"),
                                               prevNext == 0 ? prevBnds.Start : null,
                                               prevNext == (prevVars.Count - 1) ? assignBnds.End : null);

                            assignDone = true;
                        }
                        else
                        {
                            context.AppendLine(String.Concat("var ", prevVars[prevNext].Name.Value, ";"),
                                               prevNext == 0 ? prevBnds.Start : null,
                                               prevNext == (prevVars.Count - 1) ? prevBnds.End : null);
                        }

                        prevNext++;
                    }

                    if (!assignDone) // no assignment done? still have to do it
                    {
                        var assnDraft = assignStmt.ToDraft(context, symbols);

                        foreach (var err in assnDraft.Messages)
                            context.AppendLine(err.CodeNotification(), null, null);

                        context.AppendLine(assnDraft.Value, assignBnds.Start, assignBnds.End);
                    }

                    CheckClearPrev();
                }
                else if (stmt is VariableDeclaration varDecl)
                {
                    // finish previous if necessary
                    CheckFinishPrev();

                    // save var info for later
                    prevVars.AddRange(varDecl.Variables);
                    prevNext = 0;
                    prevBnds = varDecl.TokenBounds();
                }
                else // not a variable declaration or assignment statement
                {
                    // finish previous if necessary
                    CheckFinishPrev();

                    // forward statement to appropriate processing function
                    stmt.ToJavaScript(context, symbols);
                }
            }

            // just in case
            CheckFinishPrev();

            return Unit.Value;
        }

        public static Unit ToJavaScript(this Program @this, Context context, SymbolsScope symbols)
        {
            @this.Statements.ProcessStatements(context, symbols);

            // write any left over trivia
            var trivia  = context.Fixed.Trivia;
            var current = trivia.Position;

            while (current < trivia.Count)
            {
                context.WriteLine(trivia.Text(current));
                current++;
            }

            return Unit.Value;
        }
    
    }

}