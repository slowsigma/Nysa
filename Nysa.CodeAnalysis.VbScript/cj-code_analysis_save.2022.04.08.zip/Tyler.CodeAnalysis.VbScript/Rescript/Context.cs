using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.Logics;
using Nysa.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public struct Context
    {
        public static IReadOnlyDictionary<String, String> CreateEmptyAssignedTypes() => new Dictionary<String, String>();
        public static IReadOnlySet<String> CreateEmptyComIncidentals() => new HashSet<String>();

        public static readonly String STANDARD_INDENT = "  ";

        public ContextFixed                         Fixed           { get; private set; }
        public Action<String>                       WriteLine       { get; private set; }
        public ContextLevel                         Level           { get; private set; }
        public IReadOnlyDictionary<String, String>  AssignedTypes   { get; private set; }
        public IReadOnlySet<String>                 ComIncidentals  { get; private set; }

        public Context(ContextFixed @fixed, Action<String> writeLine, ContextLevel level)
        {
            this.Fixed          = @fixed;
            this.WriteLine      = writeLine;
            this.Level          = level;
            this.AssignedTypes  = Context.CreateEmptyAssignedTypes();
            this.ComIncidentals = Context.CreateEmptyComIncidentals();
        }

        public Context(ContextFixed @fixed, Action<String> writeLine, ContextLevel level, IReadOnlyDictionary<String, String> assignedTypes, IReadOnlySet<String> comIncidentals)
        {
            this.Fixed          = @fixed;
            this.WriteLine      = writeLine;
            this.Level          = level;
            this.AssignedTypes  = assignedTypes;
            this.ComIncidentals = comIncidentals;
        }
    }

}
