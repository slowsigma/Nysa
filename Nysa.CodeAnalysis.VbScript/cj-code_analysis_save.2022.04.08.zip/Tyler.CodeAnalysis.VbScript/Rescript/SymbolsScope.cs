using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    /// <summary>
    /// SymbolsScope wraps any object of ISymbolScope and provides a link to
    /// the previous ISymbolScope that either contains this or would take
    /// precedence in a symbol search after this.
    /// </summary>
    public record SymbolsScope : ISymbolScope
    {
        public Option<SymbolsScope>         Previous    { get; init; }
        public ISymbolScope                 Value       { get; init; }

        public IReadOnlySet<String>         Tags        => this.Value.Tags;
        public IReadOnlyList<Symbol>        Members     => this.Value.Members;
        public IDictionary<String, Symbol>  Index       => this.Value.Index;

        public Option<T> As<T>()
            where T : ISymbolScope
            => this.Value is T asT ? asT.Some() : Option<T>.None;

        public Option<T> GetMember<T>(String name)
            where T : Symbol
            => this.Value.Member<T>(name);

        public IEnumerable<T> GetMembers<T>()
            where T : Symbol
            => this.Members.Where(m => m is T).Select(v => (T)v);

        public SymbolsScope(Option<SymbolsScope> previous, ISymbolScope value)
        {
            this.Previous   = previous;
            this.Value      = value;
        }

        public SymbolsScope MemberScope(ISymbolScope member)
            => new SymbolsScope(this.Some(), member);
    }

}