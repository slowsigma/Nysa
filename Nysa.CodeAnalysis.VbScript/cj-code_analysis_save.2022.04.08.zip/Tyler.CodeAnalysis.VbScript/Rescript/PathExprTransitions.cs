using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using Dorata.Text.Parsing;
using SyntaxToken = Dorata.Text.Lexing.Token;
using SyntaxNode  = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class PathExprTransitions
    {
        public static readonly IReadOnlySet<PathExprStates> DotFromStates = new HashSet<PathExprStates>()
        {
            PathExprStates.variable,
            PathExprStates.function,
            PathExprStates.property,
            PathExprStates.arrayArgs,
            PathExprStates.funcArgs
        };

        public static readonly IReadOnlySet<PathExprStates> DotToStates = new HashSet<PathExprStates>()
        {
            PathExprStates.variable,
            PathExprStates.function,
            PathExprStates.property
        };

    }

}