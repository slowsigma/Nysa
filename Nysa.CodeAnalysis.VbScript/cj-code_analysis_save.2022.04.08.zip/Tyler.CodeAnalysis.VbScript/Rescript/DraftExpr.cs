using System;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    // Note: The Type property here strictly represents what was created.
    public record DraftExpr(String Value, List<String> Messages, ExpressionTypes Type) : Draft(Value, Messages);

}