using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using HtmlAgilityPack;


namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class SemanticTreeFunctions
    {
        public static Option<(PathIdentifier Call, PathArguments Args)> FinalCall(this PathExpression @this)
            => @this.Count > 1
               ? (Call: @this[@this.Count - 2] as PathIdentifier, Args: @this[@this.Count - 1] as PathArguments)
                 .Make(fc => fc.Call == null || fc.Args == null
                             ? Option.None
                             : ((PathIdentifier)fc.Call, (PathArguments)fc.Args).Some())
               : Option.None;

        public static Option<String> LeftSingleId(this AssignStatement @this)
            =>    @this.Left is PathExpression path
               && path.Count == 1
               && path[0] is PathIdentifier pathId
               ? pathId.Value.Some()
               : Option.None;

        public static Option<String> CreateObjectType(this Expression @this)
            => @this is PathExpression path
               ? path.FinalCall().Bind(fc => (   fc.Call.Value.DataEquals("createobject")
                                              && fc.Args.Count > 0
                                              && fc.Args[0] is LiteralValue lit)
                                             ? lit.Value.Some()
                                             : Option.None)
               : Option.None;


        /// <summary>
        /// Return true if the final method call in the expression has the given name. Note that
        /// expression be a method call (i.e., not a property access).
        /// </summary>
        /// <param name="this"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static Boolean EndsInCallTo(this Expression @this, String name)
            => @this is PathExpression path && path.FinalCall().Map(fc => fc.Call.Value.DataEquals(name)).Or(false);

        public static Boolean EndsInCall(this Expression @this)
            => @this is PathExpression path && path.FinalCall().Map(fc => true).Or(false);

        public static Boolean IsNotLiteral(this Expression @this)
            => !(@this is LiteralValue);

        public static Option<String> RightCreateObjectType(this AssignStatement @this)
            => @this.Right.CreateObjectType();

        public static Boolean HasFinalSelectNodesCall(this Expression @this)
            => @this is PathExpression path && path.FinalCall().Map(fc => fc.Call.Value.DataEquals("selectnodes")).Or(false);

        public static Boolean FinalSelectNodesCall(this AssignStatement @this)
            => @this.Right.EndsInCallTo("selectnodes");

        public static Boolean FinalSelectSingleNodeCall(this AssignStatement @this)
            => @this.Right.EndsInCallTo("selectsinglenode");

        public static Option<String> RightNewObjectType(this AssignStatement @this)
            => @this.Right is NewObjectExpression newObj && newObj.Object is PathExpression path && path.Count == 1 && path[0] is PathIdentifier pid
               ? pid.Value.Some()
               : Option.None;

        public static Option<String> RightStartId(this AssignStatement @this)
            => @this.Right is PathExpression path && path.Count > 0 && path[0] is PathIdentifier pid
               ? pid.Value.Some()
               : Option.None;

    }

}