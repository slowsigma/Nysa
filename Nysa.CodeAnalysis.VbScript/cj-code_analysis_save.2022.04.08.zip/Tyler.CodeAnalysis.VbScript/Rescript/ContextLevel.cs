using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.Logics;
using Nysa.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public record MethodAssignInfo(Int32 AssignCount, VariableSymbol ReturnSymbol);

    public record ContextLevel(
        Option<ContextLevel> Prior,
        CodeNode CodeLevel,                     // only Program, ClassDeclaration, MethodDeclaration, or WithStatement
        WithLevel WithLevel,
        Option<MethodAssignInfo> MethodAssign
    );

}