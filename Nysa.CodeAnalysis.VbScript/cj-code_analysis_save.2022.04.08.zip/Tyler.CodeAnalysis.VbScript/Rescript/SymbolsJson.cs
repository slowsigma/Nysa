using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class SymbolsJson
    {
        private static readonly String _type = "_type";

        public static class Types
        {
            public static readonly String Argument = "Argument";
            public static readonly String Class = "Class";
            public static readonly String Constant = "Constant";
            public static readonly String Function = "Function";
            public static readonly String PropertyGet = "PropertyGet";
            public static readonly String PropertySet = "PropertySet";
            public static readonly String Property = "Property";
            public static readonly String Variable = "Variable";
        }

        //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\ WRITING //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\
        private static readonly KeyValuePair<String, JsonNode?>? NullKeyPair = null;
        private static KeyValuePair<String, JsonNode?> ToProperty(this String @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, JsonValue.Create(@this));
        private static KeyValuePair<String, JsonNode?> ToProperty(this Int32 @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, JsonValue.Create(@this));
        private static KeyValuePair<String, JsonNode?> ToProperty(this Boolean @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, JsonValue.Create(@this));
        private static KeyValuePair<String, JsonNode?> ToProperty(this IReadOnlyList<Symbol> @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, new JsonArray(@this.Select(s => s.ToJson()).ToArray()));
        private static KeyValuePair<String, JsonNode?> ToProperty(this IReadOnlyList<ScriptSymbols> @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, new JsonArray(@this.Select(s => s.ToJson()).ToArray()));
        private static KeyValuePair<String, JsonNode?> ToProperty(this IReadOnlySet<String> @this, String name)
            => new KeyValuePair<String, JsonNode?>(name, new JsonArray(@this.Select(s => (JsonNode?)s).ToArray()));
        private static KeyValuePair<String, JsonNode?> ToProperty(this Symbol @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, @this.ToJson());

        private static IEnumerable<KeyValuePair<String, JsonNode?>> WithProperties(params KeyValuePair<String, JsonNode?>?[] items)
            => items.Where(i => i.HasValue).Select(v => v.Value);

        private static JsonObject ToJson(this ArgumentSymbol @this)
            => new JsonObject(WithProperties(Types.Argument.ToProperty(_type),
                                             @this.Name.ToProperty(nameof(ArgumentSymbol.Name)),
                                             @this.NewName.Match(s => s.ToProperty(nameof(ArgumentSymbol.NewName)), NullKeyPair),
                                             @this.TypeName.Match(t => t.ToProperty(nameof(ArgumentSymbol.TypeName)), NullKeyPair)));

        private static JsonObject ToJson(this ClassSymbol @this)
            => new JsonObject(WithProperties(Types.Class.ToProperty(_type),
                                             @this.Name.ToProperty(nameof(ClassSymbol.Name)),
                                             @this.NewName.Match(n => n.ToProperty(nameof(ClassSymbol.NewName)), NullKeyPair),
                                             @this.ErrMessage.Match(e => e.ToProperty(nameof(ClassSymbol.ErrMessage)), NullKeyPair),
                                             @this.Default.Match(d => d.Name.ToProperty(nameof(ClassSymbol.Default)), NullKeyPair),
                                             @this.Members.ToProperty(nameof(ClassSymbol.Members)),
                                             @this.Tags.ToProperty(nameof(ClassSymbol.Tags))));

        private static JsonObject ToJson(this ConstantSymbol @this)
            => new JsonObject(WithProperties(Types.Constant.ToProperty(_type),
                                             @this.Name.ToProperty(nameof(ConstantSymbol.Name)),
                                             @this.NewName.Match(n => n.ToProperty(nameof(ConstantSymbol.NewName)), NullKeyPair),
                                             @this.ErrMessage.Match(e => e.ToProperty(nameof(ConstantSymbol.ErrMessage)), NullKeyPair),
                                             @this.IsPublic.ToProperty(nameof(ConstantSymbol.IsPublic)),
                                             @this.TypeName.Match(t => t.ToProperty(nameof(ConstantSymbol.TypeName)), NullKeyPair)));

        private static JsonObject ToJson(this FunctionSymbol @this)
            => new JsonObject(WithProperties(Types.Function.ToProperty(_type),
                                             @this.Name.ToProperty(nameof(FunctionSymbol.Name)),
                                             @this.NewName.Match(n => n.ToProperty(nameof(FunctionSymbol.NewName)), NullKeyPair),
                                             @this.ErrMessage.Match(e => e.ToProperty(nameof(FunctionSymbol.ErrMessage)), NullKeyPair),
                                             @this.IsPublic.ToProperty(nameof(FunctionSymbol.IsPublic)),
                                             @this.TypeName.Match(t => t.ToProperty(nameof(FunctionSymbol.TypeName)), NullKeyPair),
                                             @this.Members.ToProperty(nameof(FunctionSymbol.Members))));

        private static JsonObject ToJson(this PropertySymbol @this)
            => new JsonObject(WithProperties(Types.Property.ToProperty(_type),
                                             @this.Name.ToProperty(nameof(PropertySymbol.Name)),
                                             @this.Getter.Match(g => g.ToProperty(nameof(PropertySymbol.Getter)), NullKeyPair),
                                             @this.Setter.Match(s => s.ToProperty(nameof(PropertySymbol.Setter)), NullKeyPair)));

        private static JsonObject ToJson(this PropertyGetSymbol @this)
            => new JsonObject(WithProperties(Types.PropertyGet.ToProperty(_type),
                                             @this.Name.ToProperty(nameof(PropertyGetSymbol.Name)),
                                             @this.IsPublic.ToProperty(nameof(PropertyGetSymbol.IsPublic)),
                                             @this.TypeName.Match(t => t.ToProperty(nameof(PropertyGetSymbol.TypeName)), NullKeyPair),
                                             @this.Members.ToProperty(nameof(PropertyGetSymbol.Members))));

        private static JsonObject ToJson(this PropertySetSymbol @this)
            => new JsonObject(WithProperties(Types.PropertySet.ToProperty(_type),
                                             @this.Name.ToProperty(nameof(PropertySetSymbol.Name)),
                                             @this.IsPublic.ToProperty(nameof(PropertySetSymbol.IsPublic)),
                                             @this.TypeName.Match(t => t.ToProperty(nameof(PropertySetSymbol.TypeName)), NullKeyPair),
                                             @this.Members.ToProperty(nameof(PropertySetSymbol.Members))));

        private static JsonObject ToJson(this VariableSymbol @this)
            => new JsonObject(WithProperties(Types.Variable.ToProperty(_type),
                                             @this.Name.ToProperty(nameof(VariableSymbol.Name)),
                                             @this.NewName.Match(n => n.ToProperty(nameof(VariableSymbol.NewName)), NullKeyPair),
                                             @this.ErrMessage.Match(e => e.ToProperty(nameof(VariableSymbol.ErrMessage)), NullKeyPair),
                                             @this.IsPublic.ToProperty(nameof(VariableSymbol.IsPublic)),
                                             @this.TypeName.Match(c => c.ToProperty(nameof(VariableSymbol.TypeName)), NullKeyPair)));

        private static JsonObject? ToJson(this Symbol @this)
            => @this switch
            {
                ArgumentSymbol argSymbol => argSymbol.ToJson(),
                ClassSymbol classSymbol => classSymbol.ToJson(),
                ConstantSymbol constSymbol => constSymbol.ToJson(),
                PropertyGetSymbol propGetSymbol => propGetSymbol.ToJson(), // subtype, must go before FunctionSymbol
                PropertySetSymbol propSetSymbol => propSetSymbol.ToJson(), // subtype, must go before FunctionSymbol
                FunctionSymbol funcSymbol => funcSymbol.ToJson(),
                PropertySymbol propSymbol => propSymbol.ToJson(),
                VariableSymbol varSymbol => varSymbol.ToJson(),
                RedimSymbol => null,
                BlockSymbol => null,
                _ => throw new Exception("Unexpected type.")
            };

        public static JsonObject ToJson(this ScriptSymbols @this)
            => new JsonObject(WithProperties(@this.Members.ToProperty(nameof(ScriptSymbols.Members)),
                                             @this.Tags.ToProperty(nameof(ScriptSymbols.Tags))));

        public static Unit WriteJson(this ScriptSymbols @this, String filePath)
            => @this.ToJson()
                    .ToJsonString(new JsonSerializerOptions() { WriteIndented = true })
                    .Affect(j => { File.WriteAllText(filePath, j); });

        //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\ READING //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\
        private static Option<JsonNode> GetProperty(this JsonObject @this, String name)
        {
            var node = (JsonNode?)null;

            return @this.TryGetPropertyValue(name, out node) && node != null
                   ? node.Some<JsonNode>()
                   : Option<JsonNode>.None;
        }

        private static IEnumerable<JsonObject?> GetObjectArray(this JsonObject @this, String propertyName)
            => @this[propertyName] is JsonArray array
               ? array.Select(e => e as JsonObject).Where(o => o != null)
               : new JsonObject[] { };

        private static IEnumerable<String> GetStringArray(this JsonObject @this, String propertyName)
        {
            if (@this[propertyName] is JsonArray array)
            {
                foreach (var str in array.Select(v => (String?)v))
                    if (str != null)
                        yield return str;
            }
            else
                yield break;
        }


        private static Option<String> GetSymbolType(this JsonObject @this)
            => @this.GetProperty(_type).Map(n => n.GetValue<String>());

        private static String GetName(this JsonObject @this)
            => @this.GetProperty(nameof(Symbol.Name)).Match(n => n.GetValue<String>(), String.Empty);
        private static Option<String> GetNewName(this JsonObject @this)
            => @this.GetProperty(nameof(HardSymbol.NewName)).Match(n => n.GetValue<String>().Some(), Option<String>.None);
        private static Option<String> GetErrMessage(this JsonObject @this)
            => @this.GetProperty(nameof(HardSymbol.ErrMessage)).Match(n => n.GetValue<String>().Some(), Option<String>.None);
        private static Option<String> GetDefault(this JsonObject @this)
            => @this.GetProperty(nameof(ClassSymbol.Default)).Match(n => n.GetValue<String>().Some(), Option<String>.None);
        private static Option<Boolean> GetIsPublic(this JsonObject @this)
            => @this.GetProperty(nameof(MemberSymbol.IsPublic)).Match(n => n.GetValue<Boolean>().Some(), Option<Boolean>.None);
        private static Option<String> GetTypeName(this JsonObject @this)
            => @this.GetProperty(nameof(TypedSymbol.TypeName)).Match(n => n.GetValue<String>().Some(), Option<String>.None);

        private static List<Symbol> GetMemberSymbols(this JsonObject @this)
            => @this.GetObjectArray(nameof(ClassSymbol.Members))
                    .SomeOnly()
                    .Select(m => m.ToSymbol())
                    .ToList();

        private static ArgumentSymbol ToArgumentSymbol(this JsonObject @this)
            => new ArgumentSymbol(@this.GetName(), @this.GetNewName(), @this.GetTypeName());

        private static ClassSymbol ToClassSymbol(this JsonObject @this)
            => @this.GetMemberSymbols()
                    .Make(m => new ClassSymbol(@this.GetName(), @this.GetNewName(), @this.GetErrMessage(), m, @this.GetDefault().Bind(d => m.FirstOrNone(m => m.Name.DataEquals(d))), @this.GetStringArray(nameof(ClassSymbol.Tags)).ToArray()));
        
        private static ConstantSymbol ToConstantSymbol(this JsonObject @this)
            => new ConstantSymbol(@this.GetName(), @this.GetNewName(), @this.GetErrMessage(), @this.GetIsPublic().Or(true), @this.GetTypeName());

        private static FunctionSymbol ToFunctionSymbol(this JsonObject @this)
            => new FunctionSymbol(@this.GetName(), @this.GetNewName(), @this.GetErrMessage(), @this.GetIsPublic().Or(true), @this.GetTypeName(), @this.GetMemberSymbols());

        private static PropertyGetSymbol ToPropertyGetSymbol(this JsonObject @this)
            => new PropertyGetSymbol(@this.GetName(), @this.GetIsPublic().Or(true), @this.GetTypeName(), @this.GetMemberSymbols());
        private static PropertySetSymbol ToPropertySetSymbol(this JsonObject @this)
            => new PropertySetSymbol(@this.GetName(), @this.GetIsPublic().Or(true), @this.GetTypeName(), false, @this.GetMemberSymbols());

        private static PropertySymbol ToPropertySymbol(this JsonObject @this)
        {
            var getter = @this.GetProperty(nameof(PropertySymbol.Getter)).Map(g => ((JsonObject)g).ToSymbol().Make(y => (FunctionSymbol)y));
            var setter = @this.GetProperty(nameof(PropertySymbol.Setter)).Map(s => ((JsonObject)s).ToSymbol().Make(y => (FunctionSymbol)y));

            return new PropertySymbol(@this.GetName(), getter, setter);
        }

        private static VariableSymbol ToVariableSymbol(this JsonObject @this)
            => new VariableSymbol(@this.GetName(), @this.GetNewName(), @this.GetErrMessage(), @this.GetIsPublic().Or(true), @this.GetTypeName());

        private static Symbol ToSymbol(this JsonObject @this)
        {
            var type = @this.GetSymbolType();

            if (type is Some<String> someType)
                return   someType.Value.DataEquals(Types.Argument)       ? @this.ToArgumentSymbol()
                       : someType.Value.DataEquals(Types.Class)          ? @this.ToClassSymbol()
                       : someType.Value.DataEquals(Types.Constant)       ? @this.ToConstantSymbol()
                       : someType.Value.DataEquals(Types.Function)       ? @this.ToFunctionSymbol()
                       : someType.Value.DataEquals(Types.Property)       ? @this.ToPropertySymbol()
                       : someType.Value.DataEquals(Types.PropertyGet)    ? @this.ToPropertyGetSymbol()
                       : someType.Value.DataEquals(Types.PropertySet)    ? @this.ToPropertySetSymbol()
                       : someType.Value.DataEquals(Types.Variable)       ? @this.ToVariableSymbol()
                       : throw new Exception("Unexpected value in '_type' property.");
            else
                throw new Exception("Expected property '_type' missing.");
        }

        private static HostSymbols ToHostSymbols(this JsonObject @this)
            => new HostSymbols(@this.GetObjectArray(nameof(ScriptSymbols.Members)).Select(n => n.ToSymbol()),
                               @this.GetStringArray(nameof(ScriptSymbols.Tags)).ToArray());

        private static CodeSymbols ToCodeSymbols(this JsonObject @this)
            => new CodeSymbols(@this.GetObjectArray(nameof(ScriptSymbols.Members)).Select(n => n.ToSymbol()),
                               @this.GetStringArray(nameof(ScriptSymbols.Tags)).ToArray());

        public static HostSymbols ReadHostSymbols(this String filePath)
            => (JsonNode.Parse(File.ReadAllText(filePath))).Make(n => n != null ? ((JsonObject)n).ToHostSymbols() : new HostSymbols(new Symbol[] { }));

        public static CodeSymbols ReadCodeSymbols(this String filePath)
            => (JsonNode.Parse(File.ReadAllText(filePath))).Make(n => n != null ? ((JsonObject)n).ToCodeSymbols() : new CodeSymbols(new Symbol[] { }));

        public static Suspect<Option<SymbolsScope>> ReadHostSymbols(IEnumerable<String> files)
            => Return.Try(() => files.Select(o => ReadHostSymbols(o))
                                     .Aggregate(Option<SymbolsScope>.None,
                                                (a, n) => (new SymbolsScope(a, n)).Some()));

        public static Suspect<HostSymbols> ReadHostSymbols(this String[] filePaths, String basePath)
            => Return.Try(() => new HostSymbols(filePaths.Select(f => JsonNode.Parse(File.ReadAllText(Path.Combine(basePath, f))))
                                                         .SelectMany(n => n != null
                                                                          ? ((JsonObject)n).GetObjectArray(nameof(HostSymbols.Members)).Select(s => s.ToSymbol())
                                                                          : new Symbol[] { })));

    }

}
