using System;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public record Draft(String Value, List<String> Messages);

}