using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using Dorata.Text.Parsing;
using SyntaxToken = Dorata.Text.Lexing.Token;
using SyntaxNode  = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

        public enum PathExprStates : Int32
        {
            initial,
            variable, // PathIdentifier
            constant, // PathIdentifier (base search)
            function, // PathIdentifier
            property,
            funcArgs,
            termArgs,  // terminal function arguments
            arrayArgs,
            arrayInit, // PathIdentifier
            getRef,     // PathIdentifier
            className,
            terminate
        }

}