using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.Logics;
using Nysa.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public interface ICustomToJavaScript
    {
        Draft? ToJavaScript(AssignStatement assign, Context context, SymbolsScope symbols, DraftExpr left, DraftExpr right);

        Option<String> Message(CallStatement call, Context context, SymbolsScope symbols);
        Option<String> Message(InlineCallStatement call, Context context, SymbolsScope symbols);
    }

}
