using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.Logics;
using Nysa.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public class ContextFixed
    {
        private class DefaultToJs : ICustomToJavaScript
        {
            public Draft? ToJavaScript(AssignStatement assign, Context context, SymbolsScope symbols, DraftExpr left, DraftExpr right) => null;
            public Option<String> Message(CallStatement call, Context context, SymbolsScope symbols) => Option.None;
            public Option<String> Message(InlineCallStatement call, Context context, SymbolsScope symbols) => Option.None;
        }

        public SymbolsScope                             ParentSymbols   { get; private set; }
        public String                                   ArrayCreateFunc { get; private set; }
        public String                                   ArrayResizeFunc { get; private set; }
        public String                                   ArrayEraseFunc  { get; private set; }
        public String                                   SafeDeNullFunc  { get; private set; }
        public String                                   SafeImpFunction { get; private set; }
        public String                                   SafeEqvFunction { get; private set; }
        public String                                   SafeXorFunction { get; private set; }
        public String                                   SafeOrFunction  { get; private set; }
        public String                                   SafeAndFunction { get; private set; }
        public String                                   SafeNotFunction { get; private set; }
        public ICustomToJavaScript                      CustomToJs      { get; private set; }
        public Trivia                                   Trivia          { get; private set; }
        public Func<LiteralValue, LiteralValue>         InspectLiteral  { get; private set; }
        public Option<Dictionary<String, SymbolStats>>  SymbolHistory   { get; private set; }

        public ContextFixed(
            SymbolsScope parentSymbols,
            String arrayCreateFunc,
            String arrayResizeFunc,
            String arrayEraseFunc,
            String safeDeNullFunc,
            String safeImpFunction,
            String safeEqvFunction,
            String safeXorFunction,
            String safeOrFunction,
            String safeAndFunction,
            String safeNotFunction,
            ICustomToJavaScript? customToJs,
            Trivia trivia,
            Func<LiteralValue, LiteralValue> inspectLiteral,
            Dictionary<String, SymbolStats>? symbolHistory = null)
        {
            this.ParentSymbols      = parentSymbols;
            this.ArrayCreateFunc    = arrayCreateFunc;
            this.ArrayResizeFunc    = arrayResizeFunc;
            this.ArrayEraseFunc     = arrayEraseFunc;
            this.SafeDeNullFunc     = safeDeNullFunc;
            this.SafeImpFunction    = safeImpFunction;
            this.SafeEqvFunction    = safeEqvFunction;
            this.SafeXorFunction    = safeXorFunction;
            this.SafeOrFunction     = safeOrFunction;
            this.SafeAndFunction    = safeAndFunction;
            this.SafeNotFunction    = safeNotFunction;
            this.CustomToJs         = customToJs ?? new DefaultToJs();
            this.Trivia             = trivia;
            this.InspectLiteral     = inspectLiteral;
            this.SymbolHistory      = symbolHistory.AsOption();
        }
    }

}
