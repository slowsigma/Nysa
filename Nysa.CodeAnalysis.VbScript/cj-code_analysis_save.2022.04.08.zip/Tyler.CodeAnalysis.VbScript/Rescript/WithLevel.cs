using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.Logics;
using Nysa.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;

using SyntaxToken = Dorata.Text.Lexing.Token;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public class WithLevel
    {
        public Int32    NextLevel  { get; private set; }
        public Int32    Current    { get; private set; }
        public Boolean  CurrentCom { get; private set; }

        public String CurrentName => $"_objWithL{this.NextLevel}V{this.Current}";

        private WithLevel(Int32 nextLevel, Int32 current)
        {
            this.NextLevel  = nextLevel;
            this.Current    = current;
            this.CurrentCom = false;
        }

        public WithLevel()
            : this(1, 0)
        {
        }

        public Unit IncrementName(Boolean isCom)
        {
            this.Current += 1;
            this.CurrentCom = isCom;
            return Unit.Value;
        }

        public WithLevel NewLevel()
            => new WithLevel(this.NextLevel + 1, 0);
    }

}