using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.Logics;
using Nysa.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public class CustomToJs : ICustomToJavaScript
    {
        public HashSet<String> PixelProperties { get; private set; }
        public HashSet<String> ComProperties { get; private set; }

        public Draft? ToJavaScript(AssignStatement assign, Context context, SymbolsScope symbols, DraftExpr left, DraftExpr right)
        {
            var leftEnd         = assign.Left is PathExpression leftPath && leftPath.Count > 0
                                  ? leftPath[leftPath.Count - 1] as PathIdentifier
                                  : null;

            if (leftEnd != null)
            {
                if (this.PixelProperties.Contains(leftEnd.Value))
                {
                    return new Draft(String.Concat(left.Value, " ", "=", " Global.toPixelSize(", right.Value, ");"), new List<String>(left.Messages.Concat(right.Messages)));
                }
                else if (this.ComProperties.Contains(leftEnd.Value))
                {
                    var parts = left.Value.Split(".");
                    var prop = parts[parts.Length - 1];

                    parts[parts.Length - 1] = "setHostProperty";

                    return new Draft(String.Concat(parts.Join("."), "(\"", prop.ToLower(), "\", ", right.Value, ");"), new List<String>(left.Messages.Concat(right.Messages)));
                }
            }

            return null;
        }

        private Boolean IsAddObject(PathExpression path)
            =>    (   path[0] is PathWith
                   || path[0] is PathIdentifier)
               && (path[1] is PathIdentifier pid)
               && pid.Value.DataEquals("addobject");

        private Boolean ScriptClassArg(PathExpression path, Context context)
            =>    (path[2] is PathArguments args)
               && (args.Count == 2)
               && (   (args[0] is NewObjectExpression)
                   || (   args[0] is PathExpression pex
                       && pex.Count == 1
                       && pex[0] is PathIdentifier pei
                       && context.AssignedTypes.ContainsKey(pei.Value)
                       && !context.AssignedTypes[pei.Value].DataStartsWith("\"")));

        public Option<String> Message(CallStatement call, Context context, SymbolsScope symbols)
            => (call.AccessExpression is PathExpression path && path.Count == 3 && this.IsAddObject(path) && ScriptClassArg(path, context))
               ? "Cannot pass script class object into COM call.".Some()
               : Option.None;
        

        public Option<String> Message(InlineCallStatement call, Context context, SymbolsScope symbols)
            => (call.AccessExpression is PathExpression path && path.Count == 4 && this.IsAddObject(path) && ScriptClassArg(path, context))
               ? "Cannot pass script class object into COM call.".Some()
               : Option.None;

        public CustomToJs(IEnumerable<String> pixelProperties, IEnumerable<String> comProperties)
        {
            this.PixelProperties = pixelProperties.ToHashSet(StringComparer.OrdinalIgnoreCase);
            this.ComProperties   = comProperties.ToHashSet(StringComparer.OrdinalIgnoreCase);
        }
    }

}
