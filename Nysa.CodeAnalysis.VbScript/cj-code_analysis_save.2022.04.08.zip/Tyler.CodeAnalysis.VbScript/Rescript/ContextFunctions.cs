using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.Logics;
using Nysa.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;

using SyntaxToken = Dorata.Text.Lexing.Token;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class ContextFunctions
    {
        public static Context LineIndented(this Context @this)
        {
            var write = @this.WriteLine;

            return new Context(@this.Fixed, s => write(String.Concat(Context.STANDARD_INDENT, s)), @this.Level, @this.AssignedTypes, @this.ComIncidentals);
        }

        private static ContextLevel NewContextLevel(this ContextLevel @this, ClassDeclaration @class)
            => new ContextLevel(@this.Some(), @class, @this.WithLevel, @this.MethodAssign);
        private static ContextLevel NewContextLevel(this ContextLevel @this, MethodDeclaration @method, WithLevel withLevel, Option<MethodAssignInfo> methodInfo)
            => new ContextLevel(@this.Some(), @method, withLevel, methodInfo);
        private static ContextLevel NewContextLevel(this ContextLevel @this, WithStatement @with, WithLevel withLevel, Option<MethodAssignInfo> methodInfo)
            => new ContextLevel(@this.Some(), @with, withLevel, methodInfo);
        private static ContextLevel NewWithLevel(this ContextLevel @this)
            => new ContextLevel(@this.Some(), @this.CodeLevel, @this.WithLevel.NewLevel(), @this.MethodAssign);

        public static Context NextContext(this Context @this, ClassDeclaration @class)
            => new Context(@this.Fixed, @this.WriteLine, @this.Level.NewContextLevel(@class), @this.AssignedTypes, @this.ComIncidentals);
        public static Context NextContext(this Context @this, MethodDeclaration @method, WithLevel withLevel, Int32 methodAssignCount, VariableSymbol methodAssignSymbol)
            => new Context(@this.Fixed, @this.WriteLine, @this.Level.NewContextLevel(@method, withLevel, (new MethodAssignInfo(methodAssignCount, methodAssignSymbol)).Some()), @this.AssignedTypes, new HashSet<String>(@this.ComIncidentals.Concat(@method.ComIncidentals(@this)), StringComparer.OrdinalIgnoreCase));
        public static Context NextContext(this Context @this, WithStatement @with, WithLevel withLevel, Option<MethodAssignInfo> methodInfo)
            => new Context(@this.Fixed, @this.WriteLine, @this.Level.NewContextLevel(@with, withLevel, methodInfo), @this.AssignedTypes, @this.ComIncidentals);


        public static Option<T> FirstOf<T>(this ContextLevel @this)
            where T : CodeNode
            => @this.CodeLevel is T asT
               ? asT.Some()
               : @this.Prior is Some<ContextLevel> someLevel
                 ? someLevel.Value.FirstOf<T>()
                 : Option<T>.None;

        public static Unit AppendLine(this Context @this, String lineContent, Statement statement)
            => statement.TokenBounds().Make(bnds => @this.AppendLine(lineContent, bnds.Start, bnds.End));

        public static Unit RecordSymbolStat(
            this Context @this,
            String searchedName,
            Boolean baseSearch,
            Option<FoundSymbol> foundSymbol)
        {
            if (@this.Fixed.SymbolHistory is Some<Dictionary<String, SymbolStats>> someHist)
            {
                var hist = someHist.Value;

                if (!hist.ContainsKey(searchedName))
                    hist.Add(searchedName, new SymbolStats());

                var (what, @in) = foundSymbol.Map(f => (f.Symbol.ToWhatStat(), f.Scope.ToInStat()))
                                             .Or((0, 0));

                if (what > 0 && @in == 0)
                    Throw.CodingError<Unit>("RecordSymbolStat", "Cannot have a found symbol without symbolScope.");

                if (what > 0)
                    hist[searchedName].AddHit(what, @in, baseSearch, foundSymbol.Map(s => searchedName.Equals(s.Symbol.Name)).Or(false));
                else if (baseSearch)
                    hist[searchedName].AddBaseMiss();
                else
                    hist[searchedName].AddTypeMiss();
            }

            return Unit.Value;
        }

        public static Unit AppendLine(this Context @this, String lineContent, SyntaxToken? start, SyntaxToken? end)
        {
            // The start and end arguments assist AppendLine with ensuring we keep the context's trivia position aligned with
            // what is getting written out. If both are null, then trivia is not inspected/used. The start and end tokens
            // given must always represent the lineContent we are writing out and no more.

            var trivia  = @this.Fixed.Trivia;
            var current = @this.Fixed.Trivia.Position;
            var check   = start ?? end;

            // prior trivia that was missed (our goal is that this never happens)
            while (check != null && current < trivia.Count && trivia[current].Line.NextLine() < check.Value.Span.Position)
            {
                var missed = trivia.Text(current);

                if (trivia[current].Type != TriviaLineTypes.LineEnd || missed.Length > 0)
                    @this.WriteLine(missed);

                current++;
            }
            
            // now trivia has run out or is on or after the same line the given tokens represent
            var lineEnd = (   (check != null)
                           && (current < trivia.Count)
                           && (trivia[current].Line.Position <= check.Value.Span.Position)
                           && check.Value.Span.End.Value <= trivia[current].Line.NextLine())
                          ? current
                          : (Int32?)null;

            var lineEntStr = lineEnd == null
                             ? String.Empty
                             : trivia.Text(lineEnd.Value);

            @this.WriteLine(String.Concat(lineContent, lineEntStr));

            if (lineEnd != null)
                current++;

            @this.Fixed.Trivia.Position = current;

            return Unit.Value;
        }

    }

}
