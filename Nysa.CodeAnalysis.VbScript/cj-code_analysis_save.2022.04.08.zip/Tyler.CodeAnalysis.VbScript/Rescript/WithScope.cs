using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.Logics;
using Nysa.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;

using SyntaxToken = Dorata.Text.Lexing.Token;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public class WithScope
    {
        public Int32 NextLevel  { get; private set; }
        public Int32 Current    { get; private set; }

        public String CurrentName => $"_objWithL{this.NextLevel}V{this.Current}";

        private WithScope(Int32 nextLevel, Int32 current)
        {
            this.NextLevel = nextLevel;
            this.Current   = current;
        }

        public WithScope()
            : this(1, 0)
        {
        }

        public Unit IncrementName()
        {
            this.Current += 1;
            return Unit.Value;
        }

        public WithScope NewLevel()
            => new WithScope(this.NextLevel + 1, 0);
        
    }

}