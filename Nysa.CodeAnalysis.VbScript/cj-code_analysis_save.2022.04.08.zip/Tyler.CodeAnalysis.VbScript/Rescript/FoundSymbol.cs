using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;


namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public abstract record FoundSymbol<T>(T Symbol, SymbolsScope Scope) where T : Symbol;

    public abstract record FoundSymbol(Symbol Symbol, SymbolsScope Scope) : FoundSymbol<Symbol>(Symbol, Scope)
    {
        public abstract FoundSymbol WithSymbol(Symbol symbol);
    }

    public record FoundBaseSymbol(Symbol Symbol, SymbolsScope Scope) : FoundSymbol(Symbol, Scope)
    {
        public override FoundSymbol WithSymbol(Symbol symbol)
            => new FoundBaseSymbol(symbol, this.Scope);
    }

    public record FoundBaseSymbol<T>(T Symbol, SymbolsScope Scope) where T : Symbol;

    public record FoundTypeSymbol(Symbol Symbol, SymbolsScope Scope, ClassSymbol Type) : FoundSymbol(Symbol, Scope)
    {
        public override FoundSymbol WithSymbol(Symbol symbol)
            => new FoundTypeSymbol(symbol, this.Scope, this.Type);
    }

}