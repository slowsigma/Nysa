using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using Dorata.Text.Parsing;
using SyntaxToken = Dorata.Text.Lexing.Token;
using SyntaxNode  = Dorata.Text.Parsing.Node;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class Operators
    {
        public static readonly IReadOnlyDictionary<OperationTypes, String> MathIndex = new Dictionary<OperationTypes, string>()
        {
            // { OperationTypes.SignNegative, "-" },        handled manually (see OperateExpression in Translate)
            // { OperationTypes.SignPositive, "+" },        handled manually (see OperateExpression in Translate)
            // { OperationTypes.Concatenate, "+" },         handled manually (see OperateExpression in Translate)
            { OperationTypes.Add, "+" },
            { OperationTypes.Subtract, "-" },
            { OperationTypes.Mod, "%" },
            // { OperationTypes.IntDivide, @"\" },          handled manually (see OperateExpression in Translate)
            { OperationTypes.Multiply, "*" },
            { OperationTypes.Divide, "/" },
            { OperationTypes.Exponentiate, "**" }
        };

        public static readonly IReadOnlyDictionary<OperationTypes, (String Logical, String Bitwise)> BooleanIndex = new Dictionary<OperationTypes, (String Logical, String Bitwise)>()
        {
            { OperationTypes.ExclusiveOr, (Logical: "<manual>", Bitwise: "^") },     // there is a special test for Logical (see OperateExpression in Translate)
            { OperationTypes.Or, (Logical: "||" , Bitwise: "|") },
            { OperationTypes.And, (Logical: "&&" , Bitwise: "&") },
            { OperationTypes.Not, (Logical: "<manual>" , Bitwise: "~") },            // there is a special test for Logical (see OperateExpression in Translate)
        };

        public static readonly IReadOnlyDictionary<OperationTypes, String> OtherBooleanIndex = new Dictionary<OperationTypes, string>()
        {
            { OperationTypes.Implication, "Imp" },
            { OperationTypes.Equivalence, "Eqv" },
        };

        public static readonly IReadOnlySet<OperationTypes> TakingQuantities = new HashSet<OperationTypes>(new OperationTypes[]
        {
            OperationTypes.Greater,
            OperationTypes.GreaterOrEqual,
            OperationTypes.LesserOrEqual,
            OperationTypes.Lesser,
            OperationTypes.NotEqual,
            OperationTypes.Equal,
            OperationTypes.Add,
            OperationTypes.Subtract,
            OperationTypes.Mod,
            OperationTypes.IntDivide,
            OperationTypes.Multiply,
            OperationTypes.Divide,
            OperationTypes.Exponentiate
        });

        public static readonly IReadOnlyDictionary<OperationTypes, String> ComparisonIndex = new Dictionary<OperationTypes, string>()
        {
            { OperationTypes.Is, "===" },
            { OperationTypes.IsNot, "!==" },
            { OperationTypes.Greater, ">" },
            { OperationTypes.GreaterOrEqual, ">=" },
            { OperationTypes.LesserOrEqual, "<=" },
            { OperationTypes.Lesser, "<" },
            { OperationTypes.NotEqual, "!=" },
            { OperationTypes.Equal, "==" },
        };

        // probably is obsolete
        public static readonly Dictionary<OperationTypes, ExpressionTypes?> ArgumentType = new Dictionary<OperationTypes, ExpressionTypes?>()
        {
            { OperationTypes.Implication, (ExpressionTypes?)null },
            { OperationTypes.Equivalence, (ExpressionTypes?)null },
            { OperationTypes.ExclusiveOr, (ExpressionTypes?)null },
            { OperationTypes.Or, (ExpressionTypes?)null },
            { OperationTypes.And, (ExpressionTypes?)null },
            { OperationTypes.Not, (ExpressionTypes?)null },
            { OperationTypes.Is, ExpressionTypes.Access },
            { OperationTypes.IsNot, ExpressionTypes.Access },
            { OperationTypes.Greater, ExpressionTypes.AccessQuantity },
            { OperationTypes.GreaterOrEqual, ExpressionTypes.AccessQuantity },
            { OperationTypes.LesserOrEqual, ExpressionTypes.AccessQuantity },
            { OperationTypes.Lesser, ExpressionTypes.AccessQuantity },
            { OperationTypes.NotEqual, ExpressionTypes.AccessQuantity },
            { OperationTypes.Equal, ExpressionTypes.AccessQuantity },
            { OperationTypes.Add, ExpressionTypes.AccessQuantity },
            { OperationTypes.Subtract, ExpressionTypes.AccessQuantity },
            { OperationTypes.Mod, ExpressionTypes.AccessQuantity },
            { OperationTypes.IntDivide, ExpressionTypes.AccessQuantity },
            { OperationTypes.Multiply, ExpressionTypes.AccessQuantity },
            { OperationTypes.Divide, ExpressionTypes.AccessQuantity },
            { OperationTypes.Exponentiate, ExpressionTypes.AccessQuantity }
        };

    }

}