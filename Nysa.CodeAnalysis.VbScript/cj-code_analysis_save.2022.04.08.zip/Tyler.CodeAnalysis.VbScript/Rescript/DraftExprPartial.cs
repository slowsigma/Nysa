using System;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public record DraftExprPartial(String Value, List<String> Messages, ExpressionTypes Type, String[] Args) : DraftExpr(Value, Messages, Type);

}