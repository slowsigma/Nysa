using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using HtmlAgilityPack;


namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public static class SymbolFunctions
    {
        private static T ThrowUnexpectedType<T>(String functionName, String thisArgName)
            => throw new Exception($"Unexpected type encountered in '{functionName}({thisArgName})'.");


        /// <summary>
        /// Creates the standard set of host (global) symbols provided by the VbScript runtime engine.
        /// </summary>
        /// <returns></returns>
        public static HostSymbols ToHostSymbols(this IReadOnlyList<Symbol> members, params String[] tags)
            => new HostSymbols(members, tags.Length == 0 ? null : tags);

        private static FunctionSymbol FunctionOnly(this PropertyGetSymbol @this)
            => new FunctionSymbol(@this.Name, Option.None, Option.None, @this.IsPublic, Option.None, @this.Members);
        private static FunctionSymbol FunctionOnly(this PropertySetSymbol @this)
            => new FunctionSymbol(@this.Name, Option.None, Option.None, @this.IsPublic, Option.None, @this.Members);


        //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\ MAKE SYMBOLS FROM SEMANTIC TREE //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\

        public static IEnumerable<ConstantSymbol> ToJavaScriptSymbols(this ConstantDeclaration @this, CodeNode context)
            => @this.Constants.Select(c => new ConstantSymbol(c.Name.Value, Option.None, Option.None, true, Option.None));

        public static IEnumerable<VariableSymbol> ToJavaScriptSymbols(this FieldDeclaration @this, CodeNode context)
            => @this.Fields.Select(f => new VariableSymbol(f.Name.Value, Option.None, Option.None, context is Program || @this.Visibility == VisibilityTypes.Public, Option.None));

        public static IEnumerable<VariableSymbol> ToJavaScriptSymbols(this VariableDeclaration @this, Boolean isPublic)
            => @this.Variables.Select(v => new VariableSymbol(v.Name.Value, Option.None, Option.None, isPublic, Option.None));
        public static IEnumerable<RedimSymbol> ToJavaScriptSymbols(this RedimStatement @this)
            => @this.Variables.Select(v => new RedimSymbol(v.Name.Value, Option.None, Option.None, Option.None));

        public static Symbol ToJavaScriptSymbols(this ClassDeclaration @this)
        {
            var members  = new List<Symbol>();
            var propGets = new Dictionary<String, (PropertyGetSymbol Symbol, Int32 ArgCount)>(StringComparer.OrdinalIgnoreCase);
            var propSets = new Dictionary<String, (PropertySetSymbol Symbol, Int32 ArgCount)>(StringComparer.OrdinalIgnoreCase);
            var methods  = new Dictionary<String, FunctionSymbol>(StringComparer.OrdinalIgnoreCase);
            var @default = Option<Symbol>.None;

            members.Add(new VariableSymbol("me", "this".Some(), Option.None, true, Option.None));

            foreach (var statement in @this.Statements)
            {
                if (statement is FieldDeclaration field)
                    members.AddRange(field.ToJavaScriptSymbols(@this));
                else if (statement is VariableDeclaration variable)
                    members.AddRange(variable.ToJavaScriptSymbols(false));
                else if (statement is ConstantDeclaration constant)
                    members.AddRange(constant.ToJavaScriptSymbols(@this));
                else if (statement is MethodDeclaration method)
                {
                    (var symbol, var isDefault) = method.ToJavaScriptSymbols(@this);

                    if (isDefault)
                        @default = symbol.Some<Symbol>();
                    
                    if (symbol is PropertyGetSymbol get && !propGets.ContainsKey(symbol.Name))
                        propGets.Add(symbol.Name, (get, method.Arguments.Count));
                    else if (symbol is PropertyGetSymbol getDuplicate)
                        propGets[symbol.Name] = (getDuplicate, method.Arguments.Count);
                    else if (symbol is PropertySetSymbol set && !propSets.ContainsKey(symbol.Name))
                        propSets.Add(symbol.Name, (set, method.Arguments.Count));
                    else if (symbol is PropertySetSymbol setDuplicate)
                    {
                        var (curSym, curArgs) = propSets[symbol.Name];

                        propSets[symbol.Name] = (new PropertySetSymbol(symbol.Name, setDuplicate.IsPublic, Option.None, false, curSym.Members.Concat(setDuplicate.Members)), method.Arguments.Count);
                    }
                    else if (symbol is FunctionSymbol funcSym)
                    {
                        if (methods.ContainsKey(funcSym.Name))
                        {
                            var current = methods[funcSym.Name];

                            members.Remove(current);
                            methods.Remove(funcSym.Name);

                            funcSym = new FunctionSymbol(funcSym.Name, Option.None, Option.None, funcSym.IsPublic, Option.None, current.Members.Concat(funcSym.Members));
                        }

                        members.Add(funcSym);
                        methods.Add(funcSym.Name, funcSym);
                    }
                    else
                        Throw.UnexpectedType<Unit>(nameof(ToJavaScriptSymbols), nameof(ClassDeclaration));
                }
            }

            // reconcile properties
            foreach (var propertyName in propGets.Keys.Union(propSets.Keys, StringComparer.OrdinalIgnoreCase))
            {
                var getter = propGets.ContainsKey(propertyName) ? propGets[propertyName] : ((PropertyGetSymbol Symbol, Int32 ArgCount)?)null;
                var setter = propSets.ContainsKey(propertyName) ? propSets[propertyName] : ((PropertySetSymbol Symbol, Int32 ArgCount)?)null;

                if (getter != null && setter == null)
                {
                    var getSymbol = (getter.Value.ArgCount == 0)
                                    ? (FunctionSymbol)getter.Value.Symbol
                                    : getter.Value.Symbol.FunctionOnly();

                    members.Add(new PropertySymbol(propertyName, getSymbol.Some(), Option.None));
                }
                else if (getter == null && setter != null)
                {
                    var setSymbol = (setter.Value.ArgCount == 1)
                                    ? (FunctionSymbol)setter.Value.Symbol
                                    : setter.Value.Symbol.FunctionOnly();
                    
                    members.Add(new PropertySymbol(propertyName, Option.None, setSymbol.Some()));
                }
                else if (getter != null && setter != null)
                {
                    if (getter.Value.ArgCount == 0 && setter.Value.ArgCount == 1)
                        members.Add(new PropertySymbol(propertyName,
                                                       getter.Value.Symbol.Some<FunctionSymbol>(),
                                                       setter.Value.Symbol.Some<FunctionSymbol>()));
                    else // map to different getter and setter names (functions)
                        members.Add(new PropertySymbol(propertyName,
                                                       getter.Value.Symbol.FunctionOnly().Renamed(String.Concat("get_", propertyName)).Some(),
                                                       setter.Value.Symbol.FunctionOnly().Renamed(String.Concat("set_", propertyName)).Some()));
                }
            }

            return new ClassSymbol(@this.Name.Value, members, @default);
        }

        public static String MethodResultName(this MethodDeclaration @this)
            => String.Concat("__", @this.Name);

        public static (Symbol Symbol, Boolean IsDefault) ToJavaScriptSymbols(this MethodDeclaration @this, CodeNode context)
        {
            var unique  = new HashSet<String>(StringComparer.OrdinalIgnoreCase);
            var members = new List<Symbol>();

            foreach (var arg in @this.Arguments)
            {
                unique.Add(arg.Name.Value);
                members.Add(new ArgumentSymbol(arg.Name.Value, arg.Modifier.Map(m => m == ArgumentModifiers.ByRef).Or(true)));
            }
            
            // special function return value variable
            members.Add(new VariableSymbol(@this.Name.Value, @this.MethodResultName().Some(), Option.None, true, Translate.Function_Return_Type.Some()));

            foreach (var stmtSym in @this.Statements.ToJavaScriptSymbols())
            {
                if (stmtSym is VariableSymbol || stmtSym is RedimSymbol) // between variable and redim symbols...
                {
                    if (!unique.Contains(stmtSym.Name)) // we only take the first unique one
                    {
                        unique.Add(stmtSym.Name);
                        members.Add(stmtSym);
                    }
                }
                else // any other symbol type, just add it
                    members.Add(stmtSym);
            }
            
            var isPublic     = context is Program || @this.Visibility.Or(VisibilityTypes.Public) == VisibilityTypes.Public;
            var isDefault    = @this.IsDefault;
            var propertyType = (@this is PropertyDeclaration prop)
                               ? prop.Access == PropertyAccessTypes.Get 
                                 ? PropertyAccessTypes.Get.Some()
                                 : PropertyAccessTypes.Set.Some()
                               : Option<PropertyAccessTypes>.None;

            return @this is PropertyDeclaration propDecl
                   ? propDecl.Access == PropertyAccessTypes.Get
                     ? (new PropertyGetSymbol(@this.Name.Value, isPublic, Option.None, members), isDefault)
                     : (new PropertySetSymbol(@this.Name.Value, isPublic, Option.None, propDecl.Access == PropertyAccessTypes.Let, members), isDefault)
                   : (new FunctionSymbol(@this.Name.Value, Option.None, Option.None, isPublic, Option.None, members), isDefault);
        }

        public static IEnumerable<Symbol> ToJavaScriptSymbols(this StatementList @this)
            => @this.SelectMany(l => l.ToJavaScriptSymbols());

        public static Symbol ToJavaScriptSymbols(this IfStatement @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Consequent.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this ElseBlock @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this ForEachStatement @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this ForStatement @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this DoLoopStatement @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this DoLoopTestStatement @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this DoTestLoopStatement @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());
        public static IEnumerable<Symbol> ToJavaScriptSymbols(this SelectStatement @this)
            => @this.Cases.Select(c => c.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this SelectCase @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this WhileStatement @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());
        public static Symbol ToJavaScriptSymbols(this WithStatement @this)
            => new BlockSymbol(@this.BlockSymbolName(), @this.Statements.ToJavaScriptSymbols());

        public static IEnumerable<Symbol> ToJavaScriptSymbols(this Statement @this)
            => @this switch
            {
                ClassDeclaration @class => Return.Enumerable(@class.ToJavaScriptSymbols()),
                ConstantDeclaration constant => constant.ToJavaScriptSymbols(@this),
                FieldDeclaration field => field.ToJavaScriptSymbols(@this),
                MethodDeclaration method => Return.Enumerable(method.ToJavaScriptSymbols(@this).Symbol),
                VariableDeclaration variable => variable.ToJavaScriptSymbols(true),
                IfStatement ifStmt => Return.Enumerable<Symbol>(ifStmt.ToJavaScriptSymbols())
                                            .Concat(ifStmt.Alternatives.Select(a => a.ToJavaScriptSymbols())),
                ForEachStatement forEachStmt => Return.Enumerable(forEachStmt.ToJavaScriptSymbols()),
                ForStatement forStmt => Return.Enumerable(forStmt.ToJavaScriptSymbols()),
                DoLoopStatement doLoop => Return.Enumerable(doLoop.ToJavaScriptSymbols()),
                DoLoopTestStatement doLoopTest => Return.Enumerable(doLoopTest.ToJavaScriptSymbols()),
                DoTestLoopStatement doTestLoop => Return.Enumerable(doTestLoop.ToJavaScriptSymbols()),
                RedimStatement redimStmt => redimStmt.ToJavaScriptSymbols(),
                SelectStatement selectStmt => selectStmt.ToJavaScriptSymbols(),
                WhileStatement whileStmt => Return.Enumerable(whileStmt.ToJavaScriptSymbols()),
                WithStatement withStmt => Return.Enumerable(withStmt.ToJavaScriptSymbols()),
                _ => None<Symbol>.Enumerable()
            };

        public static CodeSymbols ToJavaScriptSymbols(this Program @this)
        {
            var members  = new List<Symbol>();
            var methods  = new Dictionary<String, FunctionSymbol>(StringComparer.OrdinalIgnoreCase);

            foreach (var statement in @this.Statements)
            {
                if (statement is MethodDeclaration method)
                {
                    (var symbol, var isDefault) = method.ToJavaScriptSymbols(@this);

                    if (symbol is FunctionSymbol funcSym)
                    {
                        if (methods.ContainsKey(funcSym.Name))
                        {
                            var current = methods[funcSym.Name];

                            members.Remove(current);
                            methods.Remove(funcSym.Name);

                            funcSym = new FunctionSymbol(funcSym.Name, Option.None, Option.None, funcSym.IsPublic, Option.None, current.Members.Concat(funcSym.Members));
                        }

                        members.Add(funcSym);
                        methods.Add(funcSym.Name, funcSym);
                    }

                }
                else
                    members.AddRange(statement.ToJavaScriptSymbols());
            }

            return new CodeSymbols(members);
        }

        public static CodeSymbols WithParent(this CodeSymbols @this)
        {
            var withParent = new List<Symbol>();

            withParent.AddRange(@this.Members);

            Boolean isParentMember(Symbol symbol)
                => symbol switch
                {
                    ConstantSymbol constSym => constSym.IsPublic,
                    FunctionSymbol funcSym => funcSym.IsPublic,
                    VariableSymbol varSym => varSym.IsPublic,
                    RedimSymbol    redimSym => redimSym.IsPublic,
                    _ => false
                };

            var parentClass = new ClassSymbol("_parent", Option.None, Option.None, @this.Members.Where(m => isParentMember(m)), Option.None);

            withParent.Add(parentClass);
            withParent.Add(new VariableSymbol("parent", Option.None, Option.None, true, parentClass.Name.Some()));

            return new CodeSymbols(withParent);
        }

        //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\ MAKE SYMBOLS FROM HTML DOCUMENT //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\

        public static PageSymbols ToJavaScriptSymbols(this HtmlDocument @this)
        {
            var raw = new List<Symbol>();

            foreach (var node in @this.DocumentNode.DescendantsAndSelf())
            {
                var nodeName = node.Name;                 // using as VariableSymbol.ClassName ??
                var idAttr   = node.Attributes.FirstOrNone(a => a.Name.DataEquals("id"));

                if (idAttr is Some<HtmlAttribute> someIdAttr)
                {
                    raw.Add(new VariableSymbol(someIdAttr.Value.Value, Option.None, Option.None, true, nodeName.Some()));
                }
            }

            return new PageSymbols(raw);
        }

        public static PageSymbols ToJavaScriptSymbols(this XmlDocument @this)
        {
            var raw = new List<Symbol>();
            var descendants = @this.SelectNodes("//*").Cast<XmlElement>() ?? None<XmlElement>.Enumerable();

            foreach (var node in descendants)
            {
                var elemName = node.LocalName;                 // using as VariableSymbol.ClassName ??
                var idAttr   = node.Attributes.Cast<XmlAttribute>().FirstOrNone(a => a.LocalName.DataEquals("id"));

                if (idAttr is Some<XmlAttribute> someIdAttr)
                {
                    raw.Add(new VariableSymbol(someIdAttr.Value.Value, Option.None, Option.None, true, elemName.Some()));
                }
            }

            return new PageSymbols(raw);
        }


        //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\ GET A SYMBOL SCOPE //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, MethodDeclaration method)
        {
            var methodName  = method.Name.Value;
            var found       = @this.GetMember<Symbol>(methodName);
            
            if (found is Some<Symbol> someSymbol)
            {
                if (someSymbol.Value is FunctionSymbol funcSym && (method is FunctionDeclaration || method is SubroutineDeclaration))
                    return @this.MemberScope(funcSym);
                else if (someSymbol.Value is PropertySymbol propSym && method is PropertyDeclaration propDecl)
                {
                    // NOTE: We only use PropertySymbol for lookup and we create the SymbolsContext using
                    //       either the getter or setter based on the incoming MethodDeclaration.
                    if (propDecl.Access == PropertyAccessTypes.Get && propSym.Getter is Some<FunctionSymbol> someGetter)
                        return @this.MemberScope(someGetter.Value);
                    else if (propSym.Setter is Some<FunctionSymbol> someSetter)
                        return @this.MemberScope(someSetter.Value);
                    else
                        throw new Exception($"Property accessor symbol does not match method declaration type: '{methodName}'.");
                }

                throw new Exception($"Symbol type does not match method declaration type: '{methodName}'.");
            }

            throw new Exception($"Symbol missing for method declaration: '{methodName}'.");
        }

        public static SymbolsScope SymbolsFor(this SymbolsScope @this, ClassDeclaration @class)
        {
            var className = @class.Name.Value;

            var found = @this.GetMember<ClassSymbol>(className);

            if (found is Some<ClassSymbol> someClass)
                return @this.MemberScope(someClass.Value);
            else
                throw new Exception($"Symbol is missing or does not match class declaration type: '{className}'.");
        }


        private static SymbolsScope SymbolsFor<T>(this SymbolsScope @this, T statement, String name)
            where T : Statement
        {
            var found = @this.GetMember<BlockSymbol>(name);

            if (found is Some<BlockSymbol> someBlock)
                return @this.MemberScope(someBlock.Value);
            else
                throw new Exception($"Block symbol could not be found for: '{statement.GetType().Name}'.");
        }

        public static SymbolsScope SymbolsFor(this SymbolsScope @this, IfStatement statement)
            => @this.SymbolsFor<IfStatement>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, ElseBlock statement)
            => @this.SymbolsFor<ElseBlock>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, ForEachStatement statement)
            => @this.SymbolsFor<ForEachStatement>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, ForStatement statement)
            => @this.SymbolsFor<ForStatement>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, DoLoopStatement statement)
            => @this.SymbolsFor<DoLoopStatement>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, DoLoopTestStatement statement)
            => @this.SymbolsFor<DoLoopTestStatement>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, DoTestLoopStatement statement)
            => @this.SymbolsFor<DoTestLoopStatement>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, SelectCase statement)
            => @this.SymbolsFor<SelectCase>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, WhileStatement statement)
            => @this.SymbolsFor<WhileStatement>(statement, statement.BlockSymbolName());
        public static SymbolsScope SymbolsFor(this SymbolsScope @this, WithStatement statement)
            => @this.SymbolsFor<WithStatement>(statement, statement.BlockSymbolName());



        public static Int32 ToWhatStat(this Symbol @this)
            => @this switch
            {
                ArgumentSymbol => SymbolStats.What.Argument,
                ClassSymbol => SymbolStats.What.Class,
                ConstantSymbol => SymbolStats.What.Constant,
                FunctionSymbol => SymbolStats.What.Function,
                VariableSymbol => SymbolStats.What.Variable,
                RedimSymbol    => SymbolStats.What.Variable,
                _ => SymbolStats.What.Invalid
            };

        public static String ToHardName(this HardSymbol @this)
            => @this.NewName.Or(@this.Name);

        public static String ToMemberName(this MemberSymbol @this)
            => @this.ToHardName()
                    .Make(n => @this.IsPublic ? n : String.Concat("#", n));

        public static String SymbolName(this Symbol @this)
            => @this switch
            {
                ArgumentSymbol      argSym   => argSym.ToHardName(),
                ClassSymbol         classSym => classSym.ToHardName(),
                ConstantSymbol      constSym => constSym.ToMemberName(),
                PropertyGetSymbol   propGet  => propGet.ToMemberName(),
                PropertySetSymbol   propSet  => propSet.ToMemberName(),
                FunctionSymbol      funcSym  => funcSym.ToMemberName(),
                PropertySymbol      propSym  => Throw.CodingError<String>(nameof (SymbolName), "PropertySymbol not allowed"),
                VariableSymbol      varSym   => varSym.ToMemberName(),
                RedimSymbol         redimSym => redimSym.ToMemberName(),
                _ => Throw.CodingError<String>(nameof(SymbolName), "unexpected type")
            };

    }

}

