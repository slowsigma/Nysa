using System;

namespace Tyler.CodeAnalysis.VbScript.Rescript
{

    public enum ExpressionTypes : Int32
    {
        AssignTarget, 	    // requires a place to store a value
        Access,             // requires a function or place to get a value
        AccessBoolean,      // requires a function or place to get a boolean
        AccessQuantity,     // requires a function or place to get a quantity
        AccessString,       // requires a function or place to get a string
        Execute,            // requires a function to execute
        Reference,          // requires a reference to a function (i.e., the arg of GetRef call)
        ClassIdentifier     // requires a class identifier (new object expression class name)
    }

}