using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Rescript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;

using SyntaxNode = Dorata.Text.Parsing.Node;
using ProgramNode = Nysa.CodeAnalysis.VbScript.Semantics.Program;

using Tyler.CodeAnalysis.VbScript;
using Tyler.CodeAnalysis.VbScript.Rescript;

using Dorata.Text.Lexing;
using Dorata.Text.Parsing;

namespace Tyler.CodeAnalysis.Testing
{

    public static class RescriptTests
    {
        public static void ReadGlobalSymbolsJson(String baseDataDir)
        {
            var hostSymbolsFile = Path.Combine(baseDataDir, "HostSymbols.json");

            var hostSymbols = hostSymbolsFile.ReadHostSymbols();
        }

        private static ContextFixed StandardFixed(SymbolsScope hostSymbols, Trivia trivia)
            => new ContextFixed(hostSymbols,
                                "Global.NewArray",
                                "Global.ResizeArray",
                                "Global.EraseArray",
                                "Global.toString",
                                "Global.Imp",
                                "Global.Eqv",
                                "Global.Xor",
                                "Global.Or",
                                "Global.And",
                                "Global.Not",
                                null,
                                trivia,
                                l => l,
                                null);

        public static void TrySingleFile(String baseDataDir)
        {
            //var path = Path.Combine(baseDataDir, @"VbScripts\AsyncHelper.vbs");
            //var path = Path.Combine(baseDataDir, @"VbScripts\Item.vbs");
            var fileIn = Path.Combine(baseDataDir, @"VbScripts\Common.vbs");
            var fileOut = Path.Combine(baseDataDir, @"JavaScripts\Common.js");

            var content = File.ReadAllText(fileIn).ToVbScriptContent(fileIn);

            var parse = content.Parse();

            if (parse.SyntaxRoot is Confirmed<SyntaxNode> confirmedNode)
            {
                var trivia = content.Trivia(confirmedNode.Value);
                var tree   = parse.ToProgram();

                if (tree is Confirmed<ProgramNode> validTree)
                {
                    var symbols = validTree.Value.ToJavaScriptSymbols();

                    var hostSymbolsFile = Path.Combine(baseDataDir, "HostSymbols.json");

                    var hostSymbols  = new SymbolsScope(Option.None, hostSymbolsFile.ReadHostSymbols());
                    var startSymbols = hostSymbols.AddScope(symbols);

                    var build   = new StringBuilder();
                    var context = new Context(StandardFixed(hostSymbols, trivia),
                                              s => { build.AppendLine(s); },
                                              new ContextLevel(Option.None, validTree.Value, new WithLevel(), Option.None));

                    var rescript = validTree.Value.ToJavaScript(context, startSymbols);

                    if (File.Exists(fileOut))
                        File.Delete(fileOut);

                    File.WriteAllText(fileOut, build.ToString());
                }

            }
            else if (parse.SyntaxRoot is Failed<SyntaxNode> failedNode)
            {
                Debug.WriteLine(failedNode.Value.ToString());
            }
        }

    }

}
