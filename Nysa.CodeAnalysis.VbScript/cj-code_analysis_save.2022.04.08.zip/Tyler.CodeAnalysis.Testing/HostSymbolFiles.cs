using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Rescript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;

using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.CodeAnalysis.Testing
{

    public static class HostSymbolFiles
    {

        public static readonly String VbScriptFile = "HostSymbols.VbScript.json";
        public static readonly String WebApiFile = "HostSymbols.WebApi.json";
        public static readonly String TylerHostFile = "HostSymbols.Tyler.json";

        private static List<Symbol> TylerHostSymbols()
        {
            var allSymbols = new List<Symbol>();

            var ccvMembers = new List<Symbol>();

            ccvMembers.Add("FilterCallback".EmptyProperty(false));
            ccvMembers.Add("NamespaceName".EmptyProperty(false));
            ccvMembers.Add("EntityName".EmptyProperty(false));
            ccvMembers.Add("Tablename".EmptyProperty(false));
            ccvMembers.Add("Namespace".EmptyProperty(false));
            ccvMembers.Add("NodeID".EmptyProperty(false));
            ccvMembers.Add("Filter".EmptyProperty(false));
            ccvMembers.Add("InitialValue".EmptyProperty(false));
            ccvMembers.Add("TaxYear".EmptyProperty(false));
            ccvMembers.Add("IncludeObsoleteCodes".EmptyProperty(false));
            ccvMembers.Add("NodeDataFilter".EmptyProperty(false));
            ccvMembers.Add("SortExpression".EmptyProperty(false));
            ccvMembers.Add("DefaultCodeID".EmptyProperty(true, false));
            ccvMembers.Add("DefaultCategoryKey".EmptyProperty(false));
            ccvMembers.Add("AddSecurityFilter".EmptyFunction());
            ccvMembers.Add("AddPropertyFilter".EmptyFunction());
            ccvMembers.Add("Reset".EmptyFunction());

            allSymbols.Add(new ClassSymbol("ICacheCodeValidator", Option.None, Option.None, ccvMembers, Option.None));


            var comboBoxMembers = new List<Symbol>();

            comboBoxMembers.Add("tabIndex".EmptyProperty(false));
            comboBoxMembers.Add("disabled".EmptyProperty(false));
            comboBoxMembers.Add("required".EmptyProperty(false));
            comboBoxMembers.Add("readOnly".EmptyProperty(false));
            comboBoxMembers.Add("errorState".EmptyProperty(false));
            comboBoxMembers.Add("warningState".EmptyProperty(false));
            comboBoxMembers.Add("errorTag".EmptyProperty(false));
            comboBoxMembers.Add("errorLabel".EmptyProperty(false));
            comboBoxMembers.Add("value".EmptyProperty(false));
            comboBoxMembers.Add("innerHTML".EmptyProperty(false));
            comboBoxMembers.Add("textTitle".EmptyProperty(false));
            comboBoxMembers.Add("maxLength".EmptyProperty(false));
            comboBoxMembers.Add("Options".EmptyProperty(true));
            comboBoxMembers.Add("CacheValidator".EmptyProperty(true));
            comboBoxMembers.Add("Code".EmptyProperty(false));
            comboBoxMembers.Add("Description".EmptyProperty(true));
            comboBoxMembers.Add("width".EmptyProperty(false));
            comboBoxMembers.Add("authorized".EmptyProperty(false));
            comboBoxMembers.Add("TextValue".EmptyProperty(false));
            comboBoxMembers.Add("IncludeEmptyOption".EmptyProperty(false));
            comboBoxMembers.Add("SortPopup".EmptyProperty(false));
            comboBoxMembers.Add("dialogTitle".EmptyProperty(false));
            comboBoxMembers.Add("EmptyOptionText".EmptyProperty(false));
            comboBoxMembers.Add("OptionCount".EmptyProperty(true));
            comboBoxMembers.Add(new PropertySymbol("SelectedIndex", Option.None, "SelectedIndex".EmptyPropertySet().Some<FunctionSymbol>()));
            comboBoxMembers.Add("initComplete".EmptyProperty(true));
            
            comboBoxMembers.Add("focus".EmptyFunction());
            comboBoxMembers.Add("addError".EmptyFunction());
            comboBoxMembers.Add("addWarning".EmptyFunction());
            comboBoxMembers.Add("clearMessage".EmptyFunction());
            comboBoxMembers.Add("validate".EmptyFunction());
            comboBoxMembers.Add("clickButton".EmptyFunction());
            comboBoxMembers.Add("reset".EmptyFunction());
            comboBoxMembers.Add("select".EmptyFunction());

            allSymbols.Add(new ClassSymbol("IComboBox", Option.None, Option.None, comboBoxMembers, Option.None));


            var dateboxMembers = new List<Symbol>();

            dateboxMembers.Add("tabIndex".EmptyProperty(false));
            dateboxMembers.Add("disabled".EmptyProperty(false));
            dateboxMembers.Add("required".EmptyProperty(false));
            dateboxMembers.Add("readOnly".EmptyProperty(false));
            dateboxMembers.Add("errorState".EmptyProperty(false));
            dateboxMembers.Add("warningState".EmptyProperty(false));
            dateboxMembers.Add("errorTag".EmptyProperty(false));
            dateboxMembers.Add("errorLabel".EmptyProperty(false));
            dateboxMembers.Add("value".EmptyProperty(false));
            dateboxMembers.Add("innerHTML".EmptyProperty(false));
            dateboxMembers.Add("minValue".EmptyProperty(false));
            dateboxMembers.Add("maxValue".EmptyProperty(false));
            dateboxMembers.Add("buttonTitle".EmptyProperty(false));
            dateboxMembers.Add("textTitle".EmptyProperty(false));
            dateboxMembers.Add("authorized".EmptyProperty(false));
            dateboxMembers.Add("noBorder".EmptyProperty(false));
            dateboxMembers.Add("displayButton".EmptyProperty(false));
            dateboxMembers.Add("initComplete".EmptyProperty(true));

            dateboxMembers.Add("focus".EmptyFunction());
            dateboxMembers.Add("addError".EmptyFunction());
            dateboxMembers.Add("addWarning".EmptyFunction());
            dateboxMembers.Add("clearMessage".EmptyFunction());
            dateboxMembers.Add("validate".EmptyFunction());
            dateboxMembers.Add("clickButton".EmptyFunction());
            dateboxMembers.Add("select".EmptyFunction());

            allSymbols.Add(new ClassSymbol("IDateBox", Option.None, Option.None, dateboxMembers, Option.None));


            var mskEditMembers = new List<Symbol>();

            mskEditMembers.Add("tabIndex".EmptyProperty(false));
            mskEditMembers.Add("disabled".EmptyProperty(false));
            mskEditMembers.Add("required".EmptyProperty(false));
            mskEditMembers.Add("readOnly".EmptyProperty(false));
            mskEditMembers.Add("errorState".EmptyProperty(false));
            mskEditMembers.Add("warningState".EmptyProperty(false));
            mskEditMembers.Add("errorTag".EmptyProperty(false));
            mskEditMembers.Add("errorLabel".EmptyProperty(false));
            mskEditMembers.Add("value".EmptyProperty(false));
            mskEditMembers.Add("innerHTML".EmptyProperty(false));
            mskEditMembers.Add("minValue".EmptyProperty(false));
            mskEditMembers.Add("maxValue".EmptyProperty(false));
            mskEditMembers.Add("textTitle".EmptyProperty(false));
            mskEditMembers.Add("authorized".EmptyProperty(false));
            mskEditMembers.Add("noBorder".EmptyProperty(false));
            mskEditMembers.Add("maxLength".EmptyProperty(false));
            mskEditMembers.Add("mask".EmptyProperty(false));
            mskEditMembers.Add("precision".EmptyProperty(false));
            mskEditMembers.Add("justification".EmptyProperty(false));
            mskEditMembers.Add("width".EmptyProperty(false));
            mskEditMembers.Add("defaultAreaCode".EmptyProperty(false));
            mskEditMembers.Add("initComplete".EmptyProperty(true));

            mskEditMembers.Add("focus".EmptyFunction());
            mskEditMembers.Add("addError".EmptyFunction());
            mskEditMembers.Add("addWarning".EmptyFunction());
            mskEditMembers.Add("clearMessage".EmptyFunction());
            mskEditMembers.Add("validate".EmptyFunction());
            mskEditMembers.Add("select".EmptyFunction());

            allSymbols.Add(new ClassSymbol("IMaskedEdit", Option.None, Option.None, mskEditMembers, Option.None));


            var multiPickMembers = new List<Symbol>();

            multiPickMembers.Add("tabIndex".EmptyProperty(false));
            multiPickMembers.Add("disabled".EmptyProperty(false));
            multiPickMembers.Add("required".EmptyProperty(false));
            multiPickMembers.Add("readOnly".EmptyProperty(false));
            multiPickMembers.Add("errorState".EmptyProperty(false));
            multiPickMembers.Add("warningState".EmptyProperty(false));
            multiPickMembers.Add("errorTag".EmptyProperty(false));
            multiPickMembers.Add("errorLabel".EmptyProperty(false));
            multiPickMembers.Add("value".EmptyProperty(false));
            multiPickMembers.Add("innerHTML".EmptyProperty(false));
            multiPickMembers.Add("buttonTitle".EmptyProperty(false));
            multiPickMembers.Add("textTitle".EmptyProperty(false));
            multiPickMembers.Add("labelWidth".EmptyProperty(false));
            multiPickMembers.Add("label".EmptyProperty(false));
            multiPickMembers.Add("multiLine".EmptyProperty(false));
            multiPickMembers.Add("editable".EmptyProperty(false));
            multiPickMembers.Add("textCodeValue".EmptyProperty(false));
            multiPickMembers.Add("textDescriptionValue".EmptyProperty(false));
            multiPickMembers.Add("Options".EmptyProperty(true));
            multiPickMembers.Add("CacheValidator".EmptyProperty(true));
            multiPickMembers.Add("dialogTitle".EmptyProperty(false));
            multiPickMembers.Add("buttonDisabled".EmptyProperty(false));
            multiPickMembers.Add("IsAllSelected".EmptyProperty(true));
            multiPickMembers.Add("addedArray".EmptyProperty(true));
            multiPickMembers.Add("removedArray".EmptyProperty(true));
            multiPickMembers.Add("codeXML".EmptyProperty(true));
            multiPickMembers.Add("valueXML".EmptyProperty(true));
            multiPickMembers.Add("initComplete".EmptyProperty(true));

            multiPickMembers.Add("focus".EmptyFunction());
            multiPickMembers.Add("addError".EmptyFunction());
            multiPickMembers.Add("addWarning".EmptyFunction());
            multiPickMembers.Add("clearMessage".EmptyFunction());
            multiPickMembers.Add("validate".EmptyFunction());
            multiPickMembers.Add("clickButton".EmptyFunction());
            multiPickMembers.Add("clickError".EmptyFunction());
            multiPickMembers.Add("select".EmptyFunction());
            multiPickMembers.Add("disableAll".EmptyFunction());
            multiPickMembers.Add("addCode".EmptyFunction());
            multiPickMembers.Add("RemoveCode".EmptyFunction());

            allSymbols.Add(new ClassSymbol("IMultiPicker", Option.None, Option.None, multiPickMembers, Option.None));


            var olcvMembers = new List<Symbol>();

            olcvMembers.Add("AddOption".EmptyFunction());
            olcvMembers.Add("RemoveOption".EmptyFunction());
            olcvMembers.Add("ClearOptions".EmptyFunction());

            allSymbols.Add(new ClassSymbol("IOptionListCodeValidator", Option.None, Option.None, olcvMembers, Option.None));


            var sandBoxMembers = new List<Symbol>();

            sandBoxMembers.Add("tabIndex".EmptyProperty(false));
            sandBoxMembers.Add("disabled".EmptyProperty(false));
            sandBoxMembers.Add("required".EmptyProperty(false));
            sandBoxMembers.Add("readOnly".EmptyProperty(false));
            sandBoxMembers.Add("errorState".EmptyProperty(false));
            sandBoxMembers.Add("warningState".EmptyProperty(false));
            sandBoxMembers.Add("errorTag".EmptyProperty(false));
            sandBoxMembers.Add("errorLabel".EmptyProperty(false));
            sandBoxMembers.Add("value".EmptyProperty(false));
            sandBoxMembers.Add("innerHTML".EmptyProperty(false));
            sandBoxMembers.Add("buttonTitle".EmptyProperty(false));
            sandBoxMembers.Add("textTitle".EmptyProperty(false));
            sandBoxMembers.Add("textValue".EmptyProperty(false));
            sandBoxMembers.Add("mode".EmptyProperty(false));
            sandBoxMembers.Add("multiValue".EmptyProperty(false));
            sandBoxMembers.Add("multiLine".EmptyProperty(false));
            sandBoxMembers.Add("editable".EmptyProperty(false));
            sandBoxMembers.Add("rows".EmptyProperty(false));
            sandBoxMembers.Add("label".EmptyProperty(false));
            sandBoxMembers.Add("labelWidth".EmptyProperty(false));
            sandBoxMembers.Add("authorized".EmptyProperty(false));
            sandBoxMembers.Add("buttonDisabled".EmptyProperty(false));
            sandBoxMembers.Add("showAsLink".EmptyProperty(false));
            sandBoxMembers.Add("initComplete".EmptyProperty(true));

            sandBoxMembers.Add("focus".EmptyFunction());
            sandBoxMembers.Add("addError".EmptyFunction());
            sandBoxMembers.Add("addWarning".EmptyFunction());
            sandBoxMembers.Add("clearMessage".EmptyFunction());
            sandBoxMembers.Add("validate".EmptyFunction());
            sandBoxMembers.Add("clickButton".EmptyFunction());
            sandBoxMembers.Add("clickLink".EmptyFunction());
            sandBoxMembers.Add("clickError".EmptyFunction());
            sandBoxMembers.Add("select".EmptyFunction());
            sandBoxMembers.Add("disableAll".EmptyFunction());

            allSymbols.Add(new ClassSymbol("ISandBox", Option.None, Option.None, sandBoxMembers, Option.None));


            var textBoxMembers = new List<Symbol>();

            textBoxMembers.Add("tabIndex".EmptyProperty(false));
            textBoxMembers.Add("disabled".EmptyProperty(false));
            textBoxMembers.Add("required".EmptyProperty(false));
            textBoxMembers.Add("readOnly".EmptyProperty(false));
            textBoxMembers.Add("errorState".EmptyProperty(false));
            textBoxMembers.Add("warningState".EmptyProperty(false));
            textBoxMembers.Add("errorTag".EmptyProperty(false));
            textBoxMembers.Add("errorLabel".EmptyProperty(false));
            textBoxMembers.Add("value".EmptyProperty(false));
            textBoxMembers.Add("innerHTML".EmptyProperty(false));
            textBoxMembers.Add("buttonTitle".EmptyProperty(false));
            textBoxMembers.Add("textTitle".EmptyProperty(false));
            textBoxMembers.Add("labelWidth".EmptyProperty(false));
            textBoxMembers.Add("label".EmptyProperty(false));
            textBoxMembers.Add("multiLine".EmptyProperty(true));
            textBoxMembers.Add("editIcon".EmptyProperty(true));
            textBoxMembers.Add("rows".EmptyProperty(false));
            textBoxMembers.Add("maxLength".EmptyProperty(false));
            textBoxMembers.Add("titleBar".EmptyProperty(false));
            textBoxMembers.Add("editorWidth".EmptyProperty(false));
            textBoxMembers.Add("editorHeight".EmptyProperty(false));
            textBoxMembers.Add("allowCrLf".EmptyProperty(false));
            textBoxMembers.Add("authorized".EmptyProperty(false));
            textBoxMembers.Add("buttonDisabled".EmptyProperty(false));
            textBoxMembers.Add("autoButtonTitle".EmptyProperty(false));
            textBoxMembers.Add("allowSpellCheck".EmptyProperty(false));
            textBoxMembers.Add("initComplete".EmptyProperty(true));

            textBoxMembers.Add("focus".EmptyFunction());
            textBoxMembers.Add("addError".EmptyFunction());
            textBoxMembers.Add("addWarning".EmptyFunction());
            textBoxMembers.Add("clearMessage".EmptyFunction());
            textBoxMembers.Add("validate".EmptyFunction());
            textBoxMembers.Add("clickButton".EmptyFunction());
            textBoxMembers.Add("select".EmptyFunction());

            allSymbols.Add(new ClassSymbol("ITextBox", Option.None, Option.None, textBoxMembers, Option.None));


            var unityDocMembers = new List<Symbol>();

            unityDocMembers.Add("DocumentName".EmptyProperty(true));
            unityDocMembers.Add("URI".EmptyProperty(false));
            unityDocMembers.Add("BaseURI".EmptyProperty(false));
            unityDocMembers.Add("AbsoluteURI".EmptyProperty(true));
            unityDocMembers.Add("FormElements".EmptyProperty(true));

            unityDocMembers.Add("ActivateDocument".EmptyFunction());
            unityDocMembers.Add("DeactivateDocument".EmptyFunction());
            unityDocMembers.Add("EnableUIActivation".EmptyFunction());
            unityDocMembers.Add("DisableUIActivation".EmptyFunction());

            unityDocMembers.Add("AllowUIActivate".EmptyProperty(false));
            unityDocMembers.Add("UseSynchronousActivation".EmptyProperty(false));

            unityDocMembers.Add("ShowDialog".EmptyFunction());
            unityDocMembers.Add("ShowDialogEx".EmptyFunction());
            unityDocMembers.Add("CloseDialog".EmptyFunction());

            unityDocMembers.Add("DialogArgument".EmptyProperty(true));
            unityDocMembers.Add("DialogResult".EmptyProperty(true));
            unityDocMembers.Add("IsModeless".EmptyProperty(true));
            unityDocMembers.Add("DocumentMode".EmptyProperty(true));
            unityDocMembers.Add("DialogPositionMode".EmptyProperty(true));
            unityDocMembers.Add("Core".EmptyProperty(true));
            unityDocMembers.Add("DocumentSet".EmptyProperty(true));
            unityDocMembers.Add("FrameWindow".EmptyProperty(true));
            unityDocMembers.Add("Left".EmptyProperty(true));
            unityDocMembers.Add("Top".EmptyProperty(true));
            unityDocMembers.Add("Width".EmptyProperty(true));
            unityDocMembers.Add("Height".EmptyProperty(true));
            unityDocMembers.Add("WindowLeft".EmptyProperty(true));
            unityDocMembers.Add("WindowTop".EmptyProperty(true));
            unityDocMembers.Add("WindowWidth".EmptyProperty(true));
            unityDocMembers.Add("WindowHeight".EmptyProperty(true));

            unityDocMembers.Add("SetPosition".EmptyFunction());

            unityDocMembers.Add("DocumentWindow".EmptyProperty(true));

            unityDocMembers.Add("AllowResize".EmptyProperty(false));
            unityDocMembers.Add("AllowResizeWidth".EmptyProperty(false));
            unityDocMembers.Add("AllowResizeHeight".EmptyProperty(false));
            unityDocMembers.Add("MinimumWidth".EmptyProperty(false));
            unityDocMembers.Add("MinimumHeight".EmptyProperty(false));
            unityDocMembers.Add("MaximumWidth".EmptyProperty(false));
            unityDocMembers.Add("MaximumHeight".EmptyProperty(false));
            unityDocMembers.Add("Opacity".EmptyProperty(false));
            unityDocMembers.Add("AlwaysOnTop".EmptyProperty(false));

            unityDocMembers.Add("BringToForeground".EmptyFunction());
            unityDocMembers.Add("FlashWindow".EmptyFunction());
            unityDocMembers.Add("EnableWindow".EmptyFunction());

            unityDocMembers.Add("IsEnabled".EmptyProperty(true));
            unityDocMembers.Add("Surrogate".EmptyProperty(true));
            unityDocMembers.Add("Script".EmptyProperty(true));
            unityDocMembers.Add("OpticalZoom".EmptyProperty(false));
            unityDocMembers.Add("AllowScrollBar".EmptyProperty(false));

            unityDocMembers.Add("CreateDocumentSet".EmptyFunction());
            unityDocMembers.Add("CreateDocumentWindow".EmptyFunction());

            unityDocMembers.Add("AppContextStreamIn".EmptyProperty(true));
            unityDocMembers.Add("AppContextStreamOut".EmptyProperty(true));
            unityDocMembers.Add("BinaryViewFileName".EmptyProperty(true));
            unityDocMembers.Add("BinaryViewFullPath".EmptyProperty(true));
            unityDocMembers.Add("HTTPTransactions".EmptyProperty(true));

            unityDocMembers.Add("CreateObject".EmptyFunction());

            unityDocMembers.Add("Parameters".EmptyProperty(true));
            unityDocMembers.Add("ShellTasks".EmptyProperty(true));

            unityDocMembers.Add("Invoke".EmptyFunction());
            unityDocMembers.Add("CheckForExistence".EmptyFunction());

            unityDocMembers.Add("ScriptEngine".EmptyProperty(true));

            unityDocMembers.Add("ExecScript".EmptyFunction());

            unityDocMembers.Add("CommandDocumentName".EmptyProperty(false));
            unityDocMembers.Add("CommandDocumentMode".EmptyProperty(false));

            unityDocMembers.Add("MOM".EmptyProperty(true));
            unityDocMembers.Add("SharedStash".EmptyProperty(true));
            unityDocMembers.Add("ProductStash".EmptyProperty(true));
            unityDocMembers.Add("LocalStash".EmptyProperty(true));

            unityDocMembers.Add("LockStash".EmptyFunction());
            unityDocMembers.Add("Set".EmptyFunction());
            unityDocMembers.Add("Get".EmptyFunction());
            unityDocMembers.Add("Exists".EmptyFunction());
            unityDocMembers.Add("IsObject".EmptyFunction());

            unityDocMembers.Add("ProductCenter".EmptyProperty(true));
            unityDocMembers.Add("ShellSecurity".EmptyProperty(true));

            unityDocMembers.Add("CodeQuery".EmptyProperty(true));
            unityDocMembers.Add("ShellCache".EmptyProperty(true));
            unityDocMembers.Add("NodeID".EmptyProperty(false));

            unityDocMembers.Add("CreateCommand".EmptyFunction());

            unityDocMembers.Add("Title".EmptyProperty(false));
            unityDocMembers.Add("StatusMessage".EmptyProperty(false));
            unityDocMembers.Add("CommandMenu".EmptyProperty(true));
            unityDocMembers.Add("LegacyMenu".EmptyProperty(true));
            unityDocMembers.Add("Events".EmptyProperty(true));

            unityDocMembers.Add("Print".EmptyFunction());
            unityDocMembers.Add("PageSetup".EmptyFunction());
            unityDocMembers.Add("ExecuteCommand".EmptyFunction());
            unityDocMembers.Add("QueryStatus".EmptyFunction());

            unityDocMembers.Add("MessageArea".EmptyProperty(true));
            unityDocMembers.Add("ShellMessages".EmptyProperty(true));
            unityDocMembers.Add("AutoErrorMode".EmptyProperty(false));
            unityDocMembers.Add("WaitWindow".EmptyProperty(true));

            unityDocMembers.Add("InfoBox".EmptyFunction());

            unityDocMembers.Add("IsSpellCheckerAvailable".EmptyProperty(true));

            unityDocMembers.Add("CheckSpelling".EmptyFunction());

            unityDocMembers.Add("CacheLatency".EmptyProperty(false));
            unityDocMembers.Add("OMSManager".EmptyProperty(true));
            unityDocMembers.Add("OMSMessageTypes".EmptyProperty(true));
            unityDocMembers.Add("OMSStatus".EmptyProperty(true));
            unityDocMembers.Add("OMSTargets".EmptyProperty(true));

            unityDocMembers.Add("ShowContextHelp".EmptyFunction());
            unityDocMembers.Add("ExecuteApplicationCommand".EmptyFunction());
            unityDocMembers.Add("Save".EmptyFunction());
            unityDocMembers.Add("Activate".EmptyFunction());

            unityDocMembers.Add("ActiveDocumentName".EmptyProperty(false));
            unityDocMembers.Add("ActiveDocuments".EmptyProperty(true));

            unityDocMembers.Add("Encrypt".EmptyFunction());

            unityDocMembers.Add("ModelessTitle".EmptyProperty(false));
            unityDocMembers.Add("NavMenus".EmptyProperty(true));
            unityDocMembers.Add("PerformDirtyCheck".EmptyProperty(false));
            unityDocMembers.Add("SendContext".EmptyProperty(false));
            unityDocMembers.Add("ShellSession".EmptyProperty(true));

            unityDocMembers.Add("CreateGUID".EmptyFunction());
            unityDocMembers.Add("CreateID".EmptyFunction());
            unityDocMembers.Add("Sleep".EmptyFunction());
            unityDocMembers.Add("EmptyQueue".EmptyFunction());
            unityDocMembers.Add("PostCallback".EmptyFunction());

            unityDocMembers.Add("Theme".EmptyProperty(true));
            unityDocMembers.Add("Palette".EmptyProperty(true));

            unityDocMembers.Add("ConvertFromWebColor".EmptyFunction());
            unityDocMembers.Add("ConvertToWebColor".EmptyFunction());
            unityDocMembers.Add("ConvertToRGB".EmptyFunction());
            unityDocMembers.Add("ShiftFocus".EmptyFunction());
            unityDocMembers.Add("SendMessage".EmptyFunction());
            unityDocMembers.Add("GetWindowLong".EmptyFunction());
            unityDocMembers.Add("SetWindowLong".EmptyFunction());
            unityDocMembers.Add("TranslateX".EmptyFunction());
            unityDocMembers.Add("TranslateY".EmptyFunction());

            unityDocMembers.Add("DeveloperMode".EmptyProperty(true));

            unityDocMembers.Add("ReloadDocument".EmptyFunction());
            unityDocMembers.Add("Debug".EmptyFunction());

            unityDocMembers.Add("TickCount".EmptyProperty(true));
            unityDocMembers.Add("DocumentDomainModel".EmptyProperty(false));
            unityDocMembers.Add("EnableDebugBinding".EmptyProperty(false));
            unityDocMembers.Add("DebugLaunchModel".EmptyProperty(false));

            unityDocMembers.Add("CreateType".EmptyFunction());
            unityDocMembers.Add("FindBinaryViewPath".EmptyFunction());

            unityDocMembers.Add("Locale".EmptyProperty(true));

            unityDocMembers.Add("GetSpellingErrors".EmptyFunction());

            allSymbols.Add(new ClassSymbol("IUnityDocument", Option.None, Option.None, unityDocMembers, Option.None));


            var shellMsgMembers = new List<Symbol>();

            shellMsgMembers.Add("ID".EmptyProperty(false));
            shellMsgMembers.Add("ShortMessage".EmptyProperty(false));
            shellMsgMembers.Add("LongMessage".EmptyProperty(false));
            shellMsgMembers.Add("HelpFile".EmptyProperty(false));
            shellMsgMembers.Add("HelpContext".EmptyProperty(false));
            shellMsgMembers.Add("TagID".EmptyProperty(false));
            shellMsgMembers.Add("DisplayCategory".EmptyProperty(false));
            shellMsgMembers.Add("Category".EmptyProperty(false));
            shellMsgMembers.Add("ParentID".EmptyProperty(false));
            shellMsgMembers.Add("RowID".EmptyProperty(false));
            shellMsgMembers.Add("Timestamp".EmptyProperty(false));
            shellMsgMembers.Add("DoAlert".EmptyProperty(false));
            shellMsgMembers.Add("AllowRemove".EmptyProperty(false));
            shellMsgMembers.Add("Command".EmptyProperty(true));
            shellMsgMembers.Add("HasCommand".EmptyProperty(true));
            shellMsgMembers.Add("IsActionable".EmptyProperty(true));
            shellMsgMembers.Add("ContextMenu".EmptyProperty(true));
            shellMsgMembers.Add("Number".EmptyProperty(false));
            shellMsgMembers.Add("Location".EmptyProperty(false));
            shellMsgMembers.Add("Context".EmptyProperty(false));

            allSymbols.Add(new ClassSymbol("IShellMessage", Option.None, Option.None, shellMsgMembers, Option.None));


            var shellMessagesMembers = new List<Symbol>();

            shellMessagesMembers.Add("Item".EmptyFunction());
            shellMessagesMembers.Add("Add".EmptyFunction());
            shellMessagesMembers.Add("AddEMPErrors".EmptyFunction());
            shellMessagesMembers.Add("Remove".EmptyFunction());
            shellMessagesMembers.Add("Clear".EmptyFunction());
            shellMessagesMembers.Add("ClearRemovableMessages".EmptyFunction());

            shellMessagesMembers.Add("Count".EmptyProperty(true));

            shellMessagesMembers.Add("InsertMode".EmptyProperty(false));

            shellMessagesMembers.Add("ResetAttention".EmptyFunction());

            shellMessagesMembers.Add("_NewEnum".EmptyProperty(true));

            allSymbols.Add(new ClassSymbol("IShellMessages", Option.None, Option.None, shellMessagesMembers, Option.None));


            var shellTaskMembers = new List<Symbol>();

            shellTaskMembers.Add("TaskID".EmptyProperty(true));
            shellTaskMembers.Add("TaskState".EmptyProperty(true));

            shellTaskMembers.Add("Execute".EmptyFunction());

            shellTaskMembers.Add("CompleteCallback".EmptyProperty(true));
            shellTaskMembers.Add("ErrorCallback".EmptyProperty(true));

            shellTaskMembers.Add(new PropertySymbol("OnComplete", Option.None, "OnComplete".EmptyPropertySet().Some<FunctionSymbol>()));
            shellTaskMembers.Add(new PropertySymbol("OnError", Option.None, "OnError".EmptyPropertySet().Some<FunctionSymbol>()));

            shellTaskMembers.Add("Item".EmptyFunction());

            shellTaskMembers.Add("Count".EmptyProperty(true));
            shellTaskMembers.Add("_NewEnum".EmptyProperty(true));

            shellTaskMembers.Add("AddCacheUpdateServiceRequest".EmptyFunction());
            shellTaskMembers.Add("AddHTTPTransaction".EmptyFunction());
            shellTaskMembers.Add("EnlistHTTPTransaction".EmptyFunction());
            shellTaskMembers.Add("AddBaleInstallerRequest".EmptyFunction());
            shellTaskMembers.Add("GetTransaction".EmptyFunction());
            shellTaskMembers.Add("GetBaleInstallerResult".EmptyFunction());

            shellTaskMembers.Add("Parameter".EmptyProperty(false));

            allSymbols.Add(new ClassSymbol("IShellTask", Option.None, Option.None, shellTaskMembers, Option.None));

            var shellTasksMembers = new List<Symbol>();

            shellTasksMembers.Add("Item".EmptyFunction());
            shellTasksMembers.Add("Add".EmptyFunction());
            shellTasksMembers.Add("Clear".EmptyFunction());

            shellTasksMembers.Add("Count".EmptyProperty(true));
            shellTasksMembers.Add("Count".EmptyProperty(true));

            shellTasksMembers.Add("_NewEnum".EmptyFunction());

            allSymbols.Add(new ClassSymbol("IShellTasks", Option.None, Option.None, shellTasksMembers, Option.None));


            var msgAreaMembers = new List<Symbol>();

            msgAreaMembers.Add("Visible".EmptyProperty(false));
            msgAreaMembers.Add("DoAttention".EmptyProperty(false));

            allSymbols.Add(new ClassSymbol("IMessageArea", Option.None, Option.None, msgAreaMembers, Option.None));


            var waitWinMembers = new List<Symbol>();

            waitWinMembers.Add("Show".EmptyFunction());
            waitWinMembers.Add("Close".EmptyFunction());
            waitWinMembers.Add("AutoShow".EmptyFunction());

            waitWinMembers.Add("Mode".EmptyProperty(false));
            waitWinMembers.Add("Delay".EmptyProperty(false));
            waitWinMembers.Add("Text".EmptyProperty(false));
            waitWinMembers.Add("OffsetLeft".EmptyProperty(false));
            waitWinMembers.Add("OffsetRight".EmptyProperty(false));
            waitWinMembers.Add("OffsetTop".EmptyProperty(false));
            waitWinMembers.Add("OffsetBottom".EmptyProperty(false));

            waitWinMembers.Add("Theme".EmptyProperty(true));

            allSymbols.Add(new ClassSymbol("IWaitWindow", Option.None, Option.None, waitWinMembers, Option.None));


            var cusrMembers = new List<Symbol>();

            cusrMembers.Add("ServiceInfo".EmptyProperty(true));
            cusrMembers.Add("SiteID".EmptyProperty(false));

            cusrMembers.Add("AddCacheItem".EmptyFunction());

            allSymbols.Add(new ClassSymbol("ICacheUpdateServiceRequest", Option.None, Option.None, cusrMembers, Option.None));


            var securityMembers = new List<Symbol>();

            securityMembers.Add("Deserialize".EmptyFunction());

            securityMembers.Add("UserID".EmptyProperty(true));
            securityMembers.Add("SecurityStream".EmptyProperty(true));

            securityMembers.Add(new PropertySymbol("OrgChart", Option.None, "OrgChart".EmptyPropertySet().Some<FunctionSymbol>()));

            securityMembers.Add("IsSuperUser".EmptyFunction());
            securityMembers.Add("SuperUser".EmptyFunction());
            securityMembers.Add("LocateByKey".EmptyFunction());
            securityMembers.Add("Locate".EmptyFunction());
            securityMembers.Add("GetRightsCollection".EmptyFunction());
            securityMembers.Add("GetNodesCollection".EmptyFunction());

            securityMembers.Add("Count".EmptyProperty(true));

            securityMembers.Add("LocateByList".EmptyFunction());
            securityMembers.Add("GetNodesCollectionByRightsList".EmptyFunction());
            securityMembers.Add("LocateBelowProductNodeID".EmptyFunction());
            securityMembers.Add("GetNodesByRightProductNodeID".EmptyFunction());
            securityMembers.Add("GetNodesByRightsProductNodeID".EmptyFunction());
            securityMembers.Add("LocateAtNode".EmptyFunction());
            securityMembers.Add("LoadOrgChart".EmptyFunction());

            allSymbols.Add(new ClassSymbol("ISecurity", Option.None, Option.None, securityMembers, Option.None));


            var merCoreMembers = new List<Symbol>();

            merCoreMembers.Add("CommandLineTokens".EmptyProperty(true));
            merCoreMembers.Add("DateValidator".EmptyProperty(true));
            merCoreMembers.Add("NetworkConfiguration".EmptyProperty(true));
            merCoreMembers.Add("NumericValidator".EmptyProperty(true));
            merCoreMembers.Add("ShellCache".EmptyProperty(true));
            merCoreMembers.Add("ShellInfo".EmptyProperty(true));
            merCoreMembers.Add("ShellLog".EmptyProperty(true));
            merCoreMembers.Add("ShellPrinters".EmptyProperty(true));
            merCoreMembers.Add("ShellSecurity".EmptyProperty(true));
            merCoreMembers.Add("StructuredStorage".EmptyProperty(true));
            merCoreMembers.Add("UserInfo".EmptyProperty(true));
            merCoreMembers.Add("ActiveDocuments".EmptyProperty(true));
            merCoreMembers.Add("ConfigurationManager".EmptyProperty(true));
            merCoreMembers.Add("FrameWindow".EmptyProperty(true));
            merCoreMembers.Add("IPCManager".EmptyProperty(true));
            merCoreMembers.Add("NavMenus".EmptyProperty(true));
            merCoreMembers.Add("OMSManager".EmptyProperty(true));
            merCoreMembers.Add("OMSStatus".EmptyProperty(true));
            merCoreMembers.Add("ScriptEngines".EmptyProperty(true));
            merCoreMembers.Add("ServiceAgent".EmptyProperty(true));
            merCoreMembers.Add("SessionStash".EmptyProperty(true));
            merCoreMembers.Add("ShellBarcode".EmptyProperty(true));
            merCoreMembers.Add("ShellHelp".EmptyProperty(true));
            merCoreMembers.Add("ShellRegistry".EmptyProperty(true));
            merCoreMembers.Add("ShellSession".EmptyProperty(true));
            merCoreMembers.Add("ShellStash".EmptyProperty(true));
            merCoreMembers.Add("ShellUtility".EmptyProperty(true));
            merCoreMembers.Add("SpellCheckers".EmptyProperty(true));
            merCoreMembers.Add("UserStash".EmptyProperty(true));
            merCoreMembers.Add("ContentWindow".EmptyProperty(true));
            merCoreMembers.Add("ShellUI".EmptyProperty(true));
            merCoreMembers.Add("OMSMessageTypes".EmptyProperty(true));
            merCoreMembers.Add("OMSTargets".EmptyProperty(true));
            merCoreMembers.Add("CommandBar".EmptyProperty(true));
            merCoreMembers.Add("ProductList".EmptyProperty(true));
            merCoreMembers.Add("StatusBar".EmptyProperty(true));
            merCoreMembers.Add("StorageManager".EmptyProperty(true));

            allSymbols.Add(new ClassSymbol("IMeridianCore", Option.None, Option.None, merCoreMembers, Option.None));

            return allSymbols;
        }

        public static Unit WriteAllFiles(String baseDataDir)
        {
            var vbSymbols     = Symbols.VbScriptHostSymbols();
            var vbSymbolsFile = Path.Combine(baseDataDir, VbScriptFile);

            if (File.Exists(vbSymbolsFile))
                File.Delete(vbSymbolsFile);

            vbSymbols.ToHostSymbols().WriteJson(vbSymbolsFile);

            var webSymbols = Symbols.WebApiSymbols();
            var webSymbolsFile = Path.Combine(baseDataDir, WebApiFile);

            if (File.Exists(webSymbolsFile))
                File.Delete(webSymbolsFile);

            webSymbols.ToHostSymbols("page-elements").WriteJson(webSymbolsFile);


            var tylerSymbols = HostSymbolFiles.TylerHostSymbols();
            var tylerSymbolsFile = Path.Combine(baseDataDir, TylerHostFile);

            if (File.Exists(tylerSymbolsFile))
                File.Delete(tylerSymbolsFile);

            tylerSymbols.ToHostSymbols().WriteJson(tylerSymbolsFile);

            return Unit.Value;
        }

    }

}