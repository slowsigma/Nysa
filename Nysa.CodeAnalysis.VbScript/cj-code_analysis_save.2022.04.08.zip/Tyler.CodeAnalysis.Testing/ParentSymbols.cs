using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Rescript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using SyntaxNode = Dorata.Text.Parsing.Node;
using ProgramNode = Nysa.CodeAnalysis.VbScript.Semantics.Program;

using Tyler.CodeAnalysis.VbScript;
using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.CodeAnalysis.Testing
{

    public static class ParentSymbols
    {
        public static String PathNormal(this String @this)
            => @this.Replace("\\", "/").Trim();

        public static void FindParentSymbols(String baseDataDir)
        {
            var distinct  = new Dictionary<String, Symbol>();
            var consensus = new Dictionary<String, Int32>();
            var winners   = new Dictionary<String, (Symbol Symbol, Int32 Instances)>(StringComparer.OrdinalIgnoreCase);
            var typeDiffs = new List<String>();

            foreach (var file in Directory.EnumerateFiles("C:\\Git\\cj-odyssey_mainline\\Webs", "*.*", SearchOption.AllDirectories).Where(f => f.DataEndsWith(".htm") || f.DataEndsWith(".html")))
            {
                if (file.IndexOf("Webs\\H5") < 0)
                {
                    if (file.ToContent() is Confirmed<Content> content && content.Value.Parse() is Confirmed<Parse> parse)
                    {
                        var symbols = parse.Value switch
                        {
                            HtmlParse html => html.VbsParses.Select(vbp => vbp.ToProgram().Map(p => p.ToJavaScriptSymbols())).ToList(),
                            XHtmlParse xhtml => xhtml.VbsParses.Select(vbp => vbp.ToProgram().Map(p => p.ToJavaScriptSymbols())).ToList(),
                            _ => new List<Suspect<CodeSymbols>>()
                        };

                        var finalSymbols = new CodeSymbols(None<Symbol>.Enumerable());

                        foreach (var symbol in symbols)
                        {
                            if (symbol is Confirmed<CodeSymbols> goodSyms)
                            {
                                finalSymbols = new CodeSymbols(finalSymbols.Members.Concat(goodSyms.Value.Members), new String[] { content.Value.Source });
                            }
                        }

                        if (finalSymbols.Index.ContainsKey("tabprocessstate") && finalSymbols.Index["tabprocessstate"] is FunctionSymbol)
                        {
                            foreach (var symbol in finalSymbols.Members.Where(m => m is ConstantSymbol || m is VariableSymbol || m is FunctionSymbol))
                            {
                                if (distinct.ContainsKey(symbol.Name))
                                {
                                    consensus[symbol.Name] = consensus[symbol.Name] + 1;
                                }
                                else
                                {
                                    distinct.Add(symbol.Name, symbol);
                                    consensus.Add(symbol.Name, 1);
                                }

                                if (winners.ContainsKey(symbol.Name))
                                {
                                    var winType = winners[symbol.Name].Symbol.GetType();
                                    var symType = symbol.GetType();

                                    if (winType.Name != symType.Name)
                                        typeDiffs.Add($"{symbol.Name} - {winType.Name} / {symType.Name}");

                                    if (winners[symbol.Name].Instances < consensus[symbol.Name])
                                        winners[symbol.Name] = (symbol, consensus[symbol.Name]);
                                }
                                else
                                {
                                    winners.Add(symbol.Name, (symbol, 1));
                                }
                            }
                        }
                    }
                }
            }

            var misses = consensus.Where(c => winners[c.Key].Instances != c.Value);

            var superParent = new ClassSymbol("_parent", Option.None, Option.None, winners.Select(w => w.Value.Symbol), Option.None);

            var final = new CodeSymbols(Return.Enumerable((Symbol)superParent, new VariableSymbol("parent", Option.None, Option.None, true, "_parent".Some())));

            File.WriteAllText(Path.Combine(baseDataDir, "SuperParent.Names.txt"), String.Join("\r\n", winners.Select(m => m.Key)));

            File.WriteAllText(Path.Combine(baseDataDir, "SuperParent.Collisions.txt"), String.Join("\r\n", misses.Select(kv => $"{kv.Key} / {kv.Value} - not selected")
                                                                                                                 .Concat(typeDiffs)));

            final.WriteJson(Path.Combine(baseDataDir, "SuperParent.json"));
        }

    }

}