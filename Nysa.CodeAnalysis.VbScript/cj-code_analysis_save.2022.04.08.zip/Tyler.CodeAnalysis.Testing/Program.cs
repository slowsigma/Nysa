﻿using System;
using System.IO;

namespace Tyler.CodeAnalysis.Testing
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var workingDir = @"C:\Git\cj-code_analysis\Tyler.CodeAnalysis.Testing\Data";

            HostSymbolFiles.WriteAllFiles(workingDir);
            //ParentSymbols.FindParentSymbols(workingDir);

            //RescriptTests.TestStatementFunctions(workingDir);
            //RescriptTests.TrySingleFile(workingDir);
            //RescriptTests.WriteGlobalSymbolsJson(workingDir);
            //RescriptTests.ReadGlobalSymbolsJson(workingDir);
        }
    }
}