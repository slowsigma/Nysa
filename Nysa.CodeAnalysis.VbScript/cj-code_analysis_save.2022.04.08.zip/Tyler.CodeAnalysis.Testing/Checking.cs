using System;
using System.Collections.Generic;
using System.Linq;

using Dorata.Binary;
using Dorata.Collections;
using Dorata.Logics;
using Dorata.Text;
using Dorata.Text.Lexing;
using Dorata.Text.Parsing;
using Dorata.Text.Tree;

namespace Tyler.CodeAnalysis.Testing
{

    public static class Checking
    {

        public static void MethodOne()
        {
            VBScript.ParseError parseError;
            var test = VBScript.END_OF_INPUT;

            var strNode = new StringNode("v");

        }
        
    }


}