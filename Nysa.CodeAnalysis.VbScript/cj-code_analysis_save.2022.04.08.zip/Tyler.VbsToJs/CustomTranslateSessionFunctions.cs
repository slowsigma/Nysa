using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Web;
using System.Xml;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Rescript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using SyntaxNode = Dorata.Text.Parsing.Node;
using ProgramNode = Nysa.CodeAnalysis.VbScript.Semantics.Program;

using Tyler.CodeAnalysis.VbScript;
using Tyler.CodeAnalysis.VbScript.Rescript;

using HtmlAgilityPack;

namespace Tyler.VbsToJs
{

    public static class CustomTranslateSessionFunctions
    {

        public static Unit ProcessHtml(HtmlDocument document, TranslateSession session, String documentFullFilePath)
        {
            var needsDocType = true;
            var removes      = new List<HtmlNode>();
            var objectid     = (String?)null;

            foreach (var node in document.DocumentNode.DescendantsAndSelf().ToList())
            {
                if (node is HtmlCommentNode comment)
                {
                    if (node.OuterHtml.DataStartsWith("<!doctype "))
                        needsDocType = false;
                    if (node.OuterHtml.DataStartsWith("<?import") && node.OuterHtml.DataIndexOf(objectid ?? "behaviorfactory") > 0)
                    {
                        removes.Add(node);

                        var behaviors = document.CreateElement("script");

                        behaviors.SetAttributeValue("src", String.Concat("/", session.Settings.OutFolderUri, "/Common/Scripts/TylBehaviors.js"));
                        behaviors.SetAttributeValue("type", "text/javascript");

                        var indent = node.PreviousSibling
                                         .Make(p => p is HtmlTextNode t
                                                    ? new String(' ', t.Text.Reverse().TakeWhile(c => c == ' ').Count())
                                                    : String.Empty);

                        node.ParentNode.InsertBefore(behaviors, node);
                        node.ParentNode.InsertAfter(document.CreateTextNode(String.Concat("\r\n", indent)), behaviors);
                    }
                }
                else if (node.NodeType == HtmlNodeType.Element)
                {
                    var tylNs = node.Attributes.FirstOrNone(a => a.Name.DataEquals("xmlns:tyl"));
                    var classId = node.Attributes.FirstOrNone(a => a.Name.DataEquals("classid"));
                    var impNs = node.Attributes.FirstOrNone(a => a.Name.DataEquals("namespace"));
                    var href = node.Attributes.FirstOrNone(a => a.Name.DataEquals("href"));

                    if (tylNs is Some<HtmlAttribute> someTylNs)
                        someTylNs.Value.Remove();

                    if (node.Name.DataEquals("object") && classId is Some<HtmlAttribute> someClassId && someClassId.Value.Value.DataEndsWith("0D473317-55F7-4979-96CC-F78F767CFB78"))
                    {
                        removes.Add(node);
                        objectid = node.GetAttributeValue("id", String.Empty);
                    }
                        
                    if (impNs is Some<HtmlAttribute> someImpNs)
                        removes.Add(node);

                    if (node.Name.DataStartsWith("tyl:"))
                        node.Name = String.Concat("tyl-", node.Name.Substring(4));

                    if (node.Name.DataEquals("link") && href is Some<HtmlAttribute> someHref && someHref.Value.Value.DataEndsWith(".css"))
                    {
                        var hrefStr  = HttpUtility.UrlDecode(someHref.Value.Value);
                        var hrefFull = hrefStr.ToFullReferenceFilePath(session.Input.Root, documentFullFilePath);

                        if (hrefFull is Some<String> someHrefFull)
                        {
                            var hrefDest = someHrefFull.Value.ToFullDestinationFilePath(session.Input.Root, session.Settings.OutFolderSave);

                            var destInfo = new FileInfo(hrefDest);

                            if (!Directory.Exists(destInfo.Directory?.FullName ?? String.Empty))
                                Directory.CreateDirectory(destInfo.Directory?.FullName ?? String.Empty);

                            File.Copy(someHrefFull.Value, hrefDest, session.Overwrite);

                            if (hrefStr.DataStartsWith("/"))
                                node.SetAttributeValue("href", HttpUtility.UrlPathEncode(String.Concat("/", session.Settings.OutFolderUri, hrefStr)));
                            else
                                node.SetAttributeValue("href", HttpUtility.UrlPathEncode(hrefStr));
                        }
                    }
                }

            }

            foreach (var node in removes)
                node.Remove();

            if (needsDocType)
            {
                var docType = document.CreateComment("<!DOCTYPE html>");
                var html    = document.DocumentNode.SelectSingleNode("/html");
                var crlf    = document.CreateTextNode("\r\n");

                document.DocumentNode.InsertBefore(docType, html);
                document.DocumentNode.InsertBefore(crlf, html);
            }

            return Unit.Value;
        }

        private static XmlAttribute? TylNamespaceName(XmlDocument document)
        {
            var variations = new HashSet<String>(StringComparer.OrdinalIgnoreCase);

            variations.Add("http://tsgweb.com");
            variations.Add("http://www.tsgweb.com");
            variations.Add("http://tylertechnologies.com");
            variations.Add("http://www.tylertechnologies.com");
            variations.Add("urn:tyl");

            var descendants = document.SelectNodes("//*");

            return descendants != null
                   ? descendants.Cast<XmlElement>()
                                .SelectMany(d => d.Attributes
                                                  .Cast<XmlAttribute>()
                                                  .Where(a => a.Name.DataEquals("xmlns:tyl"))) // || variations.Contains(a.Value)
                                .FirstOrDefault()
                   : null;
        }

        public static Unit ProcessXsl(XmlDocument document, TranslateSession session, String documentFullFilePath)
        {
            var descendants  = document.SelectNodes("//*")?.Cast<XmlNode>() ?? None<XmlNode>.Enumerable();

            foreach (var node in descendants)
            {
                if (node is XmlElement elem)
                {
                    var href = elem.Attributes.Cast<XmlAttribute>().FirstOrNone(a => a.LocalName.DataEquals("href"));

// see if we can change these names in serialization

                    // if (elem.Name.DataStartsWith("tyl:"))
                    // {
                    //     elem.Name = (String.Concat("tyl-", elem.Name.LocalName));
                    // }

                    if (elem.LocalName.DataEquals("link") && href is Some<XmlAttribute> someHref && someHref.Value.Value.DataEndsWith(".css"))
                    {
                        var hrefStr  = HttpUtility.UrlDecode(someHref.Value.Value);
                        var hrefFull = hrefStr.ToFullReferenceFilePath(session.Input.Root, documentFullFilePath);

                        if (hrefFull is Some<String> someHrefFull)
                        {
                            var hrefDest = someHrefFull.Value.ToFullDestinationFilePath(session.Input.Root, session.Settings.OutFolderSave);

                            var destInfo = new FileInfo(hrefDest);

                            if (!Directory.Exists(destInfo.Directory?.FullName ?? String.Empty))
                                Directory.CreateDirectory(destInfo.Directory?.FullName ?? String.Empty);

                            File.Copy(someHrefFull.Value, hrefDest, session.Overwrite);

                            if (hrefStr.DataStartsWith("/"))
                                elem.SetAttribute("href", HttpUtility.UrlPathEncode(String.Concat("/", session.Settings.OutFolderUri, hrefStr)));
                            else
                                elem.SetAttribute("href", HttpUtility.UrlPathEncode(hrefStr));
                        }
                    }
                }
            }

            // NOT REMOVING THE NAMESPACES IN XSL
            // if (tylNsN != null)
            //     tylNsN.Remove();

            return Unit.Value;
        }

        public static Unit ProcessXHtml(XmlDocument document, TranslateSession session, String documentFullFilePath)
        {
            var needsDocType = document.DocumentType == null;
            var removeElems  = new List<XmlElement>();
            var removeAttrs  = new List<XmlAttribute>();
            var removeProcs  = new List<XmlProcessingInstruction>();
            var objectid     = (String?)null;


            var descendants  = document.SelectNodes("//*")?.Cast<XmlNode>() ?? None<XmlNode>.Enumerable();

            foreach (var node in descendants)
            {
                if (node is XmlElement elem)
                {
                    elem.Attributes
                        .Cast<XmlAttribute>()
                        .FirstOrNone(a => a.Name.DataEquals("xmlns:tyl"))
                        .Affect(a => { removeAttrs.Add(a); });

                    var classId = elem.Attributes.Cast<XmlAttribute>().FirstOrNone(a => a.LocalName.DataEquals("classid"));
                    var impNs = elem.Attributes.Cast<XmlAttribute>().FirstOrNone(a => a.LocalName.DataEquals("namespace"));
                    var href = elem.Attributes.Cast<XmlAttribute>().FirstOrNone(a => a.LocalName.DataEquals("href"));

                    if (elem.LocalName.DataEquals("object") && classId is Some<XmlAttribute> someClassId && someClassId.Value.Value.DataEndsWith("0D473317-55F7-4979-96CC-F78F767CFB78"))
                    {
                        removeElems.Add(elem);

                        objectid = elem.Attributes.Cast<XmlAttribute>().FirstOrNone(a => a.LocalName.DataEquals("id")).Map(a => a.Value) is Some<String> someId
                                   ? someId.Value
                                   : null;
                    }
                        
// see if we can change these names in serialization

                    // if (tylNsN != null && elem.Name.NamespaceName.DataEquals(tylNsN.Value))
                    // {
                    //     elem.Name = (XName)(String.Concat("tyl-", elem.Name.LocalName));
                    // }

                    if (elem.LocalName.DataEquals("link") && href is Some<XmlAttribute> someHref && someHref.Value.Value.DataEndsWith(".css"))
                    {
                        var hrefStr  = HttpUtility.UrlDecode(someHref.Value.Value);
                        var hrefFull = hrefStr.ToFullReferenceFilePath(session.Input.Root, documentFullFilePath);

                        if (hrefFull is Some<String> someHrefFull)
                        {
                            var hrefDest = someHrefFull.Value.ToFullDestinationFilePath(session.Input.Root, session.Settings.OutFolderSave);

                            var destInfo = new FileInfo(hrefDest);

                            if (!Directory.Exists(destInfo.Directory?.FullName ?? String.Empty))
                                Directory.CreateDirectory(destInfo.Directory?.FullName ?? String.Empty);

                            File.Copy(someHrefFull.Value, hrefDest, session.Overwrite);

                            if (hrefStr.DataStartsWith("/"))
                                elem.SetAttribute("href", HttpUtility.UrlPathEncode(String.Concat("/", session.Settings.OutFolderUri, hrefStr)));
                            else
                                elem.SetAttribute("href", HttpUtility.UrlPathEncode(hrefStr));
                        }
                    }
                }
                else if (node is XmlProcessingInstruction proc)
                {
                    if (proc.Target.DataEquals("import") && proc.Data.DataIndexOf(objectid ?? "behaviorfactory") > 0)
                    {
                        removeProcs.Add(proc);

                        var global = document.CreateElement("script");


                        global.SetAttribute("src", String.Concat("/", session.Settings.OutFolderUri, "Common/Scripts/TylBehaviors.js"));
                        global.SetAttribute("type", "text/javascript");

                        var indent = proc.PreviousSibling
                                         .Make(p => p is XmlText t
                                                    ? String.Concat(new String(' ', t.InnerText.Reverse().TakeWhile(c => c == ' ').Count()), "\r\n")
                                                    : "\r\n");

                        var spacer = document.CreateTextNode(indent);

                        proc.ParentNode.InsertBefore(global, proc);
                        proc.ParentNode.InsertBefore(spacer, proc);
                    }
                        
                }
            }

            foreach (var attr in removeAttrs)
                attr.ParentNode.RemoveChild(attr);
            
            foreach (var elem in removeElems)
                elem.ParentNode.RemoveChild(elem);

            foreach (var proc in removeProcs)
                proc.ParentNode.RemoveChild(proc);

            if (needsDocType)
            {
                var docType = document.CreateDocumentType("html", null, null, null);

                document.PrependChild(docType);
                document.DocumentElement.InsertBefore(document.CreateTextNode("\r\n"), document.DocumentElement.FirstChild);
            }

            return Unit.Value;
        }

    }

}