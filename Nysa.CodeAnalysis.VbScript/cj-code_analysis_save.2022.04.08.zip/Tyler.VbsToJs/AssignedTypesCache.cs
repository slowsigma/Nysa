using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

using Nysa.Logics;

namespace Tyler.VbsToJs
{

    public class AssignedTypesCache
    {
        private ConcurrentDictionary<String, IReadOnlyDictionary<String, String>> _Cache;

        public AssignedTypesCache()
        {
            this._Cache = new ConcurrentDictionary<String, IReadOnlyDictionary<String, String>>(StringComparer.OrdinalIgnoreCase);
        }

        public Option<IReadOnlyDictionary<String, String>> GetTypes(String source)
        {
            var  item = (IReadOnlyDictionary<String, String>?)null;

            return this._Cache.TryGetValue(source, out item)
                   ? item.Some()
                   : Option.None;
        }

        public Boolean TryAdd(String source, IReadOnlyDictionary<String, String> item)
            => this._Cache.TryAdd(source, item);
    }

}