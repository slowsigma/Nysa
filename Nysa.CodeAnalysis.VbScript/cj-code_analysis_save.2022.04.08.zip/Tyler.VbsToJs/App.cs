using System;

namespace Tyler.VbsToJs
{

    public static class App
    {
        public static readonly String Name = "Tyler.VbsToJs";
    }

}