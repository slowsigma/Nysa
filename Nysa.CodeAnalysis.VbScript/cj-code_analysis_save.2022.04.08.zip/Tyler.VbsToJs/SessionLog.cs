using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

using Nysa.Logics;


namespace Tyler.VbsToJs
{

    public class SessionLog
    {
        private String                      _FilePath;
        private FileStream                  _FileStream;
        private StreamWriter                _FileWriter;
        private BlockingCollection<String>  _Messages;

        public SessionLog(String filePath)
        {
            this._FilePath      = filePath;
            this._FileStream    = new FileStream(this._FilePath, FileMode.OpenOrCreate);
            this._FileWriter    = new StreamWriter(this._FileStream);
            this._Messages      = new BlockingCollection<String>();

            Task.Run(() => WriteMessages());
        }

        public Action<String> AddMessage
            => s => { if (!this._Messages.IsAddingCompleted) this._Messages.Add(s); };

        public Unit Shutdown()
        {
            this._Messages.CompleteAdding();
            if (!this._Messages.IsCompleted)
                Thread.Sleep(1000);

            this._FileWriter.Flush();
            this._FileWriter.Close();

            this._FileStream.Dispose();
            this._FileWriter.Dispose();

            return Unit.Value;
        }

        private void WriteMessages()
        {
            try
            {
                foreach (var msg in this._Messages.GetConsumingEnumerable())
                {
                    this._FileWriter.WriteLine(msg);
                }
            }
            catch
            {
            }
        }
    }

}