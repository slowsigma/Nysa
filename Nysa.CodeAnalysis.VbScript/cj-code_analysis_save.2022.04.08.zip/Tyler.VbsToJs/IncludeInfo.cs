using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;


using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using ProgramNode = Nysa.CodeAnalysis.VbScript.Semantics.Program;
using Nysa.Logics;
using Nysa.Text;

using Dorata.Text.Parsing;

using Tyler.CodeAnalysis.VbScript;
using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.VbsToJs
{

    public class IncludeInfo
    {
        public CodeSymbols                          Symbols         { get; private set; }
        public IReadOnlyDictionary<String, String>  AssignedTypes   { get; private set; }
        public Option<VbScriptParse>                Parse           { get; private set; }
        public Option<ProgramNode>                  Root            { get; private set; }

        public IncludeInfo(CodeSymbols symbols, IReadOnlyDictionary<String, String> assignedTypes, Option<VbScriptParse> parse, Option<ProgramNode> root)
        {
            this.Symbols        = symbols;
            this.AssignedTypes  = assignedTypes;
            this.Parse          = parse;
            this.Root           = root;
        }
    }

}