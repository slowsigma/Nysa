using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

using Nysa.Logics;

using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.VbsToJs
{

    public class SymbolStatsCache
    {
        private ConcurrentDictionary<String, SymbolStats> _Cache;

        public SymbolStatsCache()
        {
            this._Cache = new ConcurrentDictionary<String, SymbolStats>(StringComparer.OrdinalIgnoreCase);
        }

        public Unit Update(String name, SymbolStats stats)
        {
            this._Cache.AddOrUpdate(name, (n) => stats, (n, s) => s.AddStats(stats));

            return Unit.Value;
        }

        public IEnumerable<(String Symbol, SymbolStats Stats)> GetAll()
            => this._Cache.Select(kv => (kv.Key, kv.Value));
    }

}