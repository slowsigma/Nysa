using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Web;
using System.Xml;

using Nysa.CodeAnalysis.VbScript;
using Nysa.CodeAnalysis.VbScript.Rescript;
using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using SyntaxNode = Dorata.Text.Parsing.Node;
using ProgramNode = Nysa.CodeAnalysis.VbScript.Semantics.Program;

using Tyler.CodeAnalysis.VbScript;
using Tyler.CodeAnalysis.VbScript.Rescript;

using HtmlAgilityPack;

namespace Tyler.VbsToJs
{

    public static class TranslateSessionFunctions
    {
        private static IReadOnlySet<String> CreateEmptyComIncidentals() => new HashSet<String>(StringComparer.OrdinalIgnoreCase);

        public static ContextFixed ToFixed(this TranslateSession @this, Trivia trivia, Func<LiteralValue, LiteralValue> inspectLiteral, Dictionary<String, SymbolStats>? symbolHistory = null)
            => new ContextFixed(new SymbolsScope(Option.None, SymbolsJson.ReadCodeSymbols(Path.Combine(@this.ExeFolder, @this.Settings.ParentSymbolsFile))),
                                @this.Settings.ArrayCreateFunction,
                                @this.Settings.ArrayResizeFunction,
                                @this.Settings.ArrayEraseFunction,
                                @this.Settings.SafeDeNullFunction,
                                @this.Settings.SafeImpFunction,
                                @this.Settings.SafeEqvFunction,
                                @this.Settings.SafeXorFunction,
                                @this.Settings.SafeOrFunction,
                                @this.Settings.SafeAndFunction,
                                @this.Settings.SafeNotFunction,
                                new CustomToJs(@this.Settings.PixelProperties, @this.Settings.ComProperties),
                                trivia,
                                inspectLiteral,
                                symbolHistory ?? new Dictionary<String, SymbolStats>(StringComparer.OrdinalIgnoreCase));

        public static ContextLevel CreateContextLevel(this ProgramNode @this)
            => new ContextLevel(Option.None, @this, new WithLevel(), Option.None);

        private static Option<IncludeInfo> GetInclude(this TranslateSession @this, String filePath)
        {
            filePath = filePath.PathNormal();

            if (@this.SymbolCache.ContainsKey(filePath))
                return new IncludeInfo(@this.SymbolCache[filePath], @this.AssignedTypesCache[filePath], Option.None, Option.None).Some();
            else
            {
                var info = filePath.ToContent()
                                   .Bind(c => c.Parse())
                                   .Bind(p => p is VbScriptParse vbsp
                                              ? vbsp.ToProgram().Map(r => (Parse: vbsp, Root: r))
                                              : Return.Failed<(VbScriptParse Parse, ProgramNode Root)>(new Exception("Unexpected content type.")))
                                   .Map(n => n.Root.ToJavaScriptSymbols().Make(y => new IncludeInfo(y, n.Root.AssignedTypes(), n.Parse.Some(), n.Root.Some())));

                if (info is Confirmed<IncludeInfo> goodInfo)
                {
                    @this.SymbolCache.Add(filePath, goodInfo.Value.Symbols);
                    @this.AssignedTypesCache.Add(filePath, goodInfo.Value.AssignedTypes);

                    return goodInfo.Value.Some();
                }
                else
                {
                    info.Affect(g => { },
                                e => { @this.LogInfo(e.ToString(), filePath); });

                    return Option.None;
                }
            }
        }

        private static Func<LiteralValue, LiteralValue> FindXslReferences(this TranslateSession @this, HashSet<String> xslSources, HashSet<String> htmSources, String pageFilePath)
        {
            if (@this.PageMode)
                return l =>
                {
                    if (l.Type == LiteralValueTypes.String)
                    {
                        if (l.Value.DataEndsWith(".xsl\""))
                        {
                            var source = l.Value.Substring(1, l.Value.Length - 2); // strip quotes

                            if (!source.DataStartsWith($"/{@this.Settings.OutFolderUri}") &&
                                source.ToFullReferenceFilePath(@this.Input.Root, pageFilePath) is Some<String> goodFilePath)
                            {
                                xslSources.Add(source);

                                var relativeDestination = source.ToRelativeReferenceFilePath(@this.Settings.OutFolderUri);

                                return new LiteralValue(((Some<SyntaxNode>)l.Node).Value, l.Type, $"\"{relativeDestination}\"");
                            }
                        }
                        else if (l.Value.DataEndsWith(".htm\"") || l.Value.DataEndsWith(".html\""))
                        {
                            var source = l.Value.Substring(1, l.Value.Length - 2); // strip quotes

                            if (!source.DataStartsWith($"/{@this.Settings.OutFolderUri}") &&
                                source.ToFullReferenceFilePath(@this.Input.Root, pageFilePath) is Some<String> goodFilePath)
                            {
                                htmSources.Add(source);

                                var relativeDestination = source.ToRelativeReferenceFilePath(@this.Settings.OutFolderUri);

                                return new LiteralValue(((Some<SyntaxNode>)l.Node).Value, l.Type, $"\"{relativeDestination}\"");
                            }
                        }
                    }

                    return l;
                };
            else
                return l => l;
        }

        // returns the list of all save files
        private static List<String> SaveIncludes(
            this List<IncludeInfo> @this,
            TranslateSession session,
            CodeSymbols codeSymbols,
            IReadOnlyDictionary<String, String> assignTypes,
            PageSymbols pageSymbols,
            Func<LiteralValue, LiteralValue> inspectLiteral)
        {
            var saves = new List<String>();

            codeSymbols = codeSymbols.WithParent();
            
            foreach (var info in @this)
            {
                if (info.Parse is Some<VbScriptParse> someParse &&
                    someParse.Value.SyntaxRoot is Confirmed<SyntaxNode> goodSyntax &&
                    info.Root is Some<ProgramNode> someRoot)
                {
                    var incSource = someParse.Value.Content.Source.PathNormal();
                    var incTrivia = someParse.Value.Content.Trivia(goodSyntax.Value);
                    var incBuild  = new StringBuilder();
                    var incScope  = session.HostSymbols.AddScope(codeSymbols.ToIncludeSymbols(), pageSymbols, info.Symbols);
                    var incAssn   = session.AssignedTypesCache[incSource].MergeAssignedTypes(assignTypes);
                    var incDest   = incSource.ToFullDestinationFilePath(session.Input.Root, session.Settings.OutFolderSave)
                                             .Make(p => String.Concat(p.Substring(0, p.Length - 4), ".js"));

                    saves.Add(incDest.PathNormal());

                    var context   = new Context(session.ToFixed(incTrivia, inspectLiteral),
                                                s => { incBuild.AppendLine(s); },
                                                someRoot.Value.CreateContextLevel(),
                                                incAssn,
                                                CreateEmptyComIncidentals());

                    someRoot.Value.ToJavaScript(context, incScope);

                    incDest.EnsureDirectory();

                    File.WriteAllText(incDest, incBuild.ToString());

                    session.SavedFiles.Add(incDest.PathNormal());
                }
            }

            return saves;
        }

        // returns list of all saves files
        private static List<String> SaveXsls(
            this HashSet<String> @this,
            TranslateSession session,
            IEnumerable<IncludeSymbols> includeSymbols,
            CodeSymbols codeSymbols,
            IReadOnlyDictionary<String, String> assignTypes,
            PageSymbols pageSymbols,
            String source)
        {
            var saves = new List<String>();

            foreach (var xslPath in @this.Select(p => p.ToFullReferenceFilePath(session.Input.Root, source)))
            {
                if (xslPath is Some<String> somePath)
                {
                    var destination = somePath.Value.ToFullDestinationFilePath(session.Input.Root, session.Settings.OutFolderSave);

                    if (session.SavedFiles.Contains(destination.PathNormal()))
                        continue;

                    if (!destination.DestinationReady(session.Overwrite, m => session.LogInfo(m, source)))
                        continue;

                    var content = somePath.Value.ToContent();
                    var parse   = content.Bind(c => c switch
                                  {
                                      XslContent xsl => xsl.Parse(session.EventAttributes),
                                      _ => Return.Failed<XslParse>("Content type not handled in SessionFunctions.Process.")
                                  });

                    if (parse is Confirmed<XslParse> goodParse)
                    {
                        // currently NOT doing script elements in xsl
                        foreach (var vbParse in goodParse.Value.VbParses.Where(p => !p.Element.LocalName.DataEquals("script")))
                        {
                            var parts = vbParse.SyntaxRoot
                                               .Bind(r => vbParse.ToProgram()
                                                                 .Map(pn => (Program: pn, Trivia: vbParse.Content.Trivia(r))));

                            if (parts is Confirmed<(ProgramNode Program, Trivia Trivia)> goodParts)
                            {
                                var program = goodParts.Value.Program;
                                var symbols = goodParts.Value.Program.ToJavaScriptSymbols();
                                // NOTE: We content that xsl content is too fragmented to be used to augment the incoming assigned types.
                                var trivia  = goodParts.Value.Trivia;
                                var build   = new StringBuilder();
                                var scope   = session.HostSymbols
                                                     .AddScope(includeSymbols)
                                                     .AddScope(pageSymbols, codeSymbols, symbols);

                                var context = new Context(session.ToFixed(trivia, l => l),
                                                          s => { build.AppendLine(s); },
                                                          program.CreateContextLevel(),
                                                          assignTypes,
                                                          CreateEmptyComIncidentals());

                                program.ToJavaScript(context, scope);

                                var js = build.ToString().Replace("\"", "'").Replace("\r\n", " ").Trim();

                                if (vbParse.Attribute == null)
                                {
                                    if (vbParse.Contents.Count > 0) // should always be true
                                    {
                                        var contNo = 0;
                                        var vbCont = vbParse.Contents;
                                        var jsCont = new List<String>();

                                        while (contNo < vbCont.Count)
                                        {
                                            if (vbCont[contNo].XslValueOf != null) // placeholder
                                            {
                                                var split = js.Split(((XmlText)vbCont[contNo].TextOrPlaceholder).Value);
                                                jsCont.Add(split[0]);

                                                if (split.Length > 1)
                                                {
                                                    jsCont.Add(String.Empty);
                                                    js = split[1];
                                                }
                                                else
                                                    js = String.Empty;
                                            }

                                            contNo++;
                                        }

                                        if (js.Length > 0)
                                            jsCont.Add(js); // add in remainder

                                        if (jsCont.Count == vbCont.Count)
                                        {
                                            for (Int32 i = 0; i < jsCont.Count; i++)
                                            {
                                                if (vbCont[i].XslValueOf == null) // replace text
                                                {
                                                    if (vbCont[i].TextOrPlaceholder is XmlText xTextCont)
                                                    {
                                                        xTextCont.Value = jsCont[i];
                                                    }
                                                    else if (vbCont[i].TextOrPlaceholder is XmlElement xslText && xslText.LocalName.DataEquals("text"))
                                                    {
                                                        xslText.InnerText = jsCont[i];
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    vbParse.Attribute.Value = js;
                                }
                            }
                            else
                                session.LogError(((Failed<(ProgramNode Program, Trivia Trivia)>)parts).Value, somePath.Value);
                        }

                        CustomTranslateSessionFunctions.ProcessXsl(goodParse.Value.Document, session, somePath.Value);

                        destination.EnsureDirectory();

                        var writer = new CustomXmlWriter(XmlWriter.Create(destination));
                        goodParse.Value.Document.Save(writer);
                        
                        session.SavedFiles.Add(destination.PathNormal());

                        saves.Add(destination.PathNormal());
                    }
                    else
                        session.LogError(((Failed<XslParse>)parse).Value, somePath.Value);
                }
            }

            return saves;
        }

        private static Unit Process(this HtmlParse @this, TranslateSession session, String source, String destination)
        {
            // before doing anything, lets make sure of the overwrite setting and the destination file
            if (!destination.DestinationReady(session.Overwrite, m => session.LogInfo(m, source)))
                return Unit.Value;

            // update the <src/> nodes to point to valid .js file paths
            foreach (var include in @this.VbsIncludes.Where(x => x.Source.DataEndsWith(".vbs")))
            {
                include.Node.SetAttributeValue("src", HttpUtility.UrlPathEncode(include.Source.ToRelativeReferenceFilePath(session.Settings.OutFolderUri, (".vbs", ".js"))));
                
                var langAttr = include.Node.Attributes.FirstOrNone(a => a.Name.DataEquals("language"));

                if (langAttr is Some<HtmlAttribute> someAttr)
                    include.Node.Attributes.Remove(someAttr.Value);

                include.Node.SetAttributeValue("type", "text/javascript");
            }
            
            var xsls    = new HashSet<String>(StringComparer.OrdinalIgnoreCase);
            var htms    = new HashSet<String>(StringComparer.OrdinalIgnoreCase);
            var xslRefs = session.FindXslReferences(xsls, htms, source);
            var fInc    = @this.VbsIncludes.FirstOrNone();
            var fVbp    = @this.VbsParses.FirstOrNone();
            var global  = @this.Document.CreateElement("script");

            global.SetAttributeValue("src", String.Concat("/", session.Settings.OutFolderUri, "/Common/Scripts/Global.js"));
            global.SetAttributeValue("type", "text/javascript");

            if (fInc is Some<(String Source, HtmlNode Node)> someFinc)
            {
                var indent = someFinc.Value
                                     .Node
                                     .PreviousSibling
                                     .Make(p => p is HtmlTextNode t
                                                ? new String(' ', t.Text.Reverse().TakeWhile(c => c == ' ').Count())
                                                : String.Empty);

                someFinc.Value.Node.ParentNode.InsertBefore(global, someFinc.Value.Node);
                someFinc.Value.Node.ParentNode.InsertAfter(@this.Document.CreateTextNode(String.Concat("\r\n", indent)), global);
            }
            else if (fVbp is Some<HtmlVbScriptParse> somefVbp)
            {
                var indent = somefVbp.Value
                                     .Node
                                     .PreviousSibling
                                     .Make(p => p is HtmlTextNode t
                                                ? new String(' ', t.Text.Reverse().TakeWhile(c => c == ' ').Count())
                                                : String.Empty);

                somefVbp.Value.Node.ParentNode.InsertBefore(global, somefVbp.Value.Node);
                somefVbp.Value.Node.ParentNode.InsertAfter(@this.Document.CreateTextNode(String.Concat("\r\n", indent)), global);
            }

            // get all necessary symbol data
            var includes = @this.VbsIncludes
                                .Where(x => x.Source.DataEndsWith(".vbs"))
                                .Select(inc => inc.Source.ToFullReferenceFilePath(session.Input.Root, source))
                                .SomeOnly()
                                .Select(fp => session.GetInclude(fp))
                                .SomeOnly()
                                .ToList();

            var page    = @this.Document.ToJavaScriptSymbols();
            var code    = new CodeSymbols(None<Symbol>.Enumerable());
            var assn    = (IReadOnlyDictionary<String, String>)new Dictionary<String, String>(StringComparer.OrdinalIgnoreCase);

            foreach (var vbParse in @this.VbsParses)
            {
                var parts = vbParse.SyntaxRoot
                                    .Bind(r => vbParse.ToProgram()
                                                      .Map(pn => (Program: pn, Trivia: vbParse.Content.Trivia(r))));

                if (parts is Confirmed<(ProgramNode Program, Trivia Trivia)> goodParts)
                {
                    var program = goodParts.Value.Program;
                    var symbols = goodParts.Value.Program.ToJavaScriptSymbols();
                    var assigns = goodParts.Value.Program.AssignedTypes();
                    var trivia  = goodParts.Value.Trivia;
                    var build   = new StringBuilder();
                    var scope   = (vbParse.Attribute == null)
                                  ? session.HostSymbols.AddScope(includes.Select(ii => ii.Symbols.ToIncludeSymbols())).AddScope(page, symbols)
                                  : session.HostSymbols.AddScope(includes.Select(ii => ii.Symbols.ToIncludeSymbols())).AddScope(page, code, symbols);

                    var context = new Context(session.ToFixed(trivia, xslRefs, session.SymbolHistory),
                                              s => { build.AppendLine(s); },
                                              program.CreateContextLevel(),
                                              assigns,
                                              CreateEmptyComIncidentals());

                    program.ToJavaScript(context, scope);

                    if (vbParse.Attribute == null)
                    {
                        // update code symbols to include this parse
                        code = new CodeSymbols(code.Members.Concat(symbols.Members));
                        assn = assn.MergeAssignedTypes(assigns);

                        var textNode = @this.Document.CreateTextNode(build.ToString());

                        var newNode = @this.Document.CreateElement("script");
                        newNode.SetAttributeValue("type", "text/javascript");
                        newNode.AppendChild(textNode);

                        vbParse.Node.ParentNode.ReplaceChild(newNode, vbParse.Node);
                    }
                    else
                    {
                        vbParse.Attribute.Value = build.ToString().Replace("\"", "'").Replace("\r\n", " ").Trim();
                    }
                }
                else
                {
                    var sourceExt = vbParse.Attribute == null
                                    ? String.Empty
                                    : String.Concat("; ", vbParse.Attribute.Name, "; ", vbParse.Attribute.Value);

                    session.LogError(parts as Failed<(ProgramNode Program, Trivia Trivia)>, String.Concat(source, sourceExt));
                }
                    
            }

            destination.EnsureDirectory();

            CustomTranslateSessionFunctions.ProcessHtml(@this.Document, session, source);

            @this.Document.OptionWriteEmptyNodes = true;
            @this.Document.Save(destination);

            session.SavedFiles.Add(destination.PathNormal());

            // translate and save any necessary includes and xsl transforms
            if (session.PageMode)
            {
                includes.SaveIncludes(session, code, assn, page, xslRefs)
                        .Affect(s =>
                        {
                            foreach (var i in s)
                                session.AddDependency(destination.PathNormal(), i);
                        });

                xsls.SaveXsls(session, includes.Select(ii => ii.Symbols.ToIncludeSymbols()), code, assn, page, source)
                    .Affect(s =>
                    {
                        foreach (var i in s)
                            session.AddDependency(destination.PathNormal(), i);
                    });

                htms.Affect(s =>
                {
                    session.AddDependency(destination.PathNormal(), s);
                });
            }

            return Unit.Value;
        }

        private static Unit Process(this XHtmlParse @this, TranslateSession session, String source, String destination)
        {
            // before doing anything, lets make sure of the overwrite setting and the destination file
            if (!destination.DestinationReady(session.Overwrite, m => session.LogInfo(m, source)))
                return Unit.Value;

            // update the <src/> nodes to point to valid .js file paths
            foreach (var include in @this.VbsIncludes.Where(x => x.Source.DataEndsWith(".vbs")))
            {
                include.Element.SetAttribute("src", HttpUtility.UrlPathEncode(include.Source.ToRelativeReferenceFilePath(session.Settings.OutFolderUri, (".vbs", ".js"))));
                
                var langAttr = include.Element.Attributes.Cast<XmlAttribute>().FirstOrNone(a => a.LocalName.DataEquals("language"));

                if (langAttr is Some<XmlAttribute> someAttr)
                    include.Element.RemoveAttribute("language");

                include.Element.SetAttribute("type", "text/javascript");
            }

            var xsls    = new HashSet<String>(StringComparer.OrdinalIgnoreCase);
            var htms    = new HashSet<String>(StringComparer.OrdinalIgnoreCase);
            var xslConv = session.FindXslReferences(xsls, htms, source);
            var fInc    = @this.VbsIncludes.FirstOrNone();
            var fVbp    = @this.VbsParses.FirstOrNone();
            var global  = @this.Document.CreateElement("script");

            global.SetAttribute("src", String.Concat("/", session.Settings.OutFolderUri, "/Common/Scripts/Global.js"));
            global.SetAttribute("type", "text/javascript");

            if (fInc is Some<(String Source, XmlElement Element)> someFinc)
            {
                var indent = someFinc.Value
                                     .Element
                                     .PreviousSibling
                                     .Make(p => p is XmlText t
                                                ? String.Concat(new String(' ', t.Value.Reverse().TakeWhile(c => c == ' ').Count()), "\r\n")
                                                : "\r\n");

                someFinc.Value.Element.ParentNode.InsertBefore(global, someFinc.Value.Element);
                someFinc.Value.Element.ParentNode.InsertBefore(@this.Document.CreateTextNode(indent), someFinc.Value.Element);
            }
            else if (fVbp is Some<XHtmlVbScriptParse> somefVbp)
            {
                var indent = somefVbp.Value
                                     .Element
                                     .PreviousSibling
                                     .Make(p => p is XmlText t
                                                ? String.Concat(new String(' ', t.Value.Reverse().TakeWhile(c => c == ' ').Count()), "\r\n")
                                                : "\r\n");

                somefVbp.Value.Element.ParentNode.InsertBefore(global, somefVbp.Value.Element);
                somefVbp.Value.Element.ParentNode.InsertBefore(@this.Document.CreateTextNode(indent), somefVbp.Value.Element);
            }

            // get all necessary symbol data
            var includes = @this.VbsIncludes
                                .Where(x => x.Source.DataEndsWith(".vbs"))
                                .Select(inc => inc.Source.ToFullReferenceFilePath(session.Input.Root, source))
                                .SomeOnly()
                                .Select(fp => session.GetInclude(fp))
                                .SomeOnly()
                                .ToList();

            var page    = @this.Document.ToJavaScriptSymbols();
            var code    = new CodeSymbols(None<Symbol>.Enumerable());
            var assn    = (IReadOnlyDictionary<String, String>)new Dictionary<String, String>(StringComparer.OrdinalIgnoreCase);

            foreach (var vbParse in @this.VbsParses)
            {
                var parts = vbParse.SyntaxRoot
                                   .Bind(r => vbParse.ToProgram()
                                                     .Map(pn => (Program: pn, Trivia: vbParse.Content.Trivia(r))));

                if (parts is Confirmed<(ProgramNode Program, Trivia Trivia)> goodParts)
                {
                    var program = goodParts.Value.Program;
                    var symbols = goodParts.Value.Program.ToJavaScriptSymbols();
                    var assigns = goodParts.Value.Program.AssignedTypes();
                    var trivia  = goodParts.Value.Trivia;
                    var build   = new StringBuilder();
                    var scope   = (vbParse.Attribute == null)
                                  ? session.HostSymbols.AddScope(includes.Select(ii => ii.Symbols.ToIncludeSymbols())).AddScope(page, symbols)
                                  : session.HostSymbols.AddScope(includes.Select(ii => ii.Symbols.ToIncludeSymbols())).AddScope(page, code, symbols);

                    var context = new Context(session.ToFixed(trivia, xslConv, session.SymbolHistory),
                                              s => { build.AppendLine(s); },
                                              program.CreateContextLevel(),
                                              assigns,
                                              CreateEmptyComIncidentals());

                    program.ToJavaScript(context, scope);

                    if (vbParse.Attribute == null) // script tag with content
                    {
                        // update code symbols to include this parse
                        code = new CodeSymbols(code.Members.Concat(symbols.Members));
                        assn = assn.MergeAssignedTypes(assigns);

                        vbParse.Element.InnerText = build.ToString();

                        var codeLang = vbParse.Element.Attributes.Cast<XmlAttribute>().FirstOrNone(a => a.LocalName.DataEquals("language"));

                        if (codeLang is Some<XmlAttribute> langAttr)
                            vbParse.Element.RemoveAttribute("language");

                        vbParse.Element.SetAttribute("type", "text/javascript");
                    }
                    else
                    {
                        vbParse.Attribute.Value = build.ToString().Replace("\"", "'").Replace("\r\n", " ").Trim();
                    }
                }
                else
                {
                    var sourceExt = vbParse.Attribute == null
                                    ? String.Empty
                                    : String.Concat("; ", vbParse.Attribute.LocalName, "; ", vbParse.Attribute.Value);

                    session.LogError(parts as Failed<(ProgramNode Program, Trivia Trivia)>, String.Concat(source, sourceExt));
                }
            }

            destination.EnsureDirectory();

            CustomTranslateSessionFunctions.ProcessXHtml(@this.Document, session, source);

            @this.Document.Save(destination);

            session.SavedFiles.Add(destination.PathNormal());

            // translate and save any necessary includes and xsl transforms
            if (session.PageMode)
            {
                includes.SaveIncludes(session, code, assn, page, xslConv)
                        .Affect(s =>
                        {
                            foreach (var i in s)
                                session.AddDependency(destination.PathNormal(), i);
                        });

                xsls.SaveXsls(session, includes.Select(ii => ii.Symbols.ToIncludeSymbols()), code, assn, page, source)
                    .Affect(s =>
                    {
                        foreach (var i in s)
                            session.AddDependency(destination.PathNormal(), i);
                    });

                htms.Affect(s =>
                {
                    session.AddDependency(destination.PathNormal(), s);
                });
            }

            return Unit.Value;
        }


        private static Unit Process(this HtmlContent @this, TranslateSession session, String source, String destination)
        {
            var parse = @this.Parse(session.EventAttributes);

            if (parse is Confirmed<Parse> goodHtmlParse)
            {
                if (goodHtmlParse.Value is XHtmlParse xmlParse)
                    xmlParse.Process(session, source, destination);
                else if (goodHtmlParse.Value is HtmlParse htmlParse)
                    htmlParse.Process(session, source, destination);
                else
                    session.LogError(new Exception("Unexpected type in SessionFunctions.Process."), source);

                return Unit.Value;
            }
            else
                return session.LogError(parse as Failed<Parse>, source);
        }

        private static Unit Process(this VbScriptContent @this, TranslateSession session, String source, String destination)
        {
            var parts = @this.Parse()
                             .Make(prs => prs.ToProgram()
                                             .Bind(prg => prs.SyntaxRoot
                                                             .Map(srt => (Program: prg,
                                                                          Trivia: prs.Content.Trivia(srt)))));

            if (parts is Confirmed<(ProgramNode Program, Trivia Trivia)> goodParts)
            {
                var program = goodParts.Value.Program;
                var symbols = goodParts.Value.Program.ToJavaScriptSymbols();
                var assigns = goodParts.Value.Program.AssignedTypes();
                var trivia  = goodParts.Value.Trivia;
                var scope   = session.HostSymbols.AddScope(symbols);
                var build   = new StringBuilder();

                var context = new Context(session.ToFixed(trivia, l => l, session.SymbolHistory),
                                          s => { build.AppendLine(s); },
                                          program.CreateContextLevel(),
                                          assigns,
                                          CreateEmptyComIncidentals());

                // put symbols in session cache
                if (session.SymbolCache.ContainsKey(source))
                    session.SymbolCache[source] = symbols;
                else
                    session.SymbolCache.Add(source, symbols);
                        
                program.ToJavaScript(context, scope);

                destination.EnsureDirectory();

                File.WriteAllText(destination, build.ToString());

                session.SavedFiles.Add(destination.PathNormal());

                return Unit.Value;
            }
            else
                return session.LogError(parts as Failed<(ProgramNode Program, Trivia Trivia)>, source);
        }

        private static Unit Process(this Folder @this, TranslateSession session, String missedSymbolsFile)
        {
            foreach (var file in @this.Files)
            {
                var filePath    = Path.Combine(@this.Path, @this.Name, file);
                var content     = filePath.ToContent();
                var destination = Path.Combine(@this.Root, session.Settings.OutFolderSave, filePath.Substring(@this.Root.Length).NoLeadingSlash());
                var fileSession = session.NewFileSession();

                content.Match(c => c switch
                                   {
                                       HtmlContent htm => htm.Process(fileSession, filePath, destination),
                                       VbScriptContent vbs => vbs.Process(fileSession, filePath, destination.Make(d => String.Concat(d.Substring(0, d.Length - 4), ".js"))),
                                       _ => JsonLog.Error("Content type not handled in SessionFunctions.Process.")
                                                   .Affect(m => fileSession.LogMessage(m))
                                   },
                              e => fileSession.LogError(e, filePath));

                void WriteMisses(Utf8JsonWriter writer)
                {
                    writer.WriteStartArray("MissedSymbols");

                    foreach (var kv in fileSession.SymbolHistory)
                    {
                        if (!session.SymbolHistory.ContainsKey(kv.Key))
                            session.SymbolHistory.Add(kv.Key, new SymbolStats());

                        session.SymbolHistory[kv.Key].AddStats(kv.Value);

                        if (kv.Value.BaseMisses > 0 || kv.Value.TypeMisses > 0)
                        {
                            writer.WriteStartObject();
                            writer.WriteString("Symbol", kv.Key);
                            writer.WriteNumber("Base", kv.Value.BaseMisses);
                            writer.WriteNumber("Type", kv.Value.TypeMisses);
                            writer.WriteEndObject();
                        }
                    }

                    writer.WriteEndArray();
                }

                File.AppendAllText(missedSymbolsFile, JsonLog.SourceInfo(filePath, WriteMisses));
            }

            foreach (var folder in @this.Folders)
                folder.Process(session, missedSymbolsFile);

            return Unit.Value;
        }

        public static Unit Execute(this TranslateSession @this)
        {
            @this.Input.Process(@this, Path.Combine(@this.DataPath, "MissedSymbols.log"));

            var symFile = Path.Combine(@this.DataPath, "SymbolStats.csv");

            var sep = "\",\"";

            var header = String.Concat("\"Symbol\",\"",
                                       "Base-Host-Hits", sep,
                                       "Base-Include-Hits", sep,
                                       "Base-Page-Hits", sep,
                                       "Base-Code-Hits", sep,
                                       "Base-Misses", sep,
                                       "Type-Host-Hits", sep,
                                       "Type-Include-Hits", sep,
                                       "Type-Page-Hits", sep,
                                       "Type-Code-Hits", sep,
                                       "Type-Misses", sep,
                                       "Base-Hit-Updates", sep,
                                       "Type-Hit-Updates", "\"");

            using (var stream = File.Create(symFile))
            {
                using (var writer = new StreamWriter(stream))
                {
                    writer.WriteLine(header);

                    foreach (var kp in @this.SymbolHistory.OrderBy(s => s.Key, StringComparer.OrdinalIgnoreCase))
                    {
                        var baseCounts = kp.Value.HitCounts(true);
                        var typeCounts = kp.Value.HitCounts(false);

                        writer.WriteLine($"\"{kp.Key}\",{baseCounts.Host},{baseCounts.Include},{baseCounts.Page},{baseCounts.Code},{kp.Value.BaseMisses},{typeCounts.Host},{typeCounts.Include},{typeCounts.Page},{typeCounts.Code},{kp.Value.TypeMisses},{baseCounts.Inexact},{typeCounts.Inexact}");
                    }
                    
                    writer.Flush();
                    writer.Close();
                }
            }

            var depFile = Path.Combine(@this.DataPath, "FileDependencies.json");

            @this.Dependencies
                 .SelectMany(kv => kv.Value.Select(d => kv.ToJson(kv.Key.Replace(@this.Input.Root.PathNormal(), String.Empty).ToProperty("file"),
                                                                  d.Replace(@this.Input.Root.PathNormal(), String.Empty).ToProperty("dependsOn"))))
                 .ToJsonNode()
                 .ToJsonString(new JsonSerializerOptions() { WriteIndented = true })
                 .Affect(s => File.WriteAllText(depFile, s));

            @this.LogInfo($"Total files translated: {@this.SavedFiles.Count}.", null);

            return Unit.Value;
        }

    }

}