using System;
using System.Collections.Generic;
using System.Linq;

using Nysa.Logics;
using Nysa.Text;

namespace Tyler.VbsToJs
{

    internal static class Usage
    {

        public static void WriteUsage(Action<String> writeLine)
        {
            writeLine("Converts files containing VbScript to JavaScript.");
            writeLine("Notes:");
            writeLine("   When <source> is a directory and the /ns switch is not present, files in sub-folders of <source> are searched");
            writeLine("   (recusively) for files to convert and sub-folders are created as necessary in the output folder. The output");
            writeLine("   folder is defined in appsettings.json and is always a single folder directly under the <web-root>. Converted");
            writeLine("   files are created under the output folder respecting the relative path of the original file. The program");
            writeLine("   converts files with the following extensions: '.htm', '.html', and '.vbs'. Files with the .vbs extension are");
            writeLine("   renamed with a .js extension in the output folder. Files with .htm and .html extensions are not renamed.");
            writeLine("   In addition, the program will append the output folder name to relative paths found in 'src' attributes of");
            writeLine("   'script' elements (where the original value ends in '.vbs') in converted HTML files. Log messages and symbol");
            writeLine("   statistics for each execution are output to files in a run-specific folder directly under the output");
            writeLine("   folder. Each run folder is named 'VbsToJs_#' where # is an incrementing number to make the folder unique.");
            writeLine(String.Empty);
            writeLine("Tyler.VbsToJs /root <web-root> [/source <source-path>] [/ns] [/force] [/verbose] [/dev]");
            writeLine(String.Empty);
            writeLine("  /root <web-root>          Required: Specifies the physical path that contains all web files.");
            writeLine("  /source <source-path>     Optional: Specifies a relative path under <web-root> to a file or folder to convert.");
            writeLine("                            If omitted, the program uses the <web-root> as <source-path> (see the /ns switch).");
            writeLine("  /page                     Optional: Use HTML pages as the starting point for all translation (i.e., .vbs files");
            writeLine("                            are translated when included in a page). Only valid when <source-path> is a folder.");
            writeLine("  /ns                       Optional: Do not include sub-folders. Not applicable if <source> is specified as a file.");
            writeLine("  /force                    Optional: Overwrite files existing in the output folder.");
            writeLine("  /verbose                  Optional: Include information messages in log data.");
            writeLine("  /dev                      Optional: Renames the entire output folder on each run (developer mode).");
            writeLine("");
        }

    }

}