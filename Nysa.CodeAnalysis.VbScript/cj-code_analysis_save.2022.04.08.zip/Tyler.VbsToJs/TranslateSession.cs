using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using Tyler.CodeAnalysis.VbScript;
using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.VbsToJs
{

    public class TranslateSession
    {
        private static Dictionary<String, CodeSymbols> CreateEmptySymbolCache()
            => new Dictionary<String, CodeSymbols>(StringComparer.OrdinalIgnoreCase);
        private static Dictionary<String, IReadOnlyDictionary<String, String>> CreateEmptyAssignedTypesCache()
            => new Dictionary<String, IReadOnlyDictionary<String, String>>(StringComparer.OrdinalIgnoreCase);
        private static Dictionary<String, SymbolStats> CreateEmptySymbolHistory()
            => new Dictionary<String, SymbolStats>(StringComparer.OrdinalIgnoreCase);
        private static Dictionary<String, HashSet<String>> CreateEmptyDependencies()
            => new Dictionary<String, HashSet<String>>(StringComparer.OrdinalIgnoreCase);

        public String           ExeFolder       { get; private set; }
        public Folder           Input           { get; private set; }
        public Settings         Settings        { get; private set; }
        public String           DataPath        { get; private set; }
        public Boolean          PageMode        { get; private set; }
        public Boolean          Overwrite       { get; private set; }
        public Action<String>   LogMessage      { get; private set; }
        public Boolean          Verbose         { get; private set; }
        public SymbolsScope     HostSymbols     { get; private set; }
        public HashSet<String>  EventAttributes { get; private set; }
        public HashSet<String>  SavedFiles      { get; private set; }

        public Dictionary<String, CodeSymbols>                          SymbolCache         { get; private set; }
        public Dictionary<String, IReadOnlyDictionary<String, String>>  AssignedTypesCache  { get; private set; }
        public Dictionary<String, SymbolStats>                          SymbolHistory       { get; private set; }
        public Dictionary<String, HashSet<String>>                      Dependencies        { get; private set; }

        private TranslateSession(
            String exeFolder,
            Folder input,
            Settings settings,
            String dataPath,
            Boolean pageMode,
            Boolean overwrite,
            Action<String> logMessage,
            Boolean verbose,
            SymbolsScope hostSymbols,
            HashSet<String> eventAttributes,
            HashSet<String> savedFiles,
            Dictionary<String, CodeSymbols> symbolCache,
            Dictionary<String, IReadOnlyDictionary<String, String>> assignedTypesCache,
            Dictionary<String, SymbolStats> symbolHistory,
            Dictionary<String, HashSet<String>> dependencies)
        {
            this.ExeFolder          = exeFolder;
            this.Input              = input;
            this.Settings           = settings;
            this.DataPath           = dataPath;
            this.PageMode           = pageMode;
            this.Overwrite          = overwrite;
            this.LogMessage         = logMessage;
            this.Verbose            = verbose;
            this.HostSymbols        = hostSymbols;
            this.EventAttributes    = eventAttributes;
            this.SymbolHistory      = symbolHistory;
            this.SymbolCache        = symbolCache;
            this.AssignedTypesCache = assignedTypesCache;
            this.SavedFiles         = savedFiles;
            this.Dependencies       = dependencies;
        }

        public TranslateSession(String exeFolder, Folder input, Settings settings, String dataPath, Boolean pageMode, Boolean overwrite, Action<String> logMessage, Boolean verbose, SymbolsScope hostSymbols, HashSet<String> eventAttributes)
            : this(exeFolder, input, settings, dataPath, pageMode, overwrite, logMessage, verbose, hostSymbols, eventAttributes, new HashSet<String>(StringComparer.OrdinalIgnoreCase), CreateEmptySymbolCache(), CreateEmptyAssignedTypesCache(), CreateEmptySymbolHistory(), CreateEmptyDependencies())
        {
        }

        public TranslateSession NewFileSession()
            => new TranslateSession(this.ExeFolder, this.Input, this.Settings, this.DataPath, this.PageMode, this.Overwrite, this.LogMessage, this.Verbose, this.HostSymbols, this.EventAttributes, this.SavedFiles, this.SymbolCache, this.AssignedTypesCache, CreateEmptySymbolHistory(), this.Dependencies);
        
        public Unit AddDependency(String file, String dependsOn)
        {
            if (!this.Dependencies.ContainsKey(file))
                this.Dependencies.Add(file, new HashSet<String>(StringComparer.OrdinalIgnoreCase));

            this.Dependencies[file].Add(dependsOn);

            return Unit.Value;
        }
    }

}