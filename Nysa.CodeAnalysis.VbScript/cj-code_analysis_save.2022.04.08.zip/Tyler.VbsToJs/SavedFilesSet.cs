using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

using Nysa.Logics;

using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.VbsToJs
{

    public class SavedFilesSet
    {
        private ConcurrentDictionary<String, Byte> _Set;

        public SavedFilesSet()
        {
            this._Set = new ConcurrentDictionary<String, Byte>(StringComparer.OrdinalIgnoreCase);
        }

        public Boolean TryAdd(String source)
            => this._Set.TryAdd(source, 0);
    }

}