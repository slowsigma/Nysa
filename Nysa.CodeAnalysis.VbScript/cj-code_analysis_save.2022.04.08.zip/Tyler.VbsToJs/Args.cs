using System;
using System.Collections.Generic;
using System.Linq;

using Nysa.Logics;
using Nysa.Text;

namespace Tyler.VbsToJs
{

    public static class args
    {
        public static Boolean Flag(this String[] args, String name)
            => args.Any(a => a.DataEquals($"-{name}") || a.DataEquals($"/{name}"));
        public static Option<String> Value(this String[] args, String name)
            => args.SkipWhile(a => !a.DataEquals($"-{name}") && !a.DataEquals($"/{name}")).Skip(1).FirstOrNone();

    }

}