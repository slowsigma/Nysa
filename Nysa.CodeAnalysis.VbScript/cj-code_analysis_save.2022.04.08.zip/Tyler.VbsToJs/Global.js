class Global {
    static get external() { return chrome.webview.hostObjects.sync.unity; }

    static Cr() { return '\r'; }
    static get CrLf() { return '\r\n'; }
    static get FormFeed() { return '\f'; }
    static get Lf() { return '\n'; }
    static get NewLine() { return '\r\n'; }
    static get NullChar() { return '\0'; }
    static get NullString() { return String(); }
    static get Tab() { return '\t'; }
    static get VerticalTab() { return '\v'; }

    static get typeEmpty() { return 0; }
    static get typeNull() { return 1; }
    static get typeInteger() { return 2; }
    static get typeLong() { return 3; }
    static get typeSingle() { return 4; }
    static get typeDoubld() { return 5; }
    static get typeCurrency() { return 6; }
    static get typeDate() { return 7; }
    static get typeString() { return 8; }
    static get typeObject() { return 9; }
    static get typeError() { return 10; }
    static get typeBoolean() { return 11; }
    static get typeVariant() { return 12; }
    static get typeDataObject() { return 13; }
    static get typeByte() { return 17; }
    static get typeArray() { return 8192; }
    
    static get msgOKOnly() { return 0; }
    static get msgOKCancel() { return 1; }
    static get msgAbortRetryIgnore() { return 2; }
    static get msgYesNoCancel() { return 3; }
    static get msgYesNo() { return 4; }
    static get msgRetryCancel() { return 5; }
    static get msgCritical() { return 16; }
    static get msgQuestion() { return 32; }
    static get msgExclamation() { return 48; }
    static get msgInformation() { return 64; }
    static get msgDefaultButton1() { return 0; }
    static get msgDefaultButton2() { return 256; }
    static get msgDefaultButton3() { return 512; }
    static get msgDefaultButton4() { return 768; }
    static get msgApplicationModal() { return 0; }
    static get msgSystemModal() { return 4096; }

    static get msgOK() { return 1; }
    static get msgCancel() { return 2; }
    static get msgAbort() { return 3; }
    static get msgRetry() { return 4; }
    static get msgIgnore() { return 5; }
    static get msgYes() { return 6; }
    static get msgNo() { return 7; }

    static get BinaryCompare() { return 0; }
    static get TextCompare() { return 1; }

    static get Sunday() { return 1; }
    static get Monday() { return 2; }
    static get Tuesday() { return 3; }
    static get Wednesday() { return 4; }
    static get Thursday() { return 5; }
    static get Friday() { return 6; }
    static get Saturday() { return 7; }
    static get UseSystemDayOfWeek() { return 0; }

    static get fmtLongDate() { return 1; }
    static get fmtShortDate() { return 2; }
    static get fmtLongTime() { return 3; }
    static get fmtShortTime() { return 4; }

    static get vbObjectError() { return -2147221504; }

    static get vbTrue() { return -1; }
    static get vbFalse() { return 0; }

    static IsNullOrUndefined(unknown) {
        return   (unknown === undefined) ? true
               : (unknown === null)      ? true
               :                           false;
    }

    static ValidString(unknown, defaultValue = "") {
        if (Global.IsNullOrUndefined(unknown)) {
            return defaultValue;
        }
        else {
            return unknown.toString();
        }
    }

    static toString(unknown) {
        return (Global.IsNullOrUndefined(unknown))
               ? ""
               : unknown;
    }

    static ValidCompare(compare) {
        return   Global.IsNullOrUndefined(compare) ? Global.BinaryCompare
               : compare == 1 ? Global.TextCompare
               : Global.BinaryCompare;
    }

    static GetRef(functionName) {
        var found = Object.keys(window).find(k => k == functionName);

        if (found === undefined)
        {
            var funcLower = functionName.toLowerCase();

            found = Object.keys(window).find(k => k.toLowerCase() == funcLower);
        }

        return (found === undefined) ? null : window[found];
    }

    static IsNumber(unknown) { return !Global.IsNullOrUndefined(unknown) && /^\s*[-+]?((\d+(\.\d+)?)|(\d+\.)|(\.\d+))(e[-+]?\d+)?\s*$/.test(unknown); }

    static Len  (value)         { return Global.ValidString(value).length; }
    static Left (value, length) { return value.substring(value.length - length); }
    static Right(value, length) { return value.substring(0, length) }

    static Chr(charCode) { return String.fromCharCode(charCode); }

    static IsEmpty(value) { return value === undefined; }

    static StrComp(value1, value2, compare = 0) {
        value1  = Global.ValidString(value1);
        value2  = Global.ValidString(value2);
        compare = Global.ValidCompare(compare);

        var relation =   (compare == Global.BinaryCompare)
                       ? value1.localeCompare(value2) 
                       : value1.toLowerCase().localeCompare(value2.toLowerCase());
        
        return   relation > 0 ?  1
               : relation < 0 ? -1
               :                 0;
    }

    static Mid(value, start, length = -1) {
        value = Global.ValidString(value);

        var idxStart = !Global.IsNumber(start) || (start - 1) < 0 ? 0 : start - 1; // convert to zer-based index
        var idxEnd   = !Global.IsNumber(length) || (length < 0)
                       ? value.length
                       : (idxStart + length);
        
        return (idxStart < idxEnd) && (idxStart < value.length)
               ? value.slice(idxStart, idxEnd)
               : '';
    }

    static InStr(arg1, arg2, arg3 = null, arg4 = null) {
        var isNan   = Number.isNaN(arg1);
        var start   = isNan ?    0 : (arg1 - 1);    // change from one-based to zero-based
        var string1 = isNan ? arg1 : arg2;
        var string2 = isNan ? arg2 : arg3;
        var compare = Global.ValidCompare(isNan ? arg3 : arg4);

        if (Global.IsNullOrUndefined(string1) || Global.IsNullOrUndefined(string2)) {
            return null;
        }
        else if (string1.length == 0 || string2.length == 0) {
            return 0;
        }

        // Note: the "+ 1" here changes from zero-based to one-based
        if (compare == Global.BinaryCompare) {
            return (Global.ValidString(string1).indexOf(Global.ValidString(string2), start) + 1);
        } else {
            return (Global.ValidString(string1).toLowerCase().indexOf(Global.ValidString(string2).toLowerCase(), start) + 1);
        }
    }

    static InStrRev(string1, string2, start = -1, compare = 0) {
        compare = Global.ValidCompare(compare);
        start   = start < 0 ? string1.length : start - 1; // convert to one-based value

        if (Global.IsNullOrUndefined(string1) || Global.IsNullOrUndefined(string2)) {
            return null;
        }
        else if (string1.length == 0) {
            return 0;
        }
        else if (string2.length == 0) {
            return start;
        }
        else if (start > string1.length) {
            return 0;
        }
        else if (start < 1) {
            throw new Error("Invalid start argument.");
        }

        // Note: the "+ 1" here changes from zero-based to one-based
        if (compare == Global.BinaryCompare) {
            return (Global.ValidString(string1).lastIndexOf(Global.ValidString(string2), start) + 1);
        } else {
            return (Global.ValidString(string1).toLowerCase().lastIndexOf(Global.ValidString(string2).toLowerCase(), start) + 1);
        }
    }

    static Replace(value, find, replaceWith, start = 1, count = -1, compare = 0) {
        var result = Global.ValidString(value);
        var found  = -1;
        
        compare     = Global.ValidCompare(compare);
        
        find        = (compare == Global.BinaryCompare)
                      ? Global.ValidString(find)
                      : Global.ValidString(find).toLowerCase();
        replaceWith = Global.ValidString(replaceWith);
        start       = start - 1;                            // change from one-based to zero-based
        count       = (count < 0) ? result.length : count;  // max replacement == original string length
        
        var adjust = replaceWith.length - find.length;

        while (count > 0 && start < result.length) {
            found = compare == Global.BinaryCompare
                    ? result.indexOf(find, start)
                    : result.toLowerCase().indexOf(find, start);
                    
            if (found < 0)
                return result;
            
            result = result.slice(0, found).concat(replaceWith, result.slice(found + find.length));
            start  = find.length + adjust;
            count  = count - 1;
        }

        return result;
    }

    static Split(value, delimiter = ' ', count = -1, compare = 0) {
        value     = Global.ValidString(value);
        delimiter = Global.ValidString(delimiter);
        compare   = Global.ValidCompare(compare);

        if (compare == Global.BinaryCompare)
            return delimiter.length == 0
                   ?   count < 0 || count >= value.length ? Array.from(value)
                     : count == 0 ? []
                     : Array.from(value.slice(0, count))
                   : value.split(delimiter, count);
        else {
            var splut = Global.Split(value.toLowerCase(), delimiter.toLowerCase(), count);
            var start = 0;

            for (var i = 0; i < splut.length; i++) {
                splut[i] = value.slice(start, start + splut[i].length);
                start += splut[i].length + delimiter.length;
            }

            return splut;
        }
    }

    static Trim (value) { return Global.ValidString(value).trim(); }
    static UCase(value) { return Global.ValidString(value).toUpperCase(); }
    static LCase(value) { return Global.ValidString(value).toLowerCase(); }

    static RTrim(value) { return Global.ValidString(value).trimEnd(); }
    static LTrim(value) { return Global.ValidString(value).trimStart(); }

    static Join(values, delimiter = ' ') {
        delimiter = Global.ValidString(delimiter, ' ');

        return Array.isArray(values)
               ? values.join(delimiter)
               : Global.ValidString(values.toString());
    }

    static String(repeat, character) {
        return Global.ValidString(character.slice(0, 1)).repeat(repeat);
    }

    static Space(number) { return Global.String(number, ' '); }

    static StrReverse(value) {
        return value.split("").reverse().join("");
    }

    static Asc(value) {
        if (Global.IsNullOrUndefined)
            throw new Error("Invalid procedure call or argument");
        else if (typeof value == "string" && value.length > 0)
            return value.charCodeAt(0);
        else
            return value.toString().charCodeAt(0);
    }
    
    static CStr (value) { return value.toString(); }

    static CSng (value) { return Number.parseFloat(Global.ValidString(value)); }
    static CDbl (value) { return Number.parseFloat(Global.ValidString(value)); }
    static CInt (value) { return Number.parseInt(Global.ValidString(value)); }
    static CLng (value) { return Number.parseInt(Global.ValidString(value)); }
    static CBool(value) { return Boolean(Global.ValidString(value)); }

    static Int(value) {
        if (Global.IsNullOrUndefined(value))
            return 0;
        if (typeof value == "number")
            return Math.floor(value);
        else if (typeof value == "string" && !isNaN(parseFloat(value)) && isFinite(parseFloat(value)))
            return Math.floor(parseFloat(value));
        else
            throw new Error("Type mismatch in call to Int().");
    }

    static Fix(value) {
        if (Global.IsNullOrUndefined(value))
            return 0;
        if (typeof value == "number")
            return Math.trunc(value);
        else if (typeof value == "string" && !isNaN(parseFloat(value)) && isFinite(parseFloat(value)))
            return Math.trunc(parseFloat(value));
        else
            throw new Error("Type mismatch in call to Int().");
    }

    static Abs(value) {
        if (typeof value == "number")
            return Math.abs(value);
        else if (typeof value == "string" && !isNaN(parseFloat(value)) && isFinite(parseFloat(value)))
            return Math.abs(parseFloat(value));
        else
            throw new Error("Type mismatch in call to Abs().");
    }

    // https://jsfiddle.net/3Lbhfy5s/79/
    static Round(n, digits) {
        var negative = false;
        if (digits === undefined) {
            digits = 0;
        }
        if (n < 0) {
            negative = true;
            n = n * -1;
        }
        var multiplicator = Math.pow(10, digits);
        n = parseFloat((n * multiplicator).toFixed(11));
        n = (Math.round(n) / multiplicator).toFixed(digits);
        if (negative) {
            n = (n * -1).toFixed(digits);
        }
        return parseFloat(n);
    }

    static Hex(number) {
        return number.toString(16).toUpperCase();
    }

    static IsArray(value) { return Array.isArray(value); }

    static IsObject(value) {
        if (value === undefined || value === null)
            return false;
        else
            return typeof value === 'object' && value.constructor === Object;
    }

    static IsNumeric(value) {
        if (Global.IsNullOrUndefined(value))
            return false;
        else if (typeof value == "string")
            return Global.IsNumber(value);
        else if (typeof value == "number")
            return true;
        else
            return false;
    }

    static LBound(value, dimension = 1) {
        return 0;
    }

    static UBound(value, dimension = 1) {
        while (dimension > 1) {
            value = value[0];
            dimension -= 1;
        }
            
        if (Array.isArray(value) && value.length > 0)
            return (value.length - 1); // convert to highest index
        else if (Array.isArray(value))
            throw new Error("Subscript is out of range.");
        else
            throw new Error("Value is not an array.");
    }

    static NewArray(dim1, dim2 = null, dim3 = null) {
        var len1 = dim1 == null ?    1 : dim1 + 1;      // convert last subscript to length
        var len2 = dim2 == null ? dim2 : dim2 + 1;      // convert last subscript to length
        var len3 = dim3 == null ? dim3 : dim3 + 1;      // convert last subscript to length

        var result = new Array(len1);

        if (len2 !== null) {
            for (let x = 0; x < len1; x++) {
                result[x] = new Array(len2);

                if (len3 !== null) {
                    for (let y = 0; y < len2; y++) {
                        result[x][y] = new Array(len3);
                    }
                }
            }
        }

        return result;
    }

    static ResizeArray(value, dim1, dim2 = null, dim3 = null) {
        var len1 = dim1 == null ?    1 : dim1 + 1;      // convert last subscript to length
        var len2 = dim2 == null ? dim2 : dim2 + 1;      // convert last subscript to length
        var len3 = dim3 == null ? dim3 : dim3 + 1;      // convert last subscript to length

        var resize = function (target, length) {
            while (target.length !== length) {
                if (target.length < length) {
                    target.push(null);
                } else {
                    target.pop();
                }
            }
        }

        if (len2 !== null) {
            if (value.length !== len1)
                throw new Error("Subscript is out of range.");
            
            if (len3 !== null) {
                if (value[0].length != len2)
                    throw new Error("Subscript is out of range.");

                for (let x = 0; x < len1; x++) {
                    for (let y = 0; y < len2; y++) {
                        return resize(value[x][y], len3);
                    }
                }
            } else {
                for (let x = 0; x < len1; x++) {
                    return resize(value[x], len2);
                }
            }
        } else {
            return resize(value, len1);
        }
    }

    static IsDate(expression) {
        return   expression instanceof Date    ? true
               : typeof expression == "number" ? true
               : typeof expression == "string" ? !isNaN(Date.parse("2018/06/27"))
               : false;
    }

    static Now() { return new Date(); }

    static Date() {
        var current = new Date();

        return new Date(current.getFullYear(), current.getMonth(), current.getDate());
    }

    static Year(expression) {
        return   expression instanceof Date ? expression.getFullYear()
               : typeof expression == "number" ? (new Date(expression)).getFullYear()
               : typeof expression == "string" ? (new Date(expression)).getFullYear()
               : null;
    }

    static Month(expression) {
        return   expression instanceof Date ? expression.getMonth() + 1
               : typeof expression == "number" ? (new Date(expression)).getMonth() + 1
               : typeof expression == "string" ? (new Date(expression)).getMonth() + 1
               : null;
    }

    static Day(expression) {
        return   expression instanceof Date ? expression.getDate()
               : typeof expression == "number" ? (new Date(expression)).getDate()
               : typeof expression == "string" ? (new Date(expression)).getDate()
               : null;
    }

    static Hour(expression) {
        return   expression instanceof Date ? expression.getHours()
               : typeof expression == "number" ? (new Date(expression)).getHours()
               : typeof expression == "string" ? (new Date(expression)).getHours()
               : null;
    }

    static Minute(expression) {
        return   expression instanceof Date ? expression.getMinutes()
               : typeof expression == "number" ? (new Date(expression)).getMinutes()
               : typeof expression == "string" ? (new Date(expression)).getMinutes()
               : null;
    }

    static Second(expression) {
        return   expression instanceof Date ? expression.getSeconds()
               : typeof expression == "number" ? (new Date(expression)).getSeconds()
               : typeof expression == "string" ? (new Date(expression)).getSeconds()
               : null;
    }

    static ByteLimit(expression) {
        return Global.IsNullOrUndefined(expression)
               ? 0
               : expression % 256;
    }

    static RGB(red, green, blue) {
        return   Global.ByteLimit(red)
               + (Global.ByteLimit(green) * 256)
               + (Global.ByteLimit(blue) * 65536);
    }


    static parseLocalDateTime(expression) {
        var parts = expression.trim().split(/\D/).map(t => parseFloat(t)).filter(n => !isNaN(n));
        var hourAdj = expression.trim().slice(-2).toLowerCase == "pm" ? 12 : 0;

        return parts.length > 3
               ? new Date(part[0], parts[1] - 1, parts[2], parts[3] + hourAdj, parts[4], parts[5])
               : new Date(0, 0, 0, parts[0] + hourAdj, parts[1], parts[2]);
    }

    static useTriState(value) {
        return    Global.IsNullOrUndefined(value) ? -2
                : value == -2 ? value
                : value == -1 ? value
                : 0;
    }

    // This function may not behave exactly as the original VbScript version.
    static FormatNumber(expression, decimalDigits, fractionLeadingZero, negativeParens, groupDigits) {
        decimalDigits       = Global.IsNullOrUndefined(decimalDigits) ? -1 : decimalDigits;
        fractionLeadingZero = Global.useTriState(fractionLeadingZero);
        negativeParens      = Global.useTriState(negativeParens);
        groupDigits         = Global.useTriState(groupDigits);
        
        if (Global.IsNumeric(expression)) {
            var value     = new Number(expression);
            var formatted = (decimalDigits < 0)
                            ? groupDigits == -2
                              ? value.toLocaleString()
                              : groupDigits == -1
                                ? value.toLocaleString(undefined, { useGrouping: true })
                                : value.toLocaleString(undefined, { useGrouping: false })
                            : groupDigits == -2
                              ? value.toLocaleString(undefined, { minimumFractionDigits: decimalDigits, maximumFractionDigits: decimalDigits })
                              : groupDigits == -1
                                ? value.toLocaleString(undefined, { minimumFractionDigits: decimalDigits, maximumFractionDigits: decimalDigits, useGrouping: true })
                                : value.toLocaleString(undefined, { minimumFractionDigits: decimalDigits, maximumFractionDigits: decimalDigits, useGrouping: false });
                      
            if (value > -1.0 && value < 1.0) {
                var firstDigit = formatted[0] == '(' || formatted[0] == '-' ? 1 : 0;

                if (fractionLeadingZero == -1 && formatted[firstDigit] == '.') {
                    formatted = formatted.slice(0, firstDigit) + '0' + formatted.slice(firstDigit);
                } else if (fractionLeadingZero == 0 && formatted[firstDigit] == '0' && (firstDigit + 1) < formatted.length) {
                    formatted = formatted.slice(0, firstDigit) + formatted.slice(firstDigit + 1)
                }
            }

            if (negativeParens == -1 && formatted.length > 0 && formatted[0] == '-') {
                formatted = '(' + formatted.slice(1) + ')';
            } else if (negativeParens == 0 && formatted.length > 0 && formatted[0] == '(') {
                formatted = '-' + formatted.slice(1, -1);
            }

            return formatted;
        }
        else
            return "";
    }

    static TypeName(value) { return typeof value; }

    static tryReturn(someFunction, elseFunction) {
        try { return someFunction(); }
        catch (e) { return elseFunction(); }
    }

    static iterateOn(something) {
        if (Symbol.iterator in Object(something))
            return something;
        else {
            const wrapper = {
                [Symbol.iterator] () {
                    var nextIdx = 0;
                    var length = Global.tryReturn(() => something.Length, () => 0);
                    return {
                        next() {
                            if (nextIdx < length) {
                            return { value: something[nextIdx++], done: false }
                            } else {
                            return { value: undefined, done: true }
                            }
                        }
                    }
                }
            }
        
            return wrapper;
        }
    }

    static toPixelSize(expression) {
        if (Global.IsNumeric(expression))
            return expression + "px";
        else if (typeof expression == "string" && expression.endsWith("px"))
            return expression;
        else
            throw new Error("Invalid pixel size argument.");;
    }

}
