using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

using Nysa.Logics;


namespace Tyler.VbsToJs
{

    public class FileDependencyLog
    {
        private ConcurrentBag<(String File, String DependsOn)> _Log;

        public FileDependencyLog()
        {
            this._Log = new ConcurrentBag<(String File, String DependsOn)>();
        }

        public Unit Add(String file, String dependsOn)
        {
            this._Log.Add((file, dependsOn));

            return Unit.Value;
        }

        public IReadOnlyDictionary<String, IReadOnlySet<String>> ToDistinct()
        {
            var index = new Dictionary<String, HashSet<String>>(StringComparer.OrdinalIgnoreCase);

            foreach (var item in this._Log)
            {
                if (!index.ContainsKey(item.File))
                    index.Add(item.File, new HashSet<String>(StringComparer.OrdinalIgnoreCase));

                index[item.File].Add(item.DependsOn);
            }

            return (IReadOnlyDictionary<String, IReadOnlySet<String>>)index;
        }
    }

}