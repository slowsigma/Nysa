using System;

namespace Tyler.VbsToJs
{

    public record Settings(
        String OutFolderSave,
        String OutFolderUri,
        String[] HostSymbolFiles,
        String ParentSymbolsFile,
        String ArrayCreateFunction,
        String ArrayResizeFunction,
        String ArrayEraseFunction,
        String SafeDeNullFunction,
        String SafeImpFunction,
        String SafeEqvFunction,
        String SafeXorFunction,
        String SafeOrFunction,
        String SafeAndFunction,
        String SafeNotFunction,
        String[] PixelProperties,
        String[] ComProperties,
        String[] EventAttributeNames
    )
    {
        public static readonly HashSet<String> PageModeFileExtentions = new HashSet<String>(new String[] { ".htm", ".html" }, StringComparer.OrdinalIgnoreCase);
        public static readonly HashSet<String> StandardFileExtensions = new HashSet<String>(new String[] { ".htm", ".html", ".vbs" }, StringComparer.OrdinalIgnoreCase);

        public static readonly String FileName = "appsettings.json";

        public static readonly Settings Default = new Settings(
            "H5",
            "H5",
            SettingsDefaults.HostFiles,
            "SuperParent.json",
            "Global.NewArray",
            "Global.ResizeArray",
            "Global.EraseArray",
            "Global.EmptyIfNull",
            "Global.Imp",
            "Global.Eqv",
            "Global.Xor",
            "Global.Or",
            "Global.And",
            "Global.Not",
            SettingsDefaults.PixelProperties,
            SettingsDefaults.ComProperties,
            SettingsDefaults.EventAttributeNames
                            .Concat(SettingsDefaults.ExtendedEventAttributeNames)
                            .ToArray()
        );

        public static Settings Value = Default;

    }

}