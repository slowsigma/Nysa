using System;

namespace Tyler.VbsToJs
{

    public static class SettingsDefaults
    {

        public static readonly String[] HostFiles = new String[]
        {
            "HostSymbols.Tyler.json",
            "HostSymbols.VbScript.json",
            "HostSymbols.WebApi.json"
        };

        public static readonly String[] PixelProperties = new String[]
        {
            "pixelheight",
            "pixelwidth",
            "height",
            "width"
        };

        public static readonly String[] ComProperties = new String[]
        {
            "async"
        };

        public static readonly String[] EventAttributeNames = new String[]
        {
            "onafterprint",
            "onbeforeprint",
            "onbeforeunload",
            "onerror",
            "onhashchange",
            "onload",
            "onmessage",
            "onoffline",
            "ononline",
            "onpagehide",
            "onpageshow",
            "onpopstate",
            "onresize",
            "onstorage",
            "onunload",
            "onblur",
            "onchange",
            "oncontextmenu",
            "onfocus",
            "oninput",
            "oninvalid",
            "onreset",
            "onsearch",
            "onselect",
            "onsubmit",
            "onkeydown",
            "onkeypress",
            "onkeyup",
            "onclick",
            "ondblclick",
            "onmousedown",
            "onmousemove",
            "onmouseout",
            "onmouseover",
            "onmouseup",
            "onmousewheel",
            "onwheel",
            "ondrag",
            "ondragend",
            "ondragenter",
            "ondragleave",
            "ondragover",
            "ondragstart",
            "ondrop",
            "onscroll",
            "oncopy",
            "oncut",
            "onpaste",
            "onabort",
            "oncanplay",
            "oncanplaythrough",
            "oncuechange",
            "ondurationchange",
            "onemptied",
            "onended",
            "onerror",
            "onloadeddata",
            "onloadedmetadata",
            "onloadstart",
            "onpause",
            "onplay",
            "onplaying",
            "onprogress",
            "onratechange",
            "onseeked",
            "onseeking",
            "onstalled",
            "onsuspend",
            "ontimeupdate",
            "onvolumechange",
            "onwaiting",
            "ontoggle"
        };

        public static readonly String[] ExtendedEventAttributeNames = new String[]
        {
            "onvalidationcomplete",
            "onbeforevalidation",
            "onaftervalidation",
            "onfocusout",
            "onbuttonclick",
            "onlinkclick",
            "href",
            "onactivate"
        };

        public static readonly String FileName = "appsettings.json";
    }

}