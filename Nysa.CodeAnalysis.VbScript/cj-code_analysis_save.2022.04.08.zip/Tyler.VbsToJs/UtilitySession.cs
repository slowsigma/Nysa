using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using Tyler.CodeAnalysis.VbScript;
using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.VbsToJs
{

    public class UtilitySession
    {
        public Folder           Input         { get; private set; }
        public Settings         Settings      { get; private set; }
        public String           DataPath      { get; private set; }
        public Boolean          Overwrite     { get; private set; }
        public Action<String>   LogMessage    { get; private set; }
        public Boolean          Verbose       { get; private set; }


        public UtilitySession(
            Folder input,
            Settings settings,
            String dataPath,
            Boolean overwrite,
            Action<String> logMessage,
            Boolean verbose)
        {
            this.Input              = input;
            this.Settings           = settings;
            this.DataPath           = dataPath;
            this.Overwrite          = overwrite;
            this.LogMessage         = logMessage;
            this.Verbose            = verbose;
        }

    }

}