using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;

using Tyler.CodeAnalysis.VbScript.Rescript;
using Tyler.CodeAnalysis.VbScript;

namespace Tyler.VbsToJs
{

    public class CodeSymbolsCache
    {
        private ConcurrentDictionary<String, CodeSymbols> _Cache;

        public CodeSymbolsCache()
        {
            this._Cache = new ConcurrentDictionary<String, CodeSymbols>(StringComparer.OrdinalIgnoreCase);
        }

        public Option<CodeSymbols> GetSymbols(String source)
        {
            var item = (CodeSymbols?)null;

            return this._Cache.TryGetValue(source, out item)
                   ? item.Some()
                   : Option.None;
        }

        public Boolean TryAdd(String source, CodeSymbols symbols)
            => this._Cache.TryAdd(source, symbols);
    }

}