using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

using Nysa.Logics;
using Nysa.Text;

using HtmlAgilityPack;

namespace Tyler.VbsToJs
{

    public static class FolderFunctions
    {
        public static readonly HashSet<String> PageModeFileExtentions = new HashSet<String>(new String[] { ".htm", ".html" }, StringComparer.OrdinalIgnoreCase);
        public static readonly HashSet<String> StandardFileExtensions = new HashSet<String>(new String[] { ".htm", ".html", ".vbs" }, StringComparer.OrdinalIgnoreCase);
        public static readonly String VbsToJs_ = "VbsToJs_";

        public static String PathNormal(this String @this)
            => @this.Replace("\\", "/").Trim();

        public static String NoTrailingSlash(this String @this)
            => @this.PathNormal().Make(t => t.EndsWith(@"/") ? t.Substring(t.Length - 1) : t);
        public static String NoLeadingSlash(this String @this)
            => @this.PathNormal().Make(t => t.StartsWith(@"/") ? t.Substring(1) : t);

        public static Boolean PathStringsEqual(String first, String second)
            => first.PathNormal().Equals(second.PathNormal(), StringComparison.OrdinalIgnoreCase);

        public static Boolean PathsEqual(String first, String second)
        {
            var firstChecked  = (Directory.Exists(first))  ? (new DirectoryInfo(first)).FullName  : null;
            var secondChecked = (Directory.Exists(second)) ? (new DirectoryInfo(second)).FullName : null;

            return firstChecked == null || secondChecked == null
                   ? PathStringsEqual(first, second)
                   : PathStringsEqual(firstChecked, secondChecked);
        }

        private static String CleanRelativePath(this String relativeFilePath)
            => relativeFilePath.DataStartsWith("./")
               ? relativeFilePath.Substring(2)
               : relativeFilePath;

        public static Option<String> ToFullReferenceFilePath(this String relativeFilePath, String inputRoot, String pageFullFilePath)
        {
            var fullFilePath = relativeFilePath.DataStartsWith("/") // is relative to inputRoot (i.e., web root)?
                               ? Path.Combine(inputRoot, relativeFilePath.NoLeadingSlash())
                               : Path.Combine((new FileInfo(pageFullFilePath)).DirectoryName ?? String.Empty, relativeFilePath.CleanRelativePath()); // relative to referencingFilePath

            var fileInfo = new FileInfo(fullFilePath);

            return fileInfo.Exists ? fileInfo.FullName.PathNormal().Some() : Option.None;
        }

        public static String ToRelativeReferenceFilePath(this String originalReferenceFilePath, String outFolder, (String oldExt, String newExt)? exts = null)
        {
            var replace = (exts == null)
                          ? (oldExt: String.Empty, newExt: String.Empty)
                          : (oldExt: exts.Value.oldExt, newExt: exts.Value.newExt);

            // outFolder only used when the original path is rooted (i.e., starts with '/')
            return (originalReferenceFilePath.DataStartsWith("/"))
                   ? String.Concat("/", outFolder, originalReferenceFilePath.Substring(0, originalReferenceFilePath.Length - replace.oldExt.Length), replace.newExt)
                   : String.Concat(originalReferenceFilePath.Substring(0, originalReferenceFilePath.Length - replace.oldExt.Length), replace.newExt);
        }

        public static String ToFullDestinationFilePath(this String sourceFullFilePath, String inputRoot, String outFolder)
            => Path.Combine(inputRoot, outFolder, sourceFullFilePath.Replace(inputRoot, String.Empty).NoLeadingSlash());

        public static Unit EnsureDirectory(this String destinationFilePath)
            => (new FileInfo(destinationFilePath)).Affect(i =>
            {
                // make sure the directory for the file exists in Session.OutputPath
                if (i.DirectoryName != null && !Directory.Exists(i.DirectoryName))
                    Directory.CreateDirectory(i.DirectoryName);
            });

        public static Boolean DestinationReady(this String filePath, Boolean overwrite, Func<String, Unit> log)
        {
            if (File.Exists(filePath))
            {
                if (overwrite)                  // overwrite?
                    File.Delete(filePath);      // then delete existing file first
                else
                {
                    log($"File already exists in output folder: '{filePath}'.");
                    return false;               // bail
                }
            }

            return true;
        }

        private static (Folder? Include, Int32 FolderCount, Int32 FileCount) CreateIncludeFolderRecurse(
            String path,
            String root,
            HashSet<String> skipFolders,
            Func<String, Boolean> fileFilter)
        {
            var info        = new DirectoryInfo(path);
            var names       = new List<String>();
            var subs        = new List<Folder>();

            var folderCount = (Int32)0;
            var fileCount   = (Int32)0;

            if (skipFolders.Contains(path))     // test path to skip
                return (null, 0, 0);            // this path is not considered a possibility for input files

            names.AddRange(Directory.EnumerateFiles(path, "*.*", SearchOption.TopDirectoryOnly)
                                    .Where(fileFilter)
                                    .Select(fp => Path.GetFileName(fp)));
            fileCount = names.Count; // this folders files (could be zero)
            folderCount++;           // this folder (always counts)

            foreach (var (include, folders, files) in Directory.EnumerateDirectories(path).Select(sf => CreateIncludeFolderRecurse(sf, root, skipFolders, fileFilter)))
            {
                folderCount += folders;
                fileCount   += files;

                if (include != null)
                {
                    subs.Add(include);
                }
            }

            return fileCount > 0
                   ? (new Folder(root, info.Parent?.FullName ?? String.Empty, info.Name, names, subs), folderCount, fileCount)
                   : (null, folderCount, 0);
        }

        public static (Folder? Include, Int32 FolderCount, Int32 FileCount) CreateInput(this String rootPath, String file)
            => (new DirectoryInfo(rootPath))
               .Make(i => new Folder(rootPath,
                                     i.Parent?.FullName ?? String.Empty,
                                     i.Name,
                                     Return.Enumerable(file),
                                     None<Folder>.Enumerable()))
               .Make(i => (i, 1, 1));

        public static (Folder? Include, Int32 FolderCount, Int32 FileCount) CreateInput(
            this String rootPath,
            String sourcePath,
            HashSet<String> skipFolders,
            Boolean pageMode,
            Boolean nosubs)
        {
            var info = new DirectoryInfo(rootPath);

            var fileFilter = new Func<String, Boolean>(fp => pageMode
                                                             ? PageModeFileExtentions.Contains(Path.GetExtension(fp))
                                                             : StandardFileExtensions.Contains(Path.GetExtension(fp)));

            if (nosubs)
                return (new Folder(rootPath,
                                   info.Parent?.FullName ?? String.Empty,
                                   info.Name,
                                   Directory.EnumerateFiles(rootPath, "*.*", SearchOption.TopDirectoryOnly)
                                            .Where(fileFilter)
                                            .Select(fp => Path.GetFileName(fp)),
                                   None<Folder>.Enumerable()))
                       .Make(i => i.Files.Count > 0
                                  ? (i, 1, i.Files.Count)
                                  : (null, 1, 0));
            else
                return CreateIncludeFolderRecurse(sourcePath, rootPath, skipFolders, fileFilter);
        }

        public static String NewDataPath(String basePath)
        {
            var usedNumber  = (Int32)0;
            var baseInfo    = new DirectoryInfo(basePath);
            var target      = Path.Combine(basePath, VbsToJs_);
            var target_srch = String.Concat(VbsToJs_, "*");

            if (Directory.Exists(basePath))
            {
                foreach (var dir in Directory.GetDirectories(basePath, target_srch, SearchOption.TopDirectoryOnly))
                {
                    (new DirectoryInfo(dir)).Name
                                            .Substring(VbsToJs_.Length)
                                            .NoneIf(v => !v.All(c => Char.IsNumber(c)))
                                            .Map(n => Int32.Parse(n))
                                            .Affect(i => { if (usedNumber < i) { usedNumber = i; } });
                }
            }

            return Path.Combine(target, String.Concat(target, (usedNumber + 1).ToString().Trim()));
        }

    }

}