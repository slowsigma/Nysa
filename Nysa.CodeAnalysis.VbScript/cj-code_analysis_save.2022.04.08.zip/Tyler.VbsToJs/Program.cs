﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.VbsToJs
{

    internal class Program
    {
        private static String ToSecondsTimestamp(DateTime dateTime)
        {
            var origin = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            var diff = dateTime.ToUniversalTime() - origin;
            return Math.Floor(diff.TotalSeconds).ToString();            
        }

        static void Main(string[] args)
        {
            if (args.Length == 0 || args[0].Equals("?") || args[0].Equals("/?") || args[0].Equals("-?"))
            {
                Usage.WriteUsage(a => { Console.WriteLine(a); });
                return;
            }

            var exePath     = (new FileInfo(System.Reflection.Assembly.GetCallingAssembly().Location)).DirectoryName ?? String.Empty;
            var curPath     = Directory.GetCurrentDirectory();

            Settings.Value  = Path.Combine(exePath, Settings.FileName)
                                   .NoneIf(f => !File.Exists(f))
                                   .Bind(v => Return.Try(() => JsonSerializer.Deserialize<Settings>(File.ReadAllText(v)))
                                                    .Match(s =>  s.AsOption(),
                                                           () => Settings.Default.Some()))
                                   .Or(Settings.Default);

            var rootArg     = args.Value("root")                        // root path
                                  .Or(args.Value("r"))                  //   r is acceptable
                                  .Map(v => v.NoTrailingSlash());

            var srcArg      = args.Value("source")                      // source folder
                                  .Or(args.Value("s"))                  //   s is acceptable
                                  .Or(String.Empty)                     //   or empty string
                                  .Make(v => v.NoLeadingSlash());

            var page        = args.Flag("page") || args.Flag("p");      // page mode
                                                                        //   p is acceptable
            var nosubs      = args.Flag("ns") || args.Flag("nosub");    // do not include sub-folders
            var force       = args.Flag("force");                       // allow files in /out path to be overwritten
            var verbose     = args.Flag("verbose") || args.Flag("v");   // verbose output
            var dev         = args.Flag("dev") || args.Flag("d");       // 'dev'eloper mode
                                                                        //   d is acceptable

            var rootCheck   = rootArg.Match(r => Directory.Exists(r) ? r.Confirmed() : Return.Failed<String>($"Cannot find root folder: '{r}'."),
                                            () => Return.Failed<String>("The /root argument is required."));

            var srcValue    = rootArg.Map(r => String.IsNullOrWhiteSpace(srcArg)
                                               ? r
                                               : Path.Combine(r, srcArg));

            var srcCheck    = srcValue.Match(s =>    String.IsNullOrEmpty(srcArg)
                                                  || File.Exists(s)
                                                  || Directory.Exists(s)
                                                  ? s.Confirmed()
                                                  : Return.Failed<String>($"The /source argument must be a valid file or folder under the /root folder."),
                                             String.Empty.Confirmed()); // this only happens when /root is not specified

            var hostCheck =   Settings.Value.HostSymbolFiles.Length == 0
                              ? (Option<SymbolsScope>.None).Confirmed()
                              : SymbolsJson.ReadHostSymbols(Settings.Value.HostSymbolFiles.Select(h => Path.Combine(exePath, h)));

            if (rootCheck is Confirmed<String>               goodRoot &&
                srcCheck  is Confirmed<String>               goodSrc  &&
                hostCheck is Confirmed<Option<SymbolsScope>> goodHost   )
            {
                var root        = goodRoot.Value;
                var source      = goodSrc.Value;
                var isFile      = source.Length != 0 && File.Exists(source);

                var outPath     = Path.Combine(root, Settings.Value.OutFolderSave);
                var dataPath    = dev ? Path.Combine(outPath, "VbsToJs") : FolderFunctions.NewDataPath(outPath);

                var inFile      = isFile ? source.Substring(root.Length).NoLeadingSlash().Some() : Option<String>.None;
                var outSkips    = new HashSet<String>(StringComparer.OrdinalIgnoreCase);

                if (dev)
                {
                    if (Directory.Exists(outPath))
                    {
                        var outTs = ToSecondsTimestamp((new DirectoryInfo(outPath)).CreationTimeUtc);
                        Directory.Move(outPath, String.Concat(outPath, "_", outTs));
                    }
                }

                foreach (var folder in Directory.EnumerateDirectories(root, $"{Settings.Value.OutFolderUri}*", SearchOption.TopDirectoryOnly))
                    outSkips.Add(folder);

                if (!Settings.Value.OutFolderUri.DataEquals(Settings.Value.OutFolderSave)) // Save and Uri are different?
                {
                    foreach (var folder in Directory.EnumerateDirectories(root, $"{Settings.Value.OutFolderSave}*", SearchOption.TopDirectoryOnly))
                        outSkips.Add(folder);
                }

                var (input,
                     folders,
                     files) = inFile.Match(f => root.CreateInput(f),
                                           () => root.CreateInput(source, outSkips, page, nosubs));

                Directory.CreateDirectory(dataPath);

                var logFile     = Path.Combine(dataPath, "Session.log");
                var logEntries  = new List<String>();
                var logAction   = new Action<String>(s => { File.AppendAllText(logFile, String.Concat(s, "\r\n")); });

                void LogArgument(String argTitle, String argValue)
                {
                    logAction(JsonLog.Info($"{App.Name} {argTitle}: '{argValue}'."));
                }

                LogArgument("Root Path", root);
                LogArgument("Source File/Path", source);
                LogArgument("Output Path", outPath);
                LogArgument("Session Data", dataPath);

                if (page)
                    LogArgument("Page Mode", page ? "yes" : "no");

                if (inFile is None<String>)
                    LogArgument("Find Files", String.Join(", ", page
                                                                ? Settings.PageModeFileExtentions.Select(e => String.Concat("'", e, "'"))
                                                                : Settings.StandardFileExtensions.Select(e => String.Concat("'", e, "'"))));

                if (!isFile)
                    LogArgument("Include Subfolders", nosubs ? "no" : "yes");

                LogArgument("Allow File Overwrite", force ? "yes" : "no");
                LogArgument("Include Info Messages", verbose ? "yes" : "no");


                if (input != null)
                {
                    logAction(JsonLog.Info($"Total folders searched: {folders}."));
                    logAction(JsonLog.Info($"Total input files found: {files}."));

                    var session = new TranslateSession(exePath,
                                                       input,
                                                       Settings.Value,
                                                       dataPath,
                                                       page,
                                                       force,
                                                       logAction,
                                                       verbose,
                                                       goodHost.Value.Or(() => new SymbolsScope(Option.None, new HostSymbols(new Symbol[] { }))),
                                                       new HashSet<String>(Settings.Value.EventAttributeNames, StringComparer.OrdinalIgnoreCase));

                    logAction(JsonLog.Info("Starting translation."));

                    session.Execute();

                    logAction(JsonLog.Info("Translation complete."));
                }
                else
                    logAction(JsonLog.Info("No input files found."));
            }
            else
            {
                if (rootCheck is Failed<String> rootFailed)
                    JsonLog.Error(rootFailed).Affect(m => Console.WriteLine(m));

                if (srcCheck is Failed<String> srcFailed)
                    JsonLog.Error(srcFailed).Affect(m => Console.WriteLine(m));

                if (hostCheck is Failed<Option<SymbolsScope>> hostFailed)
                    JsonLog.Error(hostFailed).Affect(m => Console.WriteLine(m));
            }
        }

    }

}