using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

using Tyler.CodeAnalysis.VbScript;
using Tyler.CodeAnalysis.VbScript.Rescript;

namespace Tyler.VbsToJs
{

    public static class UtilitySessionFunctions
    {

        public static Unit BuildParentSymbols(this UtilitySession @this)
        {
            return Unit.Value;
        }

    }

}