using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Tyler.VbsToJs
{

    public record Folder
    {
        // Note: at every level a full file path can be constructed using .Path, .Name, and the specific value in .Files.
        public String                   Root    { get; private set; } // starting path all IncludeFolders are built from
        public String                   Path    { get; private set; } // full path without the .Name
        public String                   Name    { get; private set; } // name of current folder
        public IReadOnlyList<String>    Files   { get; private set; } // just name with extension
        public IReadOnlyList<Folder>    Folders { get; private set; } // sub-folders of this

        public Folder(String root, String path, String name, IEnumerable<String> files, IEnumerable<Folder?> folders)
        {
            this.Root    = root;
            this.Path    = path;
            this.Name    = name;
            this.Files   = files.ToList();

            var subs = new List<Folder>();

            foreach (var folder in folders)
                if (folder != null)
                    subs.Add(folder);
                    
            this.Folders =  subs;
        }
    }

}