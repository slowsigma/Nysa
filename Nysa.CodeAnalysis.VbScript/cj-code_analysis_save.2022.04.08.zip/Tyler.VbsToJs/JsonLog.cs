using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

using Nysa.Logics;

namespace Tyler.VbsToJs
{

    public static class JsonLog
    {

        public static Option<String> Error<T>(Failed<T>? failed)
            => (failed != null)
               ? JsonLog.Error(failed.Value.Message).Some()
               : Option.None;

        public static Unit LogError<T>(this TranslateSession @this, Failed<T>? failed, String source)
        {
            if (failed != null)
                @this.LogMessage(JsonLog.Error(failed.Value.Message, source));

            return Unit.Value;
        }

        public static Unit LogError(this TranslateSession @this, Exception e, String source)
        {
            @this.LogMessage(JsonLog.Error(e.Message, source));

            return Unit.Value;
        }

        public static Unit LogInfo(this TranslateSession @this, String message, String? source, Action<Utf8JsonWriter>? additionalContent = null)
        {
            @this.LogMessage(JsonLog.Info(message, source, additionalContent));

            return Unit.Value;
        }
            

        public static String Error(String message, String? source = null)
        {
            using (var memory = new MemoryStream())
            using (var writer = new Utf8JsonWriter(memory, new JsonWriterOptions() { Indented = false }))
            {
                writer.WriteStartObject();
                writer.WriteString("timestamp", DateTime.UtcNow);
                writer.WriteString("severity", "error");

                if (source != null)
                    writer.WriteString("source", source);

                writer.WriteString("message", message);
                writer.WriteEndObject();
                writer.Flush();

                return Encoding.UTF8.GetString(memory.ToArray());
            }
        }

        public static String Info(String message, String? source = null, Action<Utf8JsonWriter>? additionalContent = null)
        {
            using (var memory = new MemoryStream())
            using (var writer = new Utf8JsonWriter(memory, new JsonWriterOptions() { Indented = false }))
            {
                writer.WriteStartObject();
                writer.WriteString("timestamp", DateTime.UtcNow);
                writer.WriteString("severity", "info");
                
                if (source != null)
                    writer.WriteString("source", source);

                writer.WriteString("message", message);

                if (additionalContent != null)
                    additionalContent(writer);

                writer.WriteEndObject();
                writer.Flush();

                return Encoding.UTF8.GetString(memory.ToArray());
            }
        }

        public static String SourceInfo(String source, Action<Utf8JsonWriter> content)
        {
            using (var memory = new MemoryStream())
            using (var writer = new Utf8JsonWriter(memory, new JsonWriterOptions() { Indented = true }))
            {
                writer.WriteStartObject();
                writer.WriteString("timestamp", DateTime.UtcNow);
                writer.WriteString("severity", "info");
                
                if (source != null)
                    writer.WriteString("source", source);

                content(writer);

                writer.WriteEndObject();
                writer.Flush();

                return Encoding.UTF8.GetString(memory.ToArray());
            }
        }

    }

}