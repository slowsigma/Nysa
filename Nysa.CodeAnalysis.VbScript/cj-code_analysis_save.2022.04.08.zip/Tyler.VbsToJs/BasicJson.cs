using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;

using Nysa.CodeAnalysis.VbScript.Semantics;
using Nysa.Logics;
using Nysa.Text;

namespace Tyler.VbsToJs
{

    public static class BasicJson
    {

        public static readonly KeyValuePair<String, JsonNode?>? NullKeyPair = null;
        public static KeyValuePair<String, JsonNode?> ToProperty(this String @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, JsonValue.Create(@this));
        public static KeyValuePair<String, JsonNode?> ToProperty(this Int32 @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, JsonValue.Create(@this));
        public static KeyValuePair<String, JsonNode?> ToProperty(this Boolean @this, String name)
            => new KeyValuePair<string, JsonNode?>(name, JsonValue.Create(@this));
        public static KeyValuePair<String, JsonNode?> ToProperty(this IReadOnlySet<String> @this, String name)
            => new KeyValuePair<String, JsonNode?>(name, new JsonArray(@this.Select(s => (JsonNode?)s).ToArray()));

        public static IEnumerable<KeyValuePair<String, JsonNode?>> WithProperties(params KeyValuePair<String, JsonNode?>?[] items)
            => items.Where(i => i.HasValue).Select(v => v.Value);

        public static JsonObject ToJson<T>(this T @this, params KeyValuePair<String, JsonNode?>?[] items)
            => new JsonObject(items.Where(i => i.HasValue).Select(v => v.Value));

        public static JsonNode ToJsonNode(this IEnumerable<JsonNode> @this)
            => new JsonArray(@this.ToArray());
    }

}