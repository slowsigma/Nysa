using System;
using System.Xml;

using Nysa.Text;

namespace Tyler.VbsToJs
{

    public class CustomXmlWriter : XmlWriter
    {
        private readonly XmlWriter _Writer;

        public CustomXmlWriter(XmlWriter writer)
        {
            if (writer == null)
                throw new ArgumentNullException(nameof(writer));

            this._Writer = writer;
        }

        public override void WriteString(string? text)
        {
            var parts = text.Split((Char)160);

            for (Int32 i = 0; i < parts.Length; i++)
            {
                this._Writer.WriteString(parts[i]);

                if ((i + 1) < parts.Length)
                    this._Writer.WriteRaw("&#160;");
            }
        }

        public override async Task WriteStringAsync(string? text)
        {
            var parts = text.Split((Char)160);

            for (Int32 i = 0; i < parts.Length; i++)
            {
                this._Writer.WriteString(parts[i]);

                if ((i + 1) < parts.Length)
                    await this._Writer.WriteRawAsync("&#160;");
            }
        }

        public override void Close() => this._Writer.Close();
        public override String? LookupPrefix(String ns) => this._Writer.LookupPrefix(ns);
        public override void Flush() => this._Writer.Flush();
        public override Task FlushAsync() => this._Writer.FlushAsync();
        public override WriteState WriteState => this._Writer.WriteState;
        public override void WriteBase64(byte[] buffer, int index, int count) => this._Writer.WriteBase64(buffer, index, count);
        public override Task WriteBase64Async(byte[] buffer, int index, int count) => this._Writer.WriteBase64Async(buffer, index, count);
        public override void WriteRaw(string data) => this._Writer.WriteRaw(data);
        public override Task WriteRawAsync(string data) => this._Writer.WriteRawAsync(data);
        public override void WriteRaw(char[] buffer, int index, int count) => this._Writer.WriteRaw(buffer, index, count);
        public override Task WriteRawAsync(char[] buffer, int index, int count) => this._Writer.WriteRawAsync(buffer, index, count);
        public override void WriteChars(char[] buffer, int index, int count) => this._Writer.WriteChars(buffer, index, count);
        public override Task WriteCharsAsync(char[] buffer, int index, int count) => this._Writer.WriteCharsAsync(buffer, index, count);
        public override void WriteSurrogateCharEntity(char lowChar, char highChar) => this._Writer.WriteSurrogateCharEntity(lowChar, highChar);
        public override Task WriteSurrogateCharEntityAsync(char lowChar, char highChar) => this._Writer.WriteSurrogateCharEntityAsync(lowChar, highChar);
        public override void WriteWhitespace(string? ws) => this._Writer.WriteWhitespace(ws);
        public override Task WriteWhitespaceAsync(string? ws) => this._Writer.WriteWhitespaceAsync(ws);
        public override void WriteCharEntity(char ch) => this._Writer.WriteCharEntity(ch);
        public override Task WriteCharEntityAsync(char ch) => this._Writer.WriteCharEntityAsync(ch);
        public override void WriteEntityRef(string name) => this._Writer.WriteEntityRef(name);
        public override Task WriteEntityRefAsync(string name) => this._Writer.WriteEntityRefAsync(name);
        public override void WriteProcessingInstruction(string name, string? text) => this._Writer.WriteProcessingInstruction(name, text);
        public override Task WriteProcessingInstructionAsync(string name, string? text) => this._Writer.WriteProcessingInstructionAsync(name, text);
        public override void WriteComment(string? text) => this._Writer.WriteComment(text);
        public override Task WriteCommentAsync(string? text) => this._Writer.WriteCommentAsync(text);
        public override void WriteCData(string? text) => this._Writer.WriteCData(text);
        public override Task WriteCDataAsync(string? text) => this._Writer.WriteCDataAsync(text);

        public override void WriteFullEndElement() => this._Writer.WriteFullEndElement();
        public override Task WriteFullEndElementAsync() => this._Writer.WriteFullEndElementAsync();

        public override void WriteStartElement(string? prefix, string localName, string? ns)
        {
            if (prefix != null && prefix.DataEquals("tyl"))
                this._Writer.WriteStartElement(null, String.Concat("tyl-", localName), null);
            else
                this._Writer.WriteStartElement(prefix, localName, ns);
        }

        public override async Task WriteStartElementAsync(string? prefix, string localName, string? ns)
        {
            if (prefix != null && prefix.DataEquals("tyl"))
                await this._Writer.WriteStartElementAsync(null, String.Concat("tyl-", localName), null);
            else
                await this._Writer.WriteStartElementAsync(prefix, localName, ns);
        }

        public override void WriteEndElement() => this._Writer.WriteEndElement();
        public override Task WriteEndElementAsync() => this._Writer.WriteEndElementAsync();
        public override void WriteDocType(string name, string? pubid, string? sysid, string? subset) => this._Writer.WriteDocType(name, pubid, sysid, subset);
        public override Task WriteDocTypeAsync(string name, string? pubid, string? sysid, string? subset) => this._Writer.WriteDocTypeAsync(name, pubid, sysid, subset);

        public override void WriteEndDocument() => this._Writer.WriteEndDocument();
        public override Task WriteEndDocumentAsync() => this._Writer.WriteEndDocumentAsync();

        public override void WriteStartDocument() => this._Writer.WriteStartDocument();
        public override void WriteStartDocument(bool standalone) => this._Writer.WriteStartDocument(standalone);
        public override Task WriteStartDocumentAsync() => this._Writer.WriteStartDocumentAsync();
        public override Task WriteStartDocumentAsync(bool standalone) => this._Writer.WriteStartDocumentAsync(standalone);

        public override void WriteEndAttribute() => this._Writer.WriteEndAttribute();
        public override void WriteStartAttribute(string? prefix, string localName, string? ns) => this._Writer.WriteStartAttribute(prefix, localName, ns);
        

    }

}